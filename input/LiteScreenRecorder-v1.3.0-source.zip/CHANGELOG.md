# Changelog

## 1.3.0 — Clean diagnostic baseline
- Replaced the monolithic legacy project layout with a small service / storage / diagnostics separation.
- Added hardware AVC surface capture using MediaProjection, VirtualDisplay, MediaCodec and MediaMuxer.
- Added private staging before publication and MediaStore pending-state handling.
- Added bounded rotating diagnostic logs and memory snapshot reporting.
- Reduced build parallelism to avoid unnecessary CI memory pressure.
- Explicitly deferred audio, floating controls, pause/resume, segmentation, recovery and thermal adaptation rather than shipping unverified placeholders.

## Known issue carried forward
- The previous v1.2 implementation did not contain segmented recording or session-manifest recovery. The new v1.3 baseline also does not yet implement these; they are scheduled for v1.5 after the capture lifecycle is verified.
