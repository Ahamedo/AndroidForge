# Lite Screen Recorder — clean architecture baseline (v1.3.0)

This is a new Android Java project, not a patch to AndroidForge. The ZIP root directly contains `settings.gradle`, `build.gradle`, `gradle.properties`, and `app/`.

## Build target

- Android Gradle Plugin: 8.2.2
- JDK: 17
- Java source/target: 11
- compileSdk / targetSdk: 34
- minSdk: 24 (Android 7.0)
- Dependencies: Android SDK + AndroidX Core only (transitive AndroidX Core dependency required for notifications)

## Important release scope

**v1.3.0 is a diagnostic baseline, not the final feature-complete recorder.** It deliberately establishes a small, isolated video capture lifecycle and bounded diagnostic logging before adding the higher-risk pipelines.

Implemented in this milestone:
- Fresh MediaProjection consent for each capture.
- Foreground service with the mediaProjection service type.
- Hardware AVC surface encoder and VirtualDisplay.
- MP4 muxing with explicit format-change handling and orderly EOS drain.
- Private staging file followed by verified publication to `Movies/LiteScreenRecorder`.
- MediaStore `IS_PENDING` publication on Android 10+.
- Legacy public Movies folder + MediaScanner on Android 7–9 (requires runtime storage permission).
- Bounded diagnostic log rotation (512 KiB per file, three files).
- Performance snapshot reporting at session end (30-second periodic sampling is planned for the next diagnostic patch).

Not implemented yet (do not assume these work):
- AudioPlaybackCapture / microphone capture.
- 10-minute segmented recording and session manifest/recovery.
- Floating overlay controls.
- Pause/resume.
- Automatic thermal adaptation.
- Diagnostics export UI and error-report archive.
- Device-specific encoder capability negotiation beyond configure-time failure.

These are intentionally gated to later releases. The app must not claim these functions are available until their implementations and device tests land.

## Architecture introduced

- `service/RecordingService.java` — foreground-service lifecycle and orchestration.
- `storage/StorageManager.java` — private staging and publication.
- `diagnostics/DiagnosticLogger.java` — low-overhead bounded logs and memory snapshots.
- `MainActivity.java` — minimal capture consent and quality controls.

The capture path uses a hardware AVC encoder with a Surface input. It does not create bitmaps or copy raw video frames through Java arrays.

## AndroidForge build

1. Upload this ZIP as an **app source ZIP**, not as an AndroidForge repository/workflow patch.
2. Select a **debug** build / `assembleDebug`.
3. Ensure the build environment uses JDK 17 and Gradle 8.2-compatible runtime.
4. Download the generated debug APK and install it on a test device.

Expected APK path: `app/build/outputs/apk/debug/app-debug.apk`.

## First test

1. Start at 480p / 30 FPS.
2. Approve Android's screen capture prompt.
3. Record a short clip with visible screen changes.
4. Tap Stop & Save and wait for finalization.
5. Verify the MP4 in `Movies/LiteScreenRecorder`.
6. Repeat at 720p only after the baseline succeeds.

On Android 7–9, grant storage permission when requested. Internal audio is not part of this milestone.

## Diagnostics

Logs are stored in the app's private files directory under `diagnostics/recorder.log` and rotated files. Filter Logcat by `LiteScreenRecorder` for service, encoder, muxer, projection, storage, and error messages. The diagnostic logger never records screen contents, microphone contents, passwords, or other app content.

## Known limitations and test honesty

This authoring runtime has no Android SDK platform or Gradle installation, so an Android APK build and physical-device recording test were not run here. Static source/manifest/archive checks are not substitutes for an AndroidForge build or real-device tests. A successful cloud build is the next compile gate; a 5-minute device recording is the next runtime gate.
