# Legacy source inspection — v1.2.0

Inspected source: `ScreenRecordService.java` (71,488 bytes), `MainActivity.java`, `RecordingPreferences.java`, manifest and Gradle files.

## Confirmed source-level findings

1. **Monolithic service ownership.** Projection, encoder setup, audio capture, encoder draining, muxer synchronization, storage publication, notification and overlay lifecycle are all owned by one large Service. This increases coupling and makes lifecycle races harder to isolate.
2. **Per-sample allocation.** `writeEncodedSample()` constructs a new `MediaCodec.BufferInfo` for encoded samples. This is repeated allocation on a hot path and avoidable.
3. **Audio non-blocking polling.** The audio capture thread uses `AudioRecord.READ_NON_BLOCKING` for both sources and manually sleeps only when no samples are returned. This can produce frequent wakeups and scheduling overhead; actual CPU impact needs device measurement.
4. **Muxer lock wait in encoder-drain path.** `writeEncodedSample()` waits on muxer readiness while holding the muxer coordination lock. If track readiness stalls, encoder output-drain threads can be delayed. This is a contention/stall risk, not proof of the reported thermal issue.
5. **Long-session resilience gap.** v1.2 writes one MP4 per session and has no independently finalized segments or session manifest. A process death during the active muxer can leave the current MP4 unfinalized; already finalized segment protection does not exist because segments do not exist.
6. **Broad Throwable catches.** Numerous catch blocks include `Throwable`, and several cleanup paths suppress exceptions. Some best-effort cleanup suppression is normal, but operational failures need centralized reporting and explicit resource-state tracking.

## Root cause confidence

- Confirmed: architecture coupling, repeated hot-path allocation, polling design, lack of segmentation/recovery.
- Plausible but unproven: CPU wakeup overhead, muxer lock contention, OEM codec stalls, encoder configuration beyond device capability, device thermal throttling.
- Not established: a specific memory leak, a specific native heap leak, or a single proven cause of the phone's overheating/crash. No device trace, heap dump, Perfetto capture, or Android Studio profiler output was available.

## New v1.3 baseline scope

A separate project was created with a small capture service, storage publisher, and bounded diagnostics. It currently records video only. This is an intentional compile/runtime baseline; it is not yet a replacement for every v1.2 feature. The next gates are AndroidForge compilation and real-device recording, followed by audio, segmented sessions, recovery, overlays and export UI in subsequent releases.
