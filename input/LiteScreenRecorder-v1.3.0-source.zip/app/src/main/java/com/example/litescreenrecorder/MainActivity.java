package com.example.litescreenrecorder;

import android.app.Activity;
import android.content.Intent;
import android.media.projection.MediaProjectionManager;
import android.os.Build;
import android.os.Bundle;
import android.content.pm.PackageManager;
import android.Manifest;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.Spinner;
import android.widget.ArrayAdapter;
import android.widget.TextView;
import android.widget.Toast;
import com.example.litescreenrecorder.service.RecordingService;

/** Minimal control surface for the performance-diagnosis release. */
public final class MainActivity extends Activity {
    private static final int REQUEST_CAPTURE = 7001;
    private Spinner quality, fps;
    private TextView state;
    @Override protected void onCreate(Bundle saved) {
        super.onCreate(saved);
        LinearLayout root = new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(24), dp(28), dp(24), dp(24)); root.setBackgroundColor(0xff101820);
        TextView title = new TextView(this); title.setText("Lite Screen Recorder"); title.setTextSize(26); title.setTextColor(0xffffffff); title.setGravity(Gravity.CENTER_VERTICAL);
        root.addView(title, params(-1, dp(52)));
        TextView subtitle = new TextView(this); subtitle.setText("Performance diagnosis release • v1.3.0"); subtitle.setTextColor(0xffaab7c4); subtitle.setTextSize(13);
        root.addView(subtitle, params(-1, dp(32)));
        state = new TextView(this); state.setText("READY  •  Video-only diagnostic baseline"); state.setTextColor(0xff73d6a0); state.setTextSize(15); state.setPadding(0, dp(24), 0, dp(24));
        root.addView(state, params(-1, dp(72)));
        root.addView(label("VIDEO QUALITY")); quality = spinner(new String[]{"480p • Low resource", "720p", "1080p"}); root.addView(quality, params(-1, dp(52)));
        root.addView(label("FRAME RATE")); fps = spinner(new String[]{"30 FPS", "60 FPS"}); root.addView(fps, params(-1, dp(52)));
        Button start = button("START RECORDING", 0xff1677d2); root.addView(start, params(-1, dp(56)));
        Button stop = button("STOP & SAVE", 0xffb83b42); LinearLayout.LayoutParams stopParams = params(-1, dp(56)); stopParams.topMargin = dp(12); root.addView(stop, stopParams);
        TextView note = new TextView(this);
        note.setText("This milestone verifies the new capture lifecycle and diagnostic baseline. Audio capture, floating controls and segmented sessions are not yet enabled in v1.3.0; they are not represented as completed features.");
        note.setTextColor(0xffc3cbd3); note.setTextSize(13); note.setPadding(0, dp(24), 0, 0); root.addView(note, params(-1, -2));
        setContentView(root);
        start.setOnClickListener(v -> requestCapture());
        stop.setOnClickListener(v -> { Intent i = new Intent(this, RecordingService.class).setAction(RecordingService.ACTION_STOP); startService(i); state.setText("STOPPING • Finalizing MP4"); });
    }
    private void requestCapture() {
        if (Build.VERSION.SDK_INT <= 28 && checkSelfPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE}, 7002);
            return;
        }
        MediaProjectionManager manager = (MediaProjectionManager)getSystemService(MEDIA_PROJECTION_SERVICE);
        startActivityForResult(manager.createScreenCaptureIntent(), REQUEST_CAPTURE);
    }
    @Override public void onRequestPermissionsResult(int request, String[] permissions, int[] results) {
        super.onRequestPermissionsResult(request, permissions, results);
        if (request == 7002 && results.length > 0 && results[0] == PackageManager.PERMISSION_GRANTED) requestCapture();
        else if (request == 7002) Toast.makeText(this, "Storage permission is required on Android 7–9", Toast.LENGTH_LONG).show();
    }
    @Override protected void onActivityResult(int request, int result, Intent data) {
        super.onActivityResult(request, result, data);
        if (request != REQUEST_CAPTURE) return;
        if (result != RESULT_OK || data == null) { state.setText("READY • Screen capture permission not granted"); return; }
        int[] q = {480, 720, 1080}; int[] f = {30, 60};
        Intent service = new Intent(this, RecordingService.class).setAction(RecordingService.ACTION_START)
                .putExtra(RecordingService.EXTRA_RESULT_CODE, result)
                .putExtra(RecordingService.EXTRA_RESULT_DATA, data)
                .putExtra(RecordingService.EXTRA_QUALITY, q[quality.getSelectedItemPosition()])
                .putExtra(RecordingService.EXTRA_FPS, f[fps.getSelectedItemPosition()]);
        if (Build.VERSION.SDK_INT >= 26) startForegroundService(service); else startService(service);
        state.setText("STARTING • Waiting for encoder");
    }
    private Spinner spinner(String[] values) { Spinner s = new Spinner(this); s.setAdapter(new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, values)); return s; }
    private TextView label(String value) { TextView t = new TextView(this); t.setText(value); t.setTextColor(0xff91a4b5); t.setTextSize(11); t.setPadding(0, dp(18), 0, dp(6)); return t; }
    private Button button(String text, int color) { Button b = new Button(this); b.setText(text); b.setTextColor(0xffffffff); b.setBackgroundTintList(android.content.res.ColorStateList.valueOf(color)); return b; }
    private LinearLayout.LayoutParams params(int w, int h) { return new LinearLayout.LayoutParams(w, h); }
    private int dp(int value) { return (int)(value * getResources().getDisplayMetrics().density + 0.5f); }
}
