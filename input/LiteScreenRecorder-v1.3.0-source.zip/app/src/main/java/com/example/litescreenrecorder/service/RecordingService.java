package com.example.litescreenrecorder.service;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.Service;
import android.content.Intent;
import android.content.pm.ServiceInfo;
import android.hardware.display.DisplayManager;
import android.hardware.display.VirtualDisplay;
import android.media.MediaCodec;
import android.media.MediaCodecInfo;
import android.media.MediaCodecList;
import android.media.MediaFormat;
import android.media.MediaMuxer;
import android.media.projection.MediaProjection;
import android.media.projection.MediaProjectionManager;
import android.os.Build;
import android.os.IBinder;
import android.os.SystemClock;
import android.util.DisplayMetrics;
import android.view.Surface;
import android.view.WindowManager;
import androidx.core.app.NotificationCompat;
import com.example.litescreenrecorder.diagnostics.DiagnosticLogger;
import com.example.litescreenrecorder.storage.StorageManager;
import java.io.File;
import java.io.IOException;
import java.nio.ByteBuffer;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;
import java.util.concurrent.atomic.AtomicBoolean;

/** Video-only diagnostic capture engine. Audio and segmentation are gated to later releases. */
public final class RecordingService extends Service {
    public static final String ACTION_START = "com.example.litescreenrecorder.START";
    public static final String ACTION_STOP = "com.example.litescreenrecorder.STOP";
    public static final String EXTRA_RESULT_CODE = "resultCode";
    public static final String EXTRA_RESULT_DATA = "resultData";
    public static final String EXTRA_QUALITY = "quality";
    public static final String EXTRA_FPS = "fps";
    private static final String CHANNEL = "lite_recorder_status";
    private static final int NOTIFICATION_ID = 4101;
    private final AtomicBoolean stopping = new AtomicBoolean(false);
    private DiagnosticLogger logger;
    private MediaProjection projection;
    private VirtualDisplay virtualDisplay;
    private MediaCodec encoder;
    private Surface inputSurface;
    private MediaMuxer muxer;
    private Thread drainThread;
    private File stagingFile;
    private long startedAt;
    private int width, height, fps, bitrate, track = -1;
    private boolean muxerStarted;
    private volatile boolean eosSeen;
    private String sessionId;
    private final android.os.Handler metricsHandler = new android.os.Handler(android.os.Looper.getMainLooper());
    private final Runnable metricsTask = new Runnable() {
        @Override public void run() {
            if (projection == null || stopping.get()) return;
            logger.performance(sessionId, 1, SystemClock.elapsedRealtime() - startedAt);
            if (Build.VERSION.SDK_INT >= 29) {
                android.os.PowerManager power = (android.os.PowerManager)getSystemService(POWER_SERVICE);
                if (power != null) logger.info("Performance", "thermalStatus=" + power.getCurrentThermalStatus());
            }
            metricsHandler.postDelayed(this, 30_000L);
        }
    };

    @Override public void onCreate() { super.onCreate(); logger = new DiagnosticLogger(this); createChannel(); }
    @Override public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent == null) { stopSelf(startId); return START_NOT_STICKY; }
        if (ACTION_STOP.equals(intent.getAction())) { requestStop("user"); return START_NOT_STICKY; }
        if (ACTION_START.equals(intent.getAction())) {
            if (Build.VERSION.SDK_INT >= 29) {
                startForeground(NOTIFICATION_ID, notification("Preparing screen capture"), ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION);
            } else {
                startForeground(NOTIFICATION_ID, notification("Preparing screen capture"));
            }
            if (projection != null) { logger.warn("Service", "Duplicate start ignored", null); return START_NOT_STICKY; }
            try { startCapture(intent); }
            catch (Exception e) { logger.error("Service", "Capture startup failed", e); cleanup(false); stopSelf(); }
        }
        return START_NOT_STICKY;
    }

    private void startCapture(Intent intent) throws Exception {
        int resultCode = intent.getIntExtra(EXTRA_RESULT_CODE, 0);
        Intent data = intent.getParcelableExtra(EXTRA_RESULT_DATA);
        if (data == null) throw new IOException("Missing MediaProjection consent result");
        int shortSide = intent.getIntExtra(EXTRA_QUALITY, 480);
        fps = Math.max(15, Math.min(60, intent.getIntExtra(EXTRA_FPS, 30)));
        DisplayMetrics metrics = new DisplayMetrics();
        WindowManager wm = (WindowManager) getSystemService(WINDOW_SERVICE);
        if (wm == null) throw new IOException("WindowManager unavailable");
        wm.getDefaultDisplay().getRealMetrics(metrics);
        float scale = shortSide / (float)Math.min(metrics.widthPixels, metrics.heightPixels);
        width = even((int)(metrics.widthPixels * scale)); height = even((int)(metrics.heightPixels * scale));
        bitrate = Math.max(900_000, Math.min(6_000_000, width * height * fps / 7));
        sessionId = new SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(new Date());
        stagingFile = new StorageManager(this).createStagingFile(sessionId);
        MediaProjectionManager manager = (MediaProjectionManager)getSystemService(MEDIA_PROJECTION_SERVICE);
        projection = manager.getMediaProjection(resultCode, data);
        if (projection == null) throw new IOException("MediaProjection unavailable");
        projection.registerCallback(new MediaProjection.Callback() {
            @Override public void onStop() { logger.warn("Projection", "Projection revoked by system", null); requestStop("projection_revoked"); }
        }, new android.os.Handler(getMainLooper()));
        MediaFormat format = MediaFormat.createVideoFormat(MediaFormat.MIMETYPE_VIDEO_AVC, width, height);
        format.setInteger(MediaFormat.KEY_COLOR_FORMAT, MediaCodecInfo.CodecCapabilities.COLOR_FormatSurface);
        format.setInteger(MediaFormat.KEY_BIT_RATE, bitrate);
        format.setInteger(MediaFormat.KEY_FRAME_RATE, fps);
        format.setInteger(MediaFormat.KEY_I_FRAME_INTERVAL, 2);
        format.setInteger(MediaFormat.KEY_BITRATE_MODE, MediaCodecInfo.EncoderCapabilities.BITRATE_MODE_VBR);
        String codecName = findHardwareAvcEncoder(format);
        if (codecName == null) throw new IOException("No compatible hardware AVC encoder supports " + width + "x" + height + " @ " + fps);
        logger.info("Encoder", "Selected hardware AVC encoder=" + codecName);
        encoder = MediaCodec.createByCodecName(codecName);
        encoder.configure(format, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE);
        inputSurface = encoder.createInputSurface();
        encoder.start();
        muxer = new MediaMuxer(stagingFile.getAbsolutePath(), MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4);
        virtualDisplay = projection.createVirtualDisplay("LiteScreenRecorder", width, height,
                metrics.densityDpi, DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
                inputSurface, null, null);
        if (virtualDisplay == null) throw new IOException("VirtualDisplay creation failed");
        startedAt = SystemClock.elapsedRealtime();
        metricsHandler.removeCallbacks(metricsTask);
        metricsHandler.postDelayed(metricsTask, 30_000L);
        drainThread = new Thread(this::drainEncoder, "LSR-VideoDrain");
        drainThread.start();
        logger.info("Service", "START session=" + sessionId + " size=" + width + "x" + height + " fps=" + fps + " bitrate=" + bitrate);
        logger.info("Service", "Audio disabled in v1.3 diagnostic baseline; segmented recording is scheduled for v1.5");
        updateNotification("Recording • " + width + "×" + height + " @ " + fps + " FPS");
    }

    private void drainEncoder() {
        MediaCodec.BufferInfo info = new MediaCodec.BufferInfo();
        try {
            while (!eosSeen) {
                int index = encoder.dequeueOutputBuffer(info, 10_000);
                if (index == MediaCodec.INFO_TRY_AGAIN_LATER) continue;
                if (index == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) {
                    if (muxerStarted) throw new IllegalStateException("Encoder output format changed twice");
                    track = muxer.addTrack(encoder.getOutputFormat()); muxer.start(); muxerStarted = true;
                    logger.info("Muxer", "Muxer started; video track=" + track);
                    continue;
                }
                if (index >= 0) {
                    ByteBuffer out = encoder.getOutputBuffer(index);
                    if (out != null && info.size > 0 && muxerStarted && (info.flags & MediaCodec.BUFFER_FLAG_CODEC_CONFIG) == 0) {
                        out.position(info.offset); out.limit(info.offset + info.size);
                        muxer.writeSampleData(track, out, info);
                    }
                    boolean eos = (info.flags & MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0;
                    encoder.releaseOutputBuffer(index, false);
                    if (eos) eosSeen = true;
                }
            }
        } catch (Exception e) {
            logger.error("Encoder", "Drain loop failed", e);
            requestStop("encoder_error");
        }
    }

    private void requestStop(String reason) {
        if (!stopping.compareAndSet(false, true)) return;
        new Thread(() -> {
            logger.info("Service", "STOP requested reason=" + reason);
            cleanup(true);
            stopSelf();
        }, "LSR-Stop").start();
    }

    private void cleanup(boolean finalize) {
        try { if (virtualDisplay != null) { virtualDisplay.release(); virtualDisplay = null; } } catch (Exception e) { logger.warn("Projection", "VirtualDisplay release failed", e); }
        try { if (encoder != null) encoder.signalEndOfInputStream(); } catch (Exception e) { logger.warn("Encoder", "EOS signal failed", e); }
        if (drainThread != null && drainThread != Thread.currentThread()) {
            try { drainThread.join(7000); } catch (InterruptedException e) { Thread.currentThread().interrupt(); }
            if (drainThread.isAlive()) logger.error("Encoder", "Drain thread timed out", null);
        }
        try { if (encoder != null) { encoder.stop(); encoder.release(); encoder = null; } } catch (Exception e) { logger.warn("Encoder", "Encoder release failed", e); }
        try { if (inputSurface != null) { inputSurface.release(); inputSurface = null; } } catch (Exception e) { logger.warn("Encoder", "Input surface release failed", e); }
        boolean valid = false;
        try {
            if (muxer != null) {
                if (muxerStarted) { muxer.stop(); valid = true; }
                muxer.release(); muxer = null; muxerStarted = false;
            }
        } catch (Exception e) { logger.error("Muxer", "MP4 finalization failed", e); }
        try { if (projection != null) { projection.stop(); projection = null; } } catch (Exception e) { logger.warn("Projection", "Projection stop failed", e); }
        if (finalize && valid && stagingFile != null && stagingFile.length() > 0) {
            try {
                String name = "LiteScreenRecorder_" + sessionId + ".mp4";
                android.net.Uri uri = new StorageManager(this).publish(stagingFile, name);
                logger.info("Storage", "SAVED uri=" + uri + " bytes=" + stagingFile.length());
                if (!stagingFile.delete()) logger.warn("Storage", "Could not remove staging file", null);
            } catch (Exception e) { logger.error("Storage", "Completed MP4 retained in private staging", e); }
        } else if (stagingFile != null) logger.warn("Storage", "No verified completed MP4; staging retained if nonempty", null);
        metricsHandler.removeCallbacks(metricsTask);
        logger.performance(sessionId == null ? "none" : sessionId, 1, startedAt == 0 ? 0 : SystemClock.elapsedRealtime() - startedAt);
        stopForeground(STOP_FOREGROUND_REMOVE);
    }

    private String findHardwareAvcEncoder(MediaFormat format) {
        MediaCodecList list = new MediaCodecList(MediaCodecList.REGULAR_CODECS);
        for (MediaCodecInfo info : list.getCodecInfos()) {
            if (!info.isEncoder()) continue;
            boolean avc = false;
            for (String type : info.getSupportedTypes()) if (MediaFormat.MIMETYPE_VIDEO_AVC.equalsIgnoreCase(type)) avc = true;
            if (!avc) continue;
            String name = info.getName();
            boolean hardware;
            if (Build.VERSION.SDK_INT >= 29) hardware = info.isHardwareAccelerated();
            else hardware = !(name.toLowerCase(Locale.US).contains("google") || name.toLowerCase(Locale.US).contains("software"));
            if (!hardware) continue;
            try {
                MediaCodecInfo.CodecCapabilities caps = info.getCapabilitiesForType(MediaFormat.MIMETYPE_VIDEO_AVC);
                if (!caps.isFormatSupported(format)) continue;
                return name;
            } catch (RuntimeException unsupported) {
                logger.warn("Encoder", "Codec capability query failed for " + name, unsupported);
            }
        }
        return null;
    }
    private int even(int n) { return Math.max(2, n & ~1); }
    private void createChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationChannel c = new NotificationChannel(CHANNEL, "Recording status", NotificationManager.IMPORTANCE_LOW);
            ((NotificationManager)getSystemService(NOTIFICATION_SERVICE)).createNotificationChannel(c);
        }
    }
    private Notification notification(String text) {
        return new NotificationCompat.Builder(this, CHANNEL).setSmallIcon(android.R.drawable.presence_video_online)
                .setContentTitle("Lite Screen Recorder").setContentText(text).setOngoing(true).build();
    }
    private void updateNotification(String text) { ((NotificationManager)getSystemService(NOTIFICATION_SERVICE)).notify(NOTIFICATION_ID, notification(text)); }
    @Override public void onDestroy() { if (!stopping.get() && projection != null) requestStop("service_destroyed"); super.onDestroy(); }
    @Override public IBinder onBind(Intent intent) { return null; }
}
