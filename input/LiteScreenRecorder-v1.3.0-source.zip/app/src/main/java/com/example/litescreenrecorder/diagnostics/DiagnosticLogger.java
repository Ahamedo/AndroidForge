package com.example.litescreenrecorder.diagnostics;

import android.content.Context;
import android.os.Debug;
import android.os.Process;
import android.util.Log;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

/** Small bounded file logger. It never logs captured screen/audio content. */
public final class DiagnosticLogger {
    public static final String TAG = "LiteScreenRecorder";
    private static final long MAX_FILE_BYTES = 512L * 1024L;
    private static final int MAX_FILES = 3;
    private final File directory;
    private final File active;
    private final SimpleDateFormat clock = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSSZ", Locale.US);

    public DiagnosticLogger(Context context) {
        directory = new File(context.getFilesDir(), "diagnostics");
        if (!directory.exists() && !directory.mkdirs()) Log.e(TAG, "Cannot create diagnostics directory");
        active = new File(directory, "recorder.log");
    }
    public synchronized void info(String component, String message) { write("I", component, message, null); }
    public synchronized void warn(String component, String message, Throwable error) { write("W", component, message, error); }
    public synchronized void error(String component, String message, Throwable error) { write("E", component, message, error); }
    public synchronized void performance(String session, int segment, long durationMs) {
        Runtime r = Runtime.getRuntime(); Debug.MemoryInfo nativeInfo = new Debug.MemoryInfo();
        Debug.getMemoryInfo(nativeInfo);
        long javaUsed = r.totalMemory() - r.freeMemory();
        long cpuMs = Process.getElapsedCpuTime();
        write("I", "Performance", "session=" + session + " segment=" + segment + " durationMs=" + durationMs
                + " processCpuMs=" + cpuMs + " javaHeapUsed=" + javaUsed + " javaHeapMax=" + r.maxMemory()
                + " nativePssKb=" + nativeInfo.nativePss + " dalvikPssKb=" + nativeInfo.dalvikPss
                + " pid=" + Process.myPid(), null);
    }
    private void write(String level, String component, String message, Throwable error) {
        String line = clock.format(new Date()) + " " + level + "/" + component + ": " + message;
        if (error != null) line += " | " + Log.getStackTraceString(error);
        Log.println(level.equals("E") ? Log.ERROR : level.equals("W") ? Log.WARN : Log.INFO, TAG, line);
        try {
            rotateIfNeeded();
            try (FileWriter writer = new FileWriter(active, true)) { writer.write(line); writer.write('\n'); }
        } catch (IOException e) { Log.e(TAG, "Diagnostic file write failed", e); }
    }
    private void rotateIfNeeded() {
        if (!active.exists() || active.length() < MAX_FILE_BYTES) return;
        File oldest = new File(directory, "recorder." + (MAX_FILES - 1) + ".log");
        if (oldest.exists() && !oldest.delete()) Log.w(TAG, "Could not delete oldest log");
        for (int i = MAX_FILES - 2; i >= 1; i--) {
            File from = new File(directory, "recorder." + i + ".log");
            if (from.exists() && !from.renameTo(new File(directory, "recorder." + (i + 1) + ".log"))) Log.w(TAG, "Log rotation rename failed");
        }
        if (!active.renameTo(new File(directory, "recorder.1.log"))) Log.w(TAG, "Active log rotation failed");
    }
}
