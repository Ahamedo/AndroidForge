package com.example.litescreenrecorder.storage;

import android.content.ContentValues;
import android.content.Context;
import android.net.Uri;
import android.os.Build;
import android.os.Environment;
import android.provider.MediaStore;
import java.io.File;
import java.io.IOException;

/** Creates a private staging MP4. Publishing is a separate, verified operation. */
public final class StorageManager {
    private final Context context;
    public StorageManager(Context context) { this.context = context.getApplicationContext(); }
    public File createStagingFile(String sessionId) throws IOException {
        File dir = new File(context.getFilesDir(), "recording-staging");
        if (!dir.exists() && !dir.mkdirs()) throw new IOException("Cannot create staging directory");
        File file = new File(dir, "LSR_" + sessionId + ".mp4");
        if (file.exists() && !file.delete()) throw new IOException("Cannot replace staging file");
        return file;
    }
    public Uri publish(File source, String displayName) throws IOException {
        if (!source.isFile() || source.length() <= 0) throw new IOException("Staging MP4 is missing or empty");
        if (Build.VERSION.SDK_INT >= 29) {
            ContentValues values = new ContentValues();
            values.put(MediaStore.Video.Media.DISPLAY_NAME, displayName);
            values.put(MediaStore.Video.Media.MIME_TYPE, "video/mp4");
            values.put(MediaStore.Video.Media.RELATIVE_PATH, Environment.DIRECTORY_MOVIES + "/LiteScreenRecorder");
            values.put(MediaStore.Video.Media.IS_PENDING, 1);
            Uri uri = context.getContentResolver().insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, values);
            if (uri == null) throw new IOException("MediaStore insert failed");
            boolean success = false;
            try {
                long copied = 0;
                try (java.io.InputStream in = new java.io.FileInputStream(source);
                     java.io.OutputStream out = context.getContentResolver().openOutputStream(uri, "w")) {
                    if (out == null) throw new IOException("MediaStore output stream unavailable");
                    byte[] buffer = new byte[32 * 1024]; int n;
                    while ((n = in.read(buffer)) != -1) { out.write(buffer, 0, n); copied += n; }
                    out.flush();
                }
                if (copied != source.length()) throw new IOException("MediaStore copy size mismatch");
                ContentValues ready = new ContentValues(); ready.put(MediaStore.Video.Media.IS_PENDING, 0);
                if (context.getContentResolver().update(uri, ready, null, null) <= 0) throw new IOException("Could not publish MediaStore row");
                success = true;
                return uri;
            } finally { if (!success) context.getContentResolver().delete(uri, null, null); }
        }
        File movies = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_MOVIES);
        File folder = new File(movies, "LiteScreenRecorder");
        if (!folder.exists() && !folder.mkdirs()) throw new IOException("Cannot create Movies/LiteScreenRecorder");
        File destination = new File(folder, displayName);
        try (java.io.InputStream in = new java.io.FileInputStream(source);
             java.io.OutputStream out = new java.io.FileOutputStream(destination)) {
            byte[] buffer = new byte[32 * 1024]; int n; long copied = 0;
            while ((n = in.read(buffer)) != -1) { out.write(buffer, 0, n); copied += n; }
            out.flush();
            if (copied != source.length() || destination.length() != source.length()) throw new IOException("Legacy storage copy verification failed");
        }
        android.media.MediaScannerConnection.scanFile(context, new String[]{destination.getAbsolutePath()}, new String[]{"video/mp4"}, null);
        return Uri.fromFile(destination);
    }
}
