# Lite Recorder

A lightweight Android screen recorder using Android MediaProjection and MediaRecorder. Recordings are stored in Movies/LiteRecorder on Android 10+, and in the app-specific Movies folder on Android 6–9.

## Build

Open this folder in Android Studio (Hedgehog or newer) and sync Gradle. The project uses JDK 17, Android Gradle Plugin 8.9.2, compile SDK 35, and Kotlin 2.1.20. Build with `gradle assembleDebug` or run the included GitHub Actions workflow. The APK is produced at `app/build/outputs/apk/debug/app-debug.apk`.

## Use

Install the debug APK, grant microphone and notification permissions, tap Start Recording, then approve Android's screen-capture prompt. Stop from the app or the persistent notification. Pause and resume are supported on Android 7+.

## Audio and recovery

The app records microphone input. The Internal + Mic option is retained as a best-effort preference, but stock Android does not let MediaRecorder mix internal playback audio and microphone audio. Android can also terminate a process without running cleanup code, so a valid MP4 cannot be guaranteed after force-stop, process kill, crash, or power loss. Normal Stop finalizes the recording before publishing it to the gallery. Device codec and thermal limits vary; 60/90 fps or 1080p may fail on some devices. If so, retry at 720p/30 fps.
