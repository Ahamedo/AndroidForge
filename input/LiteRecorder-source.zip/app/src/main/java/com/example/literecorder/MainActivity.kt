package com.example.literecorder

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Bundle
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.Spinner
import android.widget.TextView

class MainActivity : Activity() {
    private lateinit var settings: SettingsManager
    private lateinit var resolution: Spinner
    private lateinit var fps: Spinner
    private lateinit var audio: Spinner
    private lateinit var button: Button
    private lateinit var status: TextView
    private val stateReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            status.text = intent?.getStringExtra(ScreenRecorderService.EXTRA_STATUS) ?: "Ready"
            renderState()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        settings = SettingsManager(this)
        resolution = findViewById(R.id.resolutionSpinner)
        fps = findViewById(R.id.fpsSpinner)
        audio = findViewById(R.id.audioSpinner)
        button = findViewById(R.id.recordButton)
        status = findViewById(R.id.statusText)
        setupSpinner(resolution, listOf("480p", "720p", "1080p"), settings.resolution)
        setupSpinner(fps, listOf("30", "60", "90"), settings.frameRate.toString())
        setupSpinner(audio, listOf(SettingsManager.AUDIO_MIC, SettingsManager.AUDIO_INTERNAL), settings.audioMode)
        button.setOnClickListener {
            if (ScreenRecorderService.isRecording) {
                startService(Intent(this, ScreenRecorderService::class.java).setAction(ScreenRecorderService.ACTION_STOP))
            } else requestCapture()
        }
        renderState()
    }

    override fun onStart() {
        super.onStart()
        val filter = IntentFilter(ScreenRecorderService.ACTION_STATE)
        if (Build.VERSION.SDK_INT >= 33) registerReceiver(stateReceiver, filter, Context.RECEIVER_NOT_EXPORTED)
        else registerReceiver(stateReceiver, filter)
    }

    override fun onStop() {
        unregisterReceiver(stateReceiver)
        super.onStop()
    }
    override fun onResume() {
        super.onResume()
        renderState()
    }

    private fun setupSpinner(spinner: Spinner, items: List<String>, selected: String) {
        spinner.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, items)
        spinner.setSelection(items.indexOf(selected).coerceAtLeast(0))
    }

    private fun requestCapture() {
        val micMissing = checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED
        val notificationsMissing = Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        if (micMissing || notificationsMissing) {
            permissionRequestInProgress = true
            val requested = if (Build.VERSION.SDK_INT >= 33) arrayOf(Manifest.permission.RECORD_AUDIO, Manifest.permission.POST_NOTIFICATIONS)
                else arrayOf(Manifest.permission.RECORD_AUDIO)
            requestPermissions(requested, REQUEST_PERMISSIONS)
            return
        }
        launchProjectionConsent()
    }

    private fun launchProjectionConsent() {
        saveSettings()
        val manager = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        @Suppress("DEPRECATION")
        startActivityForResult(manager.createScreenCaptureIntent(), REQUEST_CAPTURE)
    }

    @Deprecated("Platform activity result callback")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == REQUEST_CAPTURE) {
            if (resultCode == RESULT_OK && data != null) {
                val service = Intent(this, ScreenRecorderService::class.java).apply {
                    action = ScreenRecorderService.ACTION_START
                    putExtra(ScreenRecorderService.EXTRA_RESULT_CODE, resultCode)
                    putExtra(ScreenRecorderService.EXTRA_RESULT_DATA, data)
                    putExtra(ScreenRecorderService.EXTRA_RESOLUTION, settings.resolution)
                    putExtra(ScreenRecorderService.EXTRA_FPS, settings.frameRate)
                }
                if (Build.VERSION.SDK_INT >= 26) startForegroundService(service) else startService(service)
                status.text = "Starting recorder…"
            } else status.text = "Screen capture permission was cancelled."
        }
    }

    @Deprecated("Platform permission callback")
    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, results: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, results)
        if (requestCode != REQUEST_PERMISSIONS) return
        permissionRequestInProgress = false
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) launchProjectionConsent()
        else status.text = "Microphone permission is needed to record audio."
    }

    private fun saveSettings() {
        settings.resolution = resolution.selectedItem.toString()
        settings.frameRate = fps.selectedItem.toString().toIntOrNull() ?: 30
        settings.audioMode = audio.selectedItem.toString()
    }

    private fun renderState() {
        val active = ScreenRecorderService.isRecording
        button.text = if (active) "Stop Recording" else "Start Recording"
        resolution.isEnabled = !active
        fps.isEnabled = !active
        audio.isEnabled = !active
        if (!active && status.text.toString().startsWith("Recording")) status.text = "Recording saved to Movies/LiteRecorder"
    }

    companion object {
        private const val REQUEST_PERMISSIONS = 20
        private const val REQUEST_CAPTURE = 21
    }
}



