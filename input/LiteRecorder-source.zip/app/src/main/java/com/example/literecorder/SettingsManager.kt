package com.example.literecorder

import android.content.Context

class SettingsManager(context: Context) {
    private val prefs = context.getSharedPreferences("recorder_settings", Context.MODE_PRIVATE)
    var resolution: String
        get() = prefs.getString("resolution", "720p") ?: "720p"
        set(value) { prefs.edit().putString("resolution", value).apply() }
    var frameRate: Int
        get() = prefs.getInt("fps", 30)
        set(value) { prefs.edit().putInt("fps", value).apply() }
    var audioMode: String
        get() = prefs.getString("audio", AUDIO_MIC) ?: AUDIO_MIC
        set(value) { prefs.edit().putString("audio", value).apply() }

    companion object {
        const val AUDIO_MIC = "Microphone only"
        const val AUDIO_INTERNAL = "Internal + Mic (best effort)"
    }
}
