package com.example.literecorder

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.ContentValues
import android.content.Intent
import android.content.pm.ServiceInfo
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.MediaRecorder
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.os.ParcelFileDescriptor
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.provider.MediaStore
import android.util.DisplayMetrics
import android.view.WindowManager
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class ScreenRecorderService : Service() {
    private var projection: MediaProjection? = null
    private var recorder: MediaRecorder? = null
    private var display: VirtualDisplay? = null
    private var outputUri: Uri? = null
    private var outputPfd: ParcelFileDescriptor? = null
    private var outputFile: File? = null
    private var recording = false
    private var paused = false
    private var startedAt = 0L
    private val handler = Handler(Looper.getMainLooper())
    private val ticker = object : Runnable {
        override fun run() {
            if (recording) {
                if (!paused) updateNotification("Recording • ${elapsedText()}")
                handler.postDelayed(this, 1000)
            }
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        createChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_START -> {
                startForegroundCompat(notification("Preparing recording"))
                startRecording(intent)
            }
            ACTION_STOP -> stopRecording()
            ACTION_PAUSE -> pauseRecording()
            ACTION_RESUME -> resumeRecording()
        }
        return START_NOT_STICKY
    }

    private fun startRecording(intent: Intent) {
        try {
            val data = intent.getCaptureIntent() ?: error("Screen capture authorization is missing")
            val resultCode = intent.getIntExtra(EXTRA_RESULT_CODE, 0)
            val manager = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
            projection = manager.getMediaProjection(resultCode, data) ?: error("Screen projection unavailable")
            projection?.registerCallback(object : MediaProjection.Callback() {
                override fun onStop() {
                    if (recording) stopRecording()
                }
            }, handler)

            val metrics = displayMetrics()
            val requestedHeight = when (intent.getStringExtra(EXTRA_RESOLUTION)) {
                "480p" -> 480
                "1080p" -> 1080
                else -> 720
            }
            val scale = requestedHeight.toFloat() / metrics.heightPixels.toFloat()
            val width = even((metrics.widthPixels * scale).toInt())
            val height = even(requestedHeight.coerceAtMost(metrics.heightPixels))
            val requestedFps = intent.getIntExtra(EXTRA_FPS, 30).coerceIn(30, 90)

            prepareOutput()
            val mr = if (Build.VERSION.SDK_INT >= 31) MediaRecorder(this) else {
                @Suppress("DEPRECATION") MediaRecorder()
            }
            recorder = mr
            mr.setVideoSource(MediaRecorder.VideoSource.SURFACE)
            mr.setAudioSource(MediaRecorder.AudioSource.MIC)
            mr.setOutputFormat(MediaRecorder.OutputFormat.MPEG_4)
            mr.setVideoEncoder(MediaRecorder.VideoEncoder.H264)
            mr.setAudioEncoder(MediaRecorder.AudioEncoder.AAC)
            mr.setVideoSize(width, height)
            mr.setVideoFrameRate(requestedFps)
            val bitrate = (width.toLong() * height * requestedFps / 6L).coerceIn(1_500_000L, 12_000_000L)
            mr.setVideoEncodingBitRate(bitrate.toInt())
            mr.setAudioEncodingBitRate(96_000)
            mr.setAudioSamplingRate(44_100)
            if (Build.VERSION.SDK_INT >= 29) {
                val uri = outputUri ?: error("Media output was not created")
                outputPfd = contentResolver.openFileDescriptor(uri, "w") ?: error("Cannot open video output")
                mr.setOutputFile(outputPfd!!.fileDescriptor)
                mr.prepare()
                startRecorder(mr, width, height, metrics.densityDpi)
            } else {
                mr.setOutputFile(outputFile!!.absolutePath)
                mr.prepare()
                startRecorder(mr, width, height, metrics.densityDpi)
            }
            recording = true
            paused = false
            startedAt = System.currentTimeMillis()
            isRecording = true
            handler.post(ticker)
            updateNotification("Recording • 00:00")
            broadcast("Recording")
        } catch (t: Throwable) {
            cleanup(false)
            broadcast("Could not start recording: ${t.message ?: "unsupported device setting"}")
            stopForeground(STOP_FOREGROUND_REMOVE)
            stopSelf()
        }
    }

    private fun startRecorder(mr: MediaRecorder, width: Int, height: Int, density: Int) {
        display = projection?.createVirtualDisplay(
            "LiteRecorder", width, height, density,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
            mr.surface, null, handler
        ) ?: error("Could not create virtual display")
        mr.start()
    }

    private fun prepareOutput() {
        val filename = "Screen_${SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())}.mp4"
        if (Build.VERSION.SDK_INT >= 29) {
            val values = ContentValues().apply {
                put(MediaStore.Video.Media.DISPLAY_NAME, filename)
                put(MediaStore.Video.Media.MIME_TYPE, "video/mp4")
                put(MediaStore.Video.Media.RELATIVE_PATH, "Movies/LiteRecorder")
                put(MediaStore.Video.Media.IS_PENDING, 1)
            }
            outputUri = contentResolver.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, values)
                ?: error("Could not create a video in Movies/LiteRecorder")
        } else {
            @Suppress("DEPRECATION")
            val folder = getExternalFilesDir(Environment.DIRECTORY_MOVIES) ?: filesDir
            if (!folder.exists() && !folder.mkdirs()) error("Cannot create recording folder")
            outputFile = File(folder, filename)
        }
    }

    private fun stopRecording() {
        if (!recording) {
            cleanup(false)
            stopForeground(STOP_FOREGROUND_REMOVE)
            stopSelf()
            return
        }
        recording = false
        isRecording = false
        handler.removeCallbacks(ticker)
        var success = false
        try { recorder?.stop(); success = true } catch (_: RuntimeException) { }
        cleanup(success)
        broadcast(if (success) "Recording saved to Movies/LiteRecorder" else "Recording was too short to save")
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    private fun cleanup(publish: Boolean) {
        try { recorder?.reset() } catch (_: Throwable) { }
        try { recorder?.release() } catch (_: Throwable) { }
        recorder = null
        try { display?.release() } catch (_: Throwable) { }
        display = null
        try { projection?.stop() } catch (_: Throwable) { }
        projection = null
        if (Build.VERSION.SDK_INT >= 29) {
            val uri = outputUri
            if (publish && uri != null) {
                val values = ContentValues().apply { put(MediaStore.Video.Media.IS_PENDING, 0) }
                runCatching { contentResolver.update(uri, values, null, null) }
            } else if (uri != null) runCatching { contentResolver.delete(uri, null, null) }
            outputUri = null
        } else {
            val file = outputFile
            if (publish && file != null) {
                sendBroadcast(Intent(Intent.ACTION_MEDIA_SCANNER_SCAN_FILE, Uri.fromFile(file)))
            } else file?.delete()
            outputFile = null
        }
        paused = false
    }

    private fun pauseRecording() {
        if (!recording || paused) return
        if (Build.VERSION.SDK_INT < 24) { broadcast("Pause needs Android 7 or newer"); return }
        try {
            recorder?.pause()
            paused = true
            updateNotification("Paused • ${elapsedText()}")
            broadcast("Paused")
        } catch (t: Throwable) { broadcast("Could not pause: ${t.message}") }
    }

    private fun resumeRecording() {
        if (!recording || !paused || Build.VERSION.SDK_INT < 24) return
        try {
            recorder?.resume()
            paused = false
            updateNotification("Recording • ${elapsedText()}")
            broadcast("Recording")
        } catch (t: Throwable) { broadcast("Could not resume: ${t.message}") }
    }

    private fun displayMetrics(): DisplayMetrics {
        val result = DisplayMetrics()
        @Suppress("DEPRECATION")
        (getSystemService(WINDOW_SERVICE) as WindowManager).defaultDisplay.getRealMetrics(result)
        return result
    }

    private fun even(value: Int) = value.coerceAtLeast(2) / 2 * 2
    private fun elapsedText(): String {
        val seconds = ((System.currentTimeMillis() - startedAt) / 1000).coerceAtLeast(0)
        return "%02d:%02d".format(Locale.US, seconds / 60, seconds % 60)
    }

    private fun startForegroundCompat(n: Notification) {
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(NOTIFICATION_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION or ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE)
        } else startForeground(NOTIFICATION_ID, n)
    }

    private fun notification(message: String): Notification {
        val open = PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_UPDATE_CURRENT or immutableFlag())
        val builder = if (Build.VERSION.SDK_INT >= 26) Notification.Builder(this, CHANNEL_ID) else {
            @Suppress("DEPRECATION") Notification.Builder(this)
        }
        builder.setSmallIcon(android.R.drawable.presence_video_online)
            .setContentTitle("Lite Recorder").setContentText(message).setContentIntent(open)
            .setOngoing(true).setOnlyAlertOnce(true)
            .addAction(android.R.drawable.ic_media_pause, if (paused) "Resume" else "Pause", serviceIntent(if (paused) ACTION_RESUME else ACTION_PAUSE, 1))
            .addAction(android.R.drawable.ic_menu_close_clear_cancel, "Stop", serviceIntent(ACTION_STOP, 2))
        return builder.build()
    }

    private fun serviceIntent(action: String, request: Int) = PendingIntent.getService(
        this, request, Intent(this, ScreenRecorderService::class.java).setAction(action),
        PendingIntent.FLAG_UPDATE_CURRENT or immutableFlag()
    )
    private fun immutableFlag() = if (Build.VERSION.SDK_INT >= 23) PendingIntent.FLAG_IMMUTABLE else 0
    private fun updateNotification(message: String) = getSystemService(NotificationManager::class.java).notify(NOTIFICATION_ID, notification(message))
    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= 26) getSystemService(NotificationManager::class.java).createNotificationChannel(
            NotificationChannel(CHANNEL_ID, "Screen recording", NotificationManager.IMPORTANCE_LOW)
        )
    }
    private fun broadcast(message: String) {
        sendBroadcast(Intent(ACTION_STATE).setPackage(packageName).putExtra(EXTRA_STATUS, message).putExtra(EXTRA_IS_RECORDING, recording))
    }

    @Suppress("DEPRECATION")
    private fun Intent.getCaptureIntent(): Intent? = if (Build.VERSION.SDK_INT >= 33) getParcelableExtra(EXTRA_RESULT_DATA, Intent::class.java) else getParcelableExtra(EXTRA_RESULT_DATA)

    override fun onDestroy() {
        if (recording) stopRecording()
        handler.removeCallbacksAndMessages(null)
        super.onDestroy()
    }

    companion object {
        const val ACTION_START = "com.example.literecorder.START"
        const val ACTION_STOP = "com.example.literecorder.STOP"
        const val ACTION_PAUSE = "com.example.literecorder.PAUSE"
        const val ACTION_RESUME = "com.example.literecorder.RESUME"
        const val ACTION_STATE = "com.example.literecorder.STATE"
        const val EXTRA_RESULT_CODE = "result_code"
        const val EXTRA_RESULT_DATA = "result_data"
        const val EXTRA_RESOLUTION = "resolution"
        const val EXTRA_FPS = "fps"
        const val EXTRA_STATUS = "status"
        const val EXTRA_IS_RECORDING = "is_recording"
        @Volatile var isRecording = false
            private set
        private const val CHANNEL_ID = "screen_recording"
        private const val NOTIFICATION_ID = 41
    }
}



