@echo off
setlocal EnableExtensions EnableDelayedExpansion
set "APP_HOME=%~dp0"
set "GRADLE_VERSION=8.9"
set "GRADLE_SHA=d725d707bfabd4dfdc958c624003b3c80accc03f7037b5122c4b1d0ef15cecab"
if not defined GRADLE_USER_HOME set "GRADLE_USER_HOME=%USERPROFILE%\.gradle"
set "CACHE_DIR=%GRADLE_USER_HOME%\wrapper\dists\gradle-!GRADLE_VERSION!-bin\lite-screen-recorder"
set "GRADLE_HOME=!CACHE_DIR!\gradle-!GRADLE_VERSION!"
set "GRADLE_BIN=!GRADLE_HOME!\bin\gradle.bat"
if not exist "!GRADLE_BIN!" (
  if not exist "!CACHE_DIR!" mkdir "!CACHE_DIR!"
  set "ZIP_FILE=!CACHE_DIR!\gradle-!GRADLE_VERSION!-bin.zip"
  powershell -NoProfile -ExecutionPolicy Bypass -Command "$ErrorActionPreference='Stop'; $u='https://services.gradle.org/distributions/gradle-!GRADLE_VERSION!-bin.zip'; Invoke-WebRequest -Uri $u -OutFile '!ZIP_FILE!'; $h=(Get-FileHash -Algorithm SHA256 '!ZIP_FILE!').Hash.ToLower(); if ($h -ne '!GRADLE_SHA!') { throw 'Gradle SHA-256 mismatch' }; Expand-Archive -Force '!ZIP_FILE!' '!CACHE_DIR!'"
  if errorlevel 1 exit /b 1
)
if not exist "!GRADLE_BIN!" exit /b 1
"!GRADLE_BIN!" -p "!APP_HOME!" %*
exit /b !ERRORLEVEL!
