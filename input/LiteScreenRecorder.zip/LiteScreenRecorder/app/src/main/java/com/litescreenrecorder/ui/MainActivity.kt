package com.litescreenrecorder.ui

import android.Manifest
import android.app.Activity
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.util.Log
import android.view.View
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.Spinner
import android.widget.TextView
import android.widget.Toast
import com.litescreenrecorder.R
import com.litescreenrecorder.core.RecordingState
import com.litescreenrecorder.data.RecordingSessionStore
import com.litescreenrecorder.data.SettingsStore
import com.litescreenrecorder.recording.MediaStoreRecordingOutput
import com.litescreenrecorder.service.RecordingForegroundService

class MainActivity : Activity() {
    private lateinit var statusText: TextView
    private lateinit var durationText: TextView
    private lateinit var detailsText: TextView
    private lateinit var qualitySpinner: Spinner
    private lateinit var fpsSpinner: Spinner
    private lateinit var startButton: Button
    private lateinit var pauseButton: Button
    private lateinit var stopButton: Button

    private var currentState = RecordingState.IDLE
    private var receiverRegistered = false
    private var pendingStartAfterStoragePermission = false

    private val handler = Handler(Looper.getMainLooper())
    private val durationTicker = object : Runnable {
        override fun run() {
            updateDuration()
            if (currentState == RecordingState.RECORDING) {
                handler.postDelayed(this, 1000L)
            }
        }
    }

    private val stateReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            if (intent?.action != RecordingForegroundService.ACTION_STATE_CHANGED) return
            val stateName = intent.getStringExtra(RecordingForegroundService.EXTRA_STATE)
            currentState = RecordingState.fromStoredValue(stateName)
            val message = intent.getStringExtra(RecordingForegroundService.EXTRA_MESSAGE)
            renderState()
            if (!message.isNullOrBlank()) {
                Toast.makeText(this@MainActivity, message, Toast.LENGTH_LONG).show()
                detailsText.text = message
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        bindViews()
        setupSpinners()
        setupButtons()

        if (!RecordingForegroundService.isRunning) recoverInterruptedSession()
        currentState = RecordingSessionStore.state(this)
        renderState()
        requestNotificationPermissionIfNeeded()
    }

    override fun onStart() {
        super.onStart()
        val filter = IntentFilter(RecordingForegroundService.ACTION_STATE_CHANGED)
        if (Build.VERSION.SDK_INT >= 33) {
            registerReceiver(stateReceiver, filter, Context.RECEIVER_NOT_EXPORTED)
        } else {
            @Suppress("DEPRECATION")
            registerReceiver(stateReceiver, filter)
        }
        receiverRegistered = true
        currentState = RecordingSessionStore.state(this)
        renderState()
    }

    override fun onStop() {
        handler.removeCallbacks(durationTicker)
        if (receiverRegistered) {
            unregisterReceiver(stateReceiver)
            receiverRegistered = false
        }
        super.onStop()
    }

    private fun bindViews() {
        statusText = findViewById(R.id.statusText)
        durationText = findViewById(R.id.durationText)
        detailsText = findViewById(R.id.detailsText)
        qualitySpinner = findViewById(R.id.qualitySpinner)
        fpsSpinner = findViewById(R.id.fpsSpinner)
        startButton = findViewById(R.id.startButton)
        pauseButton = findViewById(R.id.pauseButton)
        stopButton = findViewById(R.id.stopButton)
    }

    private fun setupSpinners() {
        val qualityLabels = resources.getStringArray(R.array.quality_options)
        qualitySpinner.adapter = ArrayAdapter(
            this,
            android.R.layout.simple_spinner_item,
            qualityLabels
        ).also { it.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item) }
        qualitySpinner.setSelection(SettingsStore.quality(this).ordinal)
        qualitySpinner.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
                SettingsStore.saveQuality(this@MainActivity, SettingsStore.QualityPreset.entries[position])
            }
            override fun onNothingSelected(parent: AdapterView<*>?) = Unit
        }

        val fpsLabels = resources.getStringArray(R.array.fps_options)
        fpsSpinner.adapter = ArrayAdapter(
            this,
            android.R.layout.simple_spinner_item,
            fpsLabels
        ).also { it.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item) }
        fpsSpinner.setSelection(listOf(15, 24, 30).indexOf(SettingsStore.fps(this)).coerceAtLeast(0))
        fpsSpinner.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
                SettingsStore.saveFps(this@MainActivity, listOf(15, 24, 30)[position])
            }
            override fun onNothingSelected(parent: AdapterView<*>?) = Unit
        }
    }

    private fun setupButtons() {
        startButton.setOnClickListener { requestStartRecording() }
        pauseButton.setOnClickListener {
            when (currentState) {
                RecordingState.RECORDING -> sendServiceAction(RecordingForegroundService.ACTION_PAUSE)
                RecordingState.PAUSED -> sendServiceAction(RecordingForegroundService.ACTION_RESUME)
                else -> Unit
            }
        }
        stopButton.setOnClickListener {
            if (currentState != RecordingState.IDLE) {
                sendServiceAction(RecordingForegroundService.ACTION_STOP)
            }
        }
    }

    private fun requestStartRecording() {
        if (currentState != RecordingState.IDLE) return
        if (Build.VERSION.SDK_INT <= 28 &&
            checkSelfPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED
        ) {
            pendingStartAfterStoragePermission = true
            requestPermissions(
                arrayOf(Manifest.permission.WRITE_EXTERNAL_STORAGE),
                REQUEST_STORAGE_PERMISSION
            )
            return
        }
        launchProjectionConsent()
    }

    @Suppress("DEPRECATION")
    private fun launchProjectionConsent() {
        try {
            val manager = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
            startActivityForResult(manager.createScreenCaptureIntent(), REQUEST_SCREEN_CAPTURE)
        } catch (error: Exception) {
            Log.e(TAG, "Unable to request screen capture consent", error)
            Toast.makeText(this, "تعذر طلب إذن تسجيل الشاشة.", Toast.LENGTH_LONG).show()
        }
    }

    @Suppress("DEPRECATION")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != REQUEST_SCREEN_CAPTURE) return
        if (resultCode != RESULT_OK || data == null) {
            Log.w(TAG, "Screen capture permission denied or canceled")
            detailsText.text = getString(R.string.permission_denied)
            Toast.makeText(this, R.string.permission_denied, Toast.LENGTH_LONG).show()
            return
        }

        Log.i(TAG, "Screen capture permission granted")
        currentState = RecordingState.PREPARING
        renderState()
        val serviceIntent = Intent(this, RecordingForegroundService::class.java)
            .setAction(RecordingForegroundService.ACTION_START)
            .putExtra(RecordingForegroundService.EXTRA_RESULT_CODE, resultCode)
            .putExtra(RecordingForegroundService.EXTRA_RESULT_DATA, data)
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                startForegroundService(serviceIntent)
            } else {
                startService(serviceIntent)
            }
        } catch (error: Exception) {
            Log.e(TAG, "Could not start foreground recording service", error)
            currentState = RecordingState.IDLE
            renderState()
            Toast.makeText(this, "تعذر تشغيل خدمة التسجيل: ${error.message}", Toast.LENGTH_LONG).show()
        }
    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        when (requestCode) {
            REQUEST_STORAGE_PERMISSION -> {
                val shouldContinue = pendingStartAfterStoragePermission
                pendingStartAfterStoragePermission = false
                if (shouldContinue && grantResults.firstOrNull() == PackageManager.PERMISSION_GRANTED) {
                    Log.i(TAG, "Legacy storage permission granted")
                    launchProjectionConsent()
                } else if (shouldContinue) {
                    Log.w(TAG, "Legacy storage permission denied")
                    Toast.makeText(this, R.string.storage_permission_denied, Toast.LENGTH_LONG).show()
                }
            }
            REQUEST_NOTIFICATION_PERMISSION -> {
                if (grantResults.firstOrNull() != PackageManager.PERMISSION_GRANTED) {
                    Log.w(TAG, "Notification permission denied")
                    detailsText.text = getString(R.string.notification_permission_denied)
                } else {
                    Log.i(TAG, "Notification permission granted")
                }
            }
        }
    }

    private fun requestNotificationPermissionIfNeeded() {
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            requestPermissions(
                arrayOf(Manifest.permission.POST_NOTIFICATIONS),
                REQUEST_NOTIFICATION_PERMISSION
            )
        }
    }

    private fun sendServiceAction(action: String) {
        val command = Intent(this, RecordingForegroundService::class.java).setAction(action)
        try {
            startService(command)
        } catch (error: Exception) {
            Log.e(TAG, "Unable to send recording service action=$action", error)
            Toast.makeText(this, "تعذر تنفيذ أمر التسجيل.", Toast.LENGTH_LONG).show()
        }
    }

    private fun renderState() {
        val busy = currentState != RecordingState.IDLE
        startButton.isEnabled = !busy
        qualitySpinner.isEnabled = !busy
        fpsSpinner.isEnabled = !busy
        pauseButton.isEnabled = currentState == RecordingState.RECORDING || currentState == RecordingState.PAUSED
        stopButton.isEnabled = busy
        pauseButton.text = if (currentState == RecordingState.PAUSED) {
            getString(R.string.action_resume)
        } else {
            getString(R.string.action_pause)
        }

        statusText.text = when (currentState) {
            RecordingState.IDLE -> getString(R.string.status_idle)
            RecordingState.PREPARING -> getString(R.string.status_preparing)
            RecordingState.RECORDING -> getString(R.string.status_recording)
            RecordingState.PAUSED -> getString(R.string.status_paused)
            RecordingState.STOPPING -> getString(R.string.status_stopping)
        }
        detailsText.text = getString(
            when (currentState) {
                RecordingState.IDLE -> R.string.save_location
                RecordingState.PREPARING -> R.string.detail_preparing
                RecordingState.RECORDING -> R.string.detail_recording
                RecordingState.PAUSED -> R.string.detail_paused
                RecordingState.STOPPING -> R.string.detail_stopping
            }
        )
        updateDuration()
        handler.removeCallbacks(durationTicker)
        if (currentState == RecordingState.RECORDING) handler.post(durationTicker)
    }

    private fun updateDuration() {
        durationText.text = getString(
            R.string.duration_value,
            formatDuration(RecordingSessionStore.elapsedMillis(this))
        )
    }

    private fun recoverInterruptedSession() {
        val staleUri = RecordingSessionStore.outputUri(this)
        if (staleUri != null) {
            Log.w(TAG, "Removing incomplete recording left by a terminated service: $staleUri")
            MediaStoreRecordingOutput.delete(this, staleUri)
        }
        if (RecordingSessionStore.state(this) != RecordingState.IDLE || staleUri != null) {
            RecordingSessionStore.markIdle(this, 0L)
        }
    }

    private fun formatDuration(durationMillis: Long): String {
        val secondsTotal = (durationMillis.coerceAtLeast(0L) / 1000L).toInt()
        val hours = secondsTotal / 3600
        val minutes = (secondsTotal % 3600) / 60
        val seconds = secondsTotal % 60
        return if (hours > 0) {
            String.format("%02d:%02d:%02d", hours, minutes, seconds)
        } else {
            String.format("%02d:%02d", minutes, seconds)
        }
    }

    companion object {
        private const val TAG = "LiteScreenRecorder"
        private const val REQUEST_SCREEN_CAPTURE = 2001
        private const val REQUEST_STORAGE_PERMISSION = 2002
        private const val REQUEST_NOTIFICATION_PERMISSION = 2003
    }
}
