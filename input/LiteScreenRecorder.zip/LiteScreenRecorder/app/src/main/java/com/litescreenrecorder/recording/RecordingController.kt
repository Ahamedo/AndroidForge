package com.litescreenrecorder.recording

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.MediaRecorder
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.util.Log
import android.view.Display
import android.view.Surface
import com.litescreenrecorder.data.RecordingSessionStore
import com.litescreenrecorder.data.SettingsStore
import java.io.IOException

class RecordingController(
    private val context: Context,
    private val listener: Listener
) {
    interface Listener {
        fun onProjectionStopped()
        fun onEncoderError(message: String)
        fun onDisplayRotationChanged()
    }

    private val mainHandler = Handler(Looper.getMainLooper())
    private var projection: MediaProjection? = null
    private var projectionCallback: MediaProjection.Callback? = null
    private var virtualDisplay: VirtualDisplay? = null
    private var mediaRecorder: MediaRecorder? = null
    private var outputDescriptor: android.os.ParcelFileDescriptor? = null
    private var outputUri: Uri? = null
    private var displayManager: DisplayManager? = null
    private var displayListener: DisplayManager.DisplayListener? = null
    private var initialScreenMetrics: ScreenMetrics? = null
    private var recordingStarted = false
    private var stopping = false

    @Throws(Exception::class)
    fun start(resultCode: Int, permissionData: Intent) {
        try {
            if (resultCode != Activity.RESULT_OK) {
                throw SecurityException("لم يتم منح إذن التقاط الشاشة.")
            }

            MediaStoreRecordingOutput.ensureStorageAvailable()
            val projectionManager = context.getSystemService(Context.MEDIA_PROJECTION_SERVICE)
                    as MediaProjectionManager
            val newProjection = projectionManager.getMediaProjection(resultCode, permissionData)
                ?: throw SecurityException("تعذر الحصول على صلاحية التقاط الشاشة.")
            projection = newProjection

            val callback = object : MediaProjection.Callback() {
                override fun onStop() {
                    Log.w(TAG, "MediaProjection stopped by the system or user")
                    if (!stopping) listener.onProjectionStopped()
                }
            }
            projectionCallback = callback
            newProjection.registerCallback(callback, mainHandler)

            val quality = SettingsStore.quality(context)
            val requestedFps = SettingsStore.fps(context)
            val configuration = EncoderConfigurationResolver.resolve(context, quality, requestedFps)
            initialScreenMetrics = configuration.screenMetrics

            Log.i(
                TAG,
                "Preparing capture ${configuration.width}x${configuration.height} " +
                    "at ${configuration.frameRate} FPS, bitrate=${configuration.bitRate}"
            )

            val uri = MediaStoreRecordingOutput.create(context)
            outputUri = uri
            RecordingSessionStore.saveOutputUri(context, uri)

            val descriptor = context.contentResolver.openFileDescriptor(uri, "w")
                ?: throw IOException("تعذر فتح ملف الفيديو للكتابة.")
            outputDescriptor = descriptor

            @Suppress("DEPRECATION")
            val recorder = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                MediaRecorder(context)
            } else {
                MediaRecorder()
            }
            mediaRecorder = recorder
            recorder.setOnErrorListener { _, what, extra ->
                Log.e(TAG, "MediaRecorder error: what=$what extra=$extra")
                if (!stopping) {
                    listener.onEncoderError("خطأ في مُرمّز الفيديو (رمز $what/$extra).")
                }
            }
            recorder.setOnInfoListener { _, what, extra ->
                Log.i(TAG, "MediaRecorder info: what=$what extra=$extra")
            }
            recorder.setVideoSource(MediaRecorder.VideoSource.SURFACE)
            recorder.setOutputFormat(MediaRecorder.OutputFormat.MPEG_4)
            recorder.setVideoEncoder(MediaRecorder.VideoEncoder.H264)
            recorder.setVideoSize(configuration.width, configuration.height)
            recorder.setVideoFrameRate(configuration.frameRate)
            recorder.setVideoEncodingBitRate(configuration.bitRate)
            recorder.setOutputFile(descriptor.fileDescriptor)
            recorder.prepare()

            val surface: Surface = recorder.surface
            val virtual = newProjection.createVirtualDisplay(
                "LiteScreenRecorderDisplay",
                configuration.width,
                configuration.height,
                configuration.screenMetrics.densityDpi,
                DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
                surface,
                null,
                mainHandler
            ) ?: throw IOException("تعذر إنشاء شاشة الالتقاط الافتراضية.")
            virtualDisplay = virtual

            recorder.start()
            recordingStarted = true
            registerRotationListener()
            Log.i(TAG, "Recording pipeline started; encoder candidate=${configuration.encoderName}")
        } catch (error: Exception) {
            Log.e(TAG, "Recording pipeline initialization failed", error)
            abort()
            throw error
        }
    }

    fun pause() {
        val recorder = mediaRecorder ?: throw IllegalStateException("المسجل غير جاهز.")
        recorder.pause()
        Log.i(TAG, "Recorder paused")
    }

    fun resume() {
        val recorder = mediaRecorder ?: throw IllegalStateException("المسجل غير جاهز.")
        recorder.resume()
        Log.i(TAG, "Recorder resumed")
    }

    fun stopAndFinalize(): Boolean {
        if (stopping) return false
        stopping = true
        var outputIsValid = recordingStarted

        if (recordingStarted) {
            try {
                mediaRecorder?.stop()
            } catch (error: RuntimeException) {
                outputIsValid = false
                Log.e(TAG, "MediaRecorder.stop failed; output will be discarded", error)
            }
        }

        releaseRecordingResources()
        val uri = outputUri
        if (outputIsValid && uri != null) {
            try {
                MediaStoreRecordingOutput.finalizeOutput(context, uri)
                Log.i(TAG, "Recording finalized: $uri")
            } catch (error: Exception) {
                outputIsValid = false
                Log.e(TAG, "Could not finalize MediaStore output", error)
            }
        } else {
            Log.w(TAG, "Discarding incomplete recording output")
        }

        if (!outputIsValid) MediaStoreRecordingOutput.delete(context, uri)
        outputUri = null
        recordingStarted = false
        return outputIsValid
    }

    fun abort() {
        if (stopping) return
        stopping = true
        releaseRecordingResources()
        MediaStoreRecordingOutput.delete(context, outputUri)
        outputUri = null
        recordingStarted = false
        Log.i(TAG, "Recording resources released after abort")
    }

    private fun registerRotationListener() {
        val manager = context.getSystemService(Context.DISPLAY_SERVICE) as DisplayManager
        val original = initialScreenMetrics ?: return
        val listener = object : DisplayManager.DisplayListener {
            override fun onDisplayAdded(displayId: Int) = Unit
            override fun onDisplayRemoved(displayId: Int) = Unit
            override fun onDisplayChanged(displayId: Int) {
                if (displayId != Display.DEFAULT_DISPLAY || stopping) return
                val current = ScreenMetrics.read(context)
                if (current.widthPixels != original.widthPixels ||
                    current.heightPixels != original.heightPixels ||
                    current.rotation != original.rotation
                ) {
                    Log.w(TAG, "Display dimensions changed; stopping to preserve MP4 integrity")
                    this@RecordingController.listener.onDisplayRotationChanged()
                }
            }
        }
        displayManager = manager
        displayListener = listener
        manager.registerDisplayListener(listener, mainHandler)
    }

    private fun releaseRecordingResources() {
        val manager = displayManager
        val listener = displayListener
        if (manager != null && listener != null) {
            runCatching { manager.unregisterDisplayListener(listener) }
        }
        displayListener = null
        displayManager = null

        runCatching { virtualDisplay?.release() }
        virtualDisplay = null

        runCatching { mediaRecorder?.setOnErrorListener(null) }
        runCatching { mediaRecorder?.setOnInfoListener(null) }
        runCatching { mediaRecorder?.release() }
        mediaRecorder = null

        runCatching { outputDescriptor?.close() }
        outputDescriptor = null

        val currentProjection = projection
        val callback = projectionCallback
        if (currentProjection != null && callback != null) {
            runCatching { currentProjection.unregisterCallback(callback) }
        }
        projectionCallback = null
        projection = null
        if (currentProjection != null) {
            runCatching { currentProjection.stop() }
        }
        initialScreenMetrics = null
        Log.i(TAG, "Capture resources released")
    }

    companion object {
        private const val TAG = "LiteScreenRecorder"
    }
}
