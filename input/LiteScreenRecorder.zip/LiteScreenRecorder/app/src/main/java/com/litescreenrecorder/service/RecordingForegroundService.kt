package com.litescreenrecorder.service

import android.app.Activity
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder
import android.util.Log
import com.litescreenrecorder.core.RecordingState
import com.litescreenrecorder.data.RecordingSessionStore
import com.litescreenrecorder.recording.RecordingController

class RecordingForegroundService : Service() {
    private var controller: RecordingController? = null
    private var currentState = RecordingState.IDLE
    private var finishing = false
    private var latestStartId = 0

    override fun onCreate() {
        super.onCreate()
        isRunning = true
        RecordingNotification.createChannel(this)
        Log.i(TAG, "Foreground recording service created")
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        latestStartId = startId
        when (intent?.action) {
            ACTION_START -> startRecording(intent)
            ACTION_PAUSE -> {
                if (currentState == RecordingState.IDLE) stopSelfResult(startId) else pauseRecording()
            }
            ACTION_RESUME -> {
                if (currentState == RecordingState.IDLE) stopSelfResult(startId) else resumeRecording()
            }
            ACTION_STOP -> {
                if (currentState == RecordingState.IDLE) stopSelfResult(startId) else finishRecording(null)
            }
            else -> Log.w(TAG, "Ignoring service command without a recognized action")
        }
        return START_NOT_STICKY
    }

    private fun startRecording(intent: Intent) {
        if (controller != null || currentState != RecordingState.IDLE) {
            Log.w(TAG, "Ignoring duplicate start command")
            return
        }

        RecordingSessionStore.beginPreparing(this)
        currentState = RecordingState.PREPARING
        try {
            startForegroundCompat(
                RecordingNotification.build(this, currentState, 0L)
            )
        } catch (error: Exception) {
            Log.e(TAG, "Unable to enter media-projection foreground state", error)
            finishStartupFailure(error.message ?: "تعذر تشغيل خدمة التسجيل الأمامية.")
            return
        }
        publishState()

        val resultCode = intent.getIntExtra(EXTRA_RESULT_CODE, Activity.RESULT_CANCELED)
        val permissionData = getPermissionData(intent)
        if (resultCode != Activity.RESULT_OK || permissionData == null) {
            finishStartupFailure("لم يصل إذن التقاط الشاشة إلى خدمة التسجيل.")
            return
        }

        val engine = RecordingController(this, object : RecordingController.Listener {
            override fun onProjectionStopped() {
                finishRecording("تم إيقاف مشاركة الشاشة بواسطة النظام أو المستخدم.")
            }

            override fun onEncoderError(message: String) {
                finishRecording("تعذّر إكمال التسجيل: $message")
            }

            override fun onDisplayRotationChanged() {
                finishRecording("تغير اتجاه الشاشة؛ تم إنهاء التسجيل لحفظ ملف MP4 سليم.")
            }
        })
        controller = engine

        try {
            engine.start(resultCode, permissionData)
            RecordingSessionStore.markRecording(this)
            transitionTo(RecordingState.RECORDING)
            Log.i(TAG, "Recording started")
        } catch (error: Exception) {
            Log.e(TAG, "Unable to start recording", error)
            engine.abort()
            controller = null
            finishStartupFailure(error.message ?: "حدث خطأ أثناء بدء التسجيل.")
        }
    }

    private fun pauseRecording() {
        if (currentState != RecordingState.RECORDING) return
        try {
            controller?.pause() ?: throw IllegalStateException("جلسة التسجيل غير متاحة.")
            RecordingSessionStore.markPaused(this)
            transitionTo(RecordingState.PAUSED)
            Log.i(TAG, "Recording paused")
        } catch (error: Exception) {
            Log.e(TAG, "Pause failed", error)
            finishRecording("تعذر إيقاف التسجيل مؤقتًا: ${error.message ?: "خطأ غير معروف"}")
        }
    }

    private fun resumeRecording() {
        if (currentState != RecordingState.PAUSED) return
        try {
            controller?.resume() ?: throw IllegalStateException("جلسة التسجيل غير متاحة.")
            RecordingSessionStore.markRecording(this)
            transitionTo(RecordingState.RECORDING)
            Log.i(TAG, "Recording resumed")
        } catch (error: Exception) {
            Log.e(TAG, "Resume failed", error)
            finishRecording("تعذر استئناف التسجيل: ${error.message ?: "خطأ غير معروف"}")
        }
    }

    private fun finishRecording(message: String?) {
        if (finishing || currentState == RecordingState.IDLE || currentState == RecordingState.STOPPING) return
        finishing = true
        val elapsed = RecordingSessionStore.elapsedMillis(this)
        currentState = RecordingState.STOPPING
        RecordingSessionStore.markStopping(this, elapsed)
        transitionTo(RecordingState.STOPPING)
        Log.i(TAG, "Stopping recording session")

        val completed = runCatching { controller?.stopAndFinalize() ?: false }
            .onFailure { Log.e(TAG, "Stop/finalization failed", it) }
            .getOrDefault(false)
        controller = null
        RecordingSessionStore.markIdle(this, elapsed)
        currentState = RecordingState.IDLE

        val finalMessage = when {
            !completed && message.isNullOrBlank() -> "تعذر حفظ التسجيل؛ تم حذف الملف غير المكتمل."
            !completed -> "$message تعذر اعتماد الملف النهائي وتم حذف الملف غير المكتمل."
            else -> message ?: "تم حفظ التسجيل في Movies/LiteScreenRecorder/."
        }
        publishState(finalMessage)
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelfResult(latestStartId)
        Log.i(TAG, "Recording service session finished; saved=$completed")
        finishing = false
    }

    private fun finishStartupFailure(message: String) {
        controller?.abort()
        controller = null
        RecordingSessionStore.markIdle(this, 0L)
        currentState = RecordingState.IDLE
        publishState(message)
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelfResult(latestStartId)
        Log.e(TAG, "Recording startup failed: $message")
    }

    private fun transitionTo(state: RecordingState) {
        currentState = state
        publishState()
        if (state == RecordingState.IDLE) {
            stopForeground(STOP_FOREGROUND_REMOVE)
        } else {
            val notification = RecordingNotification.build(
                this,
                state,
                RecordingSessionStore.elapsedMillis(this)
            )
            getSystemService(android.app.NotificationManager::class.java)
                .notify(RecordingNotification.NOTIFICATION_ID, notification)
        }
    }

    private fun publishState(message: String? = null) {
        val broadcast = Intent(ACTION_STATE_CHANGED)
            .setPackage(packageName)
            .putExtra(EXTRA_STATE, currentState.name)
            .putExtra(EXTRA_ELAPSED, RecordingSessionStore.elapsedMillis(this))
        if (!message.isNullOrBlank()) broadcast.putExtra(EXTRA_MESSAGE, message)
        sendBroadcast(broadcast)
    }

    private fun startForegroundCompat(notification: android.app.Notification) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            startForeground(
                RecordingNotification.NOTIFICATION_ID,
                notification,
                ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION
            )
        } else {
            startForeground(RecordingNotification.NOTIFICATION_ID, notification)
        }
    }

    @Suppress("DEPRECATION")
    private fun getPermissionData(intent: Intent): Intent? =
        if (Build.VERSION.SDK_INT >= 33) {
            intent.getParcelableExtra(EXTRA_RESULT_DATA, Intent::class.java)
        } else {
            intent.getParcelableExtra(EXTRA_RESULT_DATA)
        }

    override fun onDestroy() {
        if (controller != null) {
            Log.w(TAG, "Service destroyed while a recording controller was active")
            val elapsed = RecordingSessionStore.elapsedMillis(this)
            currentState = RecordingState.STOPPING
            RecordingSessionStore.markStopping(this, elapsed)
            publishState()
            val saved = runCatching { controller?.stopAndFinalize() ?: false }
                .onFailure { Log.e(TAG, "Cleanup on service destruction failed", it) }
                .getOrDefault(false)
            controller = null
            RecordingSessionStore.markIdle(this, elapsed)
            currentState = RecordingState.IDLE
            publishState(
                if (saved) "تم حفظ التسجيل بعد إنهاء الخدمة."
                else "انتهت الخدمة وتم حذف ملف التسجيل غير المكتمل."
            )
            runCatching { stopForeground(STOP_FOREGROUND_REMOVE) }
        }
        isRunning = false
        Log.i(TAG, "Foreground recording service destroyed")
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    companion object {
        const val ACTION_START = "com.litescreenrecorder.action.START"
        const val ACTION_PAUSE = "com.litescreenrecorder.action.PAUSE"
        const val ACTION_RESUME = "com.litescreenrecorder.action.RESUME"
        const val ACTION_STOP = "com.litescreenrecorder.action.STOP"
        const val ACTION_STATE_CHANGED = "com.litescreenrecorder.action.STATE_CHANGED"

        const val EXTRA_RESULT_CODE = "result_code"
        const val EXTRA_RESULT_DATA = "result_data"
        const val EXTRA_STATE = "state"
        const val EXTRA_ELAPSED = "elapsed"
        const val EXTRA_MESSAGE = "message"

        @Volatile
        var isRunning: Boolean = false
            private set

        private const val TAG = "LiteScreenRecorder"
    }
}
