package com.litescreenrecorder.data

import android.content.Context
import android.net.Uri
import android.os.SystemClock
import com.litescreenrecorder.core.RecordingState

object RecordingSessionStore {
    private const val PREFS_NAME = "lite_recorder_session"
    private const val KEY_STATE = "state"
    private const val KEY_ELAPSED = "elapsed_ms"
    private const val KEY_STARTED_AT = "started_at_elapsed"
    private const val KEY_OUTPUT_URI = "output_uri"

    fun state(context: Context): RecordingState =
        prefs(context).getString(KEY_STATE, RecordingState.IDLE.name)
            .let { RecordingState.fromStoredValue(it) }

    fun beginPreparing(context: Context) {
        prefs(context).edit()
            .putString(KEY_STATE, RecordingState.PREPARING.name)
            .putLong(KEY_ELAPSED, 0L)
            .putLong(KEY_STARTED_AT, 0L)
            .remove(KEY_OUTPUT_URI)
            .commit()
    }

    fun markRecording(context: Context) {
        prefs(context).edit()
            .putString(KEY_STATE, RecordingState.RECORDING.name)
            .putLong(KEY_STARTED_AT, SystemClock.elapsedRealtime())
            .apply()
    }

    fun markPaused(context: Context) {
        val elapsed = elapsedMillis(context)
        prefs(context).edit()
            .putString(KEY_STATE, RecordingState.PAUSED.name)
            .putLong(KEY_ELAPSED, elapsed)
            .putLong(KEY_STARTED_AT, 0L)
            .apply()
    }

    fun markStopping(context: Context, elapsedMillis: Long) {
        prefs(context).edit()
            .putString(KEY_STATE, RecordingState.STOPPING.name)
            .putLong(KEY_ELAPSED, elapsedMillis.coerceAtLeast(0L))
            .putLong(KEY_STARTED_AT, 0L)
            .apply()
    }

    fun markIdle(context: Context, finalElapsedMillis: Long) {
        prefs(context).edit()
            .putString(KEY_STATE, RecordingState.IDLE.name)
            .putLong(KEY_ELAPSED, finalElapsedMillis.coerceAtLeast(0L))
            .putLong(KEY_STARTED_AT, 0L)
            .remove(KEY_OUTPUT_URI)
            .commit()
    }

    fun elapsedMillis(context: Context): Long {
        val preferences = prefs(context)
        val base = preferences.getLong(KEY_ELAPSED, 0L)
        return if (state(context) == RecordingState.RECORDING) {
            val startedAt = preferences.getLong(KEY_STARTED_AT, 0L)
            base + (SystemClock.elapsedRealtime() - startedAt).coerceAtLeast(0L)
        } else {
            base
        }
    }

    fun saveOutputUri(context: Context, uri: Uri) {
        prefs(context).edit().putString(KEY_OUTPUT_URI, uri.toString()).commit()
    }

    fun outputUri(context: Context): Uri? =
        prefs(context).getString(KEY_OUTPUT_URI, null)?.let(Uri::parse)

    private fun prefs(context: Context) =
        context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
}
