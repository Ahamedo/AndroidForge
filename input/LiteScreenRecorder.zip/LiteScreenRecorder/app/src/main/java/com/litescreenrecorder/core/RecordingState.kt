package com.litescreenrecorder.core

enum class RecordingState {
    IDLE,
    PREPARING,
    RECORDING,
    PAUSED,
    STOPPING;

    companion object {
        fun fromStoredValue(value: String?): RecordingState =
            entries.firstOrNull { it.name == value } ?: IDLE
    }
}
