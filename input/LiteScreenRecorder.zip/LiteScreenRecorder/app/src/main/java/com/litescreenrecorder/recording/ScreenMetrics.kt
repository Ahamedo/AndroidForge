package com.litescreenrecorder.recording

import android.content.Context
import android.util.DisplayMetrics
import android.view.WindowManager

data class ScreenMetrics(
    val widthPixels: Int,
    val heightPixels: Int,
    val densityDpi: Int,
    val rotation: Int
) {
    companion object {
        @Suppress("DEPRECATION")
        fun read(context: Context): ScreenMetrics {
            val metrics = DisplayMetrics()
            val windowManager = context.getSystemService(Context.WINDOW_SERVICE) as WindowManager
            val display = windowManager.defaultDisplay
            display.getRealMetrics(metrics)
            return ScreenMetrics(
                widthPixels = metrics.widthPixels.coerceAtLeast(1),
                heightPixels = metrics.heightPixels.coerceAtLeast(1),
                densityDpi = metrics.densityDpi.coerceAtLeast(1),
                rotation = display.rotation
            )
        }
    }
}
