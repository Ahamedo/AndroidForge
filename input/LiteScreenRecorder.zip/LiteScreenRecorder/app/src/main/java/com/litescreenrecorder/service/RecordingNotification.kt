package com.litescreenrecorder.service

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.SystemClock
import com.litescreenrecorder.R
import com.litescreenrecorder.core.RecordingState
import com.litescreenrecorder.ui.MainActivity

object RecordingNotification {
    const val CHANNEL_ID = "lite_screen_recording"
    const val NOTIFICATION_ID = 4107

    fun createChannel(context: Context) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                context.getString(R.string.notification_channel_name),
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = context.getString(R.string.notification_channel_description)
                setShowBadge(false)
            }
            context.getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
    }

    fun build(
        context: Context,
        state: RecordingState,
        elapsedMillis: Long
    ): Notification {
        val contentIntent = PendingIntent.getActivity(
            context,
            100,
            Intent(context, MainActivity::class.java).apply {
                flags = Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP
            },
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val builder = Notification.Builder(context, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_stat_recorder)
            .setContentTitle(context.getString(R.string.app_name))
            .setContentIntent(contentIntent)
            .setCategory(Notification.CATEGORY_SERVICE)
            .setOnlyAlertOnce(true)
            .setOngoing(state != RecordingState.IDLE)
            .setVisibility(Notification.VISIBILITY_PUBLIC)
            .setShowWhen(true)

        when (state) {
            RecordingState.RECORDING -> {
                builder.setContentText(context.getString(R.string.notification_recording))
                    .setWhen(SystemClock.elapsedRealtime() - elapsedMillis.coerceAtLeast(0L))
                    .setUsesChronometer(true)
                    .addAction(
                        R.drawable.ic_stat_recorder,
                        context.getString(R.string.action_pause),
                        servicePendingIntent(context, RecordingForegroundService.ACTION_PAUSE, 102)
                    )
                    .addAction(
                        R.drawable.ic_stat_recorder,
                        context.getString(R.string.action_stop),
                        servicePendingIntent(context, RecordingForegroundService.ACTION_STOP, 104)
                    )
            }
            RecordingState.PAUSED -> {
                builder.setContentText(
                    context.getString(R.string.notification_paused, formatDuration(elapsedMillis))
                ).setUsesChronometer(false)
                    .addAction(
                        R.drawable.ic_stat_recorder,
                        context.getString(R.string.action_resume),
                        servicePendingIntent(context, RecordingForegroundService.ACTION_RESUME, 103)
                    )
                    .addAction(
                        R.drawable.ic_stat_recorder,
                        context.getString(R.string.action_stop),
                        servicePendingIntent(context, RecordingForegroundService.ACTION_STOP, 104)
                    )
            }
            RecordingState.PREPARING -> {
                builder.setContentText(context.getString(R.string.notification_preparing))
                    .addAction(
                        R.drawable.ic_stat_recorder,
                        context.getString(R.string.action_cancel),
                        servicePendingIntent(context, RecordingForegroundService.ACTION_STOP, 104)
                    )
            }
            RecordingState.STOPPING -> {
                builder.setContentText(context.getString(R.string.notification_saving))
            }
            RecordingState.IDLE -> {
                builder.setContentText(context.getString(R.string.notification_idle))
            }
        }
        return builder.build()
    }

    private fun servicePendingIntent(context: Context, action: String, requestCode: Int): PendingIntent {
        val intent = Intent(context, RecordingForegroundService::class.java).setAction(action)
        return PendingIntent.getService(
            context,
            requestCode,
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
    }

    private fun formatDuration(durationMillis: Long): String {
        val totalSeconds = (durationMillis.coerceAtLeast(0L) / 1000L).toInt()
        val hours = totalSeconds / 3600
        val minutes = (totalSeconds % 3600) / 60
        val seconds = totalSeconds % 60
        return if (hours > 0) {
            String.format("%02d:%02d:%02d", hours, minutes, seconds)
        } else {
            String.format("%02d:%02d", minutes, seconds)
        }
    }
}
