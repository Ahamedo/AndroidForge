package com.litescreenrecorder.data

import android.content.Context

object SettingsStore {
    private const val PREFS_NAME = "lite_recorder_settings"
    private const val KEY_QUALITY = "quality"
    private const val KEY_FPS = "fps"

    enum class QualityPreset(
        val storedValue: String,
        val shortEdgePixels: Int,
        val bitRate: Int
    ) {
        LOW("low", 480, 1_500_000),
        MEDIUM("medium", 720, 4_000_000),
        HIGH("high", 1080, 7_000_000);

        companion object {
            fun fromStoredValue(value: String?): QualityPreset =
                entries.firstOrNull { it.storedValue == value } ?: LOW
        }
    }

    fun quality(context: Context): QualityPreset =
        preferences(context).getString(KEY_QUALITY, QualityPreset.LOW.storedValue)
            .let { QualityPreset.fromStoredValue(it) }

    fun saveQuality(context: Context, quality: QualityPreset) {
        preferences(context).edit().putString(KEY_QUALITY, quality.storedValue).apply()
    }

    fun fps(context: Context): Int =
        preferences(context).getInt(KEY_FPS, 15).let { value ->
            if (value in listOf(15, 24, 30)) value else 15
        }

    fun saveFps(context: Context, fps: Int) {
        if (fps in listOf(15, 24, 30)) {
            preferences(context).edit().putInt(KEY_FPS, fps).apply()
        }
    }

    private fun preferences(context: Context) =
        context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
}
