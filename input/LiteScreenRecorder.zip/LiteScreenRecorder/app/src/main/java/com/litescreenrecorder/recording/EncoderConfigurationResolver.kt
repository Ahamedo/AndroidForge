package com.litescreenrecorder.recording

import android.media.MediaCodecList
import android.os.Build
import android.util.Log
import android.content.Context
import com.litescreenrecorder.data.SettingsStore.QualityPreset
import kotlin.math.roundToInt

data class CaptureConfiguration(
    val width: Int,
    val height: Int,
    val frameRate: Int,
    val bitRate: Int,
    val encoderName: String,
    val screenMetrics: ScreenMetrics
)

object EncoderConfigurationResolver {
    private const val TAG = "LiteScreenRecorder"
    private const val MIME_AVC = "video/avc"

    fun resolve(
        context: Context,
        quality: QualityPreset,
        requestedFrameRate: Int
    ): CaptureConfiguration {
        require(requestedFrameRate in listOf(15, 24, 30)) { "Unsupported requested FPS" }

        val screen = ScreenMetrics.read(context)
        val portrait = screen.heightPixels >= screen.widthPixels
        val targetShortEdge = quality.shortEdgePixels
        val aspect = screen.widthPixels.toDouble() / screen.heightPixels.toDouble()
        val targetWidth: Int
        val targetHeight: Int
        if (portrait) {
            targetWidth = targetShortEdge
            targetHeight = (targetShortEdge / aspect).roundToInt()
        } else {
            targetHeight = targetShortEdge
            targetWidth = (targetShortEdge * aspect).roundToInt()
        }

        // MediaRecorder does not expose its final codec name; preflight the available
        // surface-capable H.264 encoders and rank hardware implementations first.
        val encoders = MediaCodecList(MediaCodecList.ALL_CODECS).codecInfos
            .filter { info ->
                info.isEncoder && info.supportedTypes.any { it.equals(MIME_AVC, ignoreCase = true) }
            }
            .sortedByDescending { info -> hardwareScore(info.name, info.isHardwareAcceleratedCompat()) }

        if (encoders.isEmpty()) {
            throw IllegalStateException("لا يوجد مُرمّز فيديو AVC متاح على هذا الجهاز.")
        }

        val fpsCandidates = when (requestedFrameRate) {
            30 -> listOf(30, 24, 15)
            24 -> listOf(24, 15)
            else -> listOf(15)
        }
        val scales = listOf(1.0, 0.90, 0.80, 0.70, 0.60, 0.50, 0.40, 0.33, 0.25)

        for (encoder in encoders) {
            val codecCapabilities = runCatching {
                encoder.getCapabilitiesForType(MIME_AVC)
            }.getOrNull() ?: continue
            if (codecCapabilities.colorFormats.none {
                    it == android.media.MediaCodecInfo.CodecCapabilities.COLOR_FormatSurface
                }
            ) {
                continue
            }
            val capabilities = codecCapabilities.videoCapabilities ?: continue
            val widthAlignment = capabilities.widthAlignment.coerceAtLeast(1)
            val heightAlignment = capabilities.heightAlignment.coerceAtLeast(1)

            for (scale in scales) {
                val scaledWidth = alignDown((targetWidth * scale).roundToInt(), widthAlignment)
                val scaledHeight = alignDown((targetHeight * scale).roundToInt(), heightAlignment)
                if (scaledWidth < 320 || scaledHeight < 240) continue

                for (fps in fpsCandidates) {
                    val supported = runCatching {
                        capabilities.areSizeAndRateSupported(
                            scaledWidth,
                            scaledHeight,
                            fps.toDouble()
                        )
                    }.getOrDefault(false)
                    if (supported) {
                        val hardware = encoder.isHardwareAcceleratedCompat()
                        val supportedBitRate = quality.bitRate.coerceIn(
                            capabilities.bitrateRange.lower,
                            capabilities.bitrateRange.upper
                        )
                        Log.i(
                            TAG,
                            "Encoder candidate=${encoder.name}, hardware=$hardware, " +
                                "size=${scaledWidth}x$scaledHeight, fps=$fps, bitrate=$supportedBitRate"
                        )
                        return CaptureConfiguration(
                            width = scaledWidth,
                            height = scaledHeight,
                            frameRate = fps,
                            bitRate = supportedBitRate,
                            encoderName = encoder.name,
                            screenMetrics = screen
                        )
                    }
                }
            }
        }

        throw IllegalStateException("لا يدعم الجهاز إعدادات ترميز AVC المطلوبة أو أي إعداد بديل آمن.")
    }

    private fun alignDown(value: Int, alignment: Int): Int =
        (value / alignment) * alignment

    private fun hardwareScore(name: String, hardwareAccelerated: Boolean): Int {
        if (hardwareAccelerated) return 2
        val lower = name.lowercase()
        return if (lower.contains("google") || lower.contains("software") || lower.contains("c2.android")) 0 else 1
    }

    @Suppress("DEPRECATION")
    private fun android.media.MediaCodecInfo.isHardwareAcceleratedCompat(): Boolean =
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) isHardwareAccelerated else {
            val lower = name.lowercase()
            !lower.contains("google") && !lower.contains("software") && !lower.contains("c2.android")
        }
}
