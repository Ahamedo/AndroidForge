package com.litescreenrecorder.recording

import android.Manifest
import android.content.ContentValues
import android.content.Context
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.os.StatFs
import android.provider.MediaStore
import java.io.File
import java.io.IOException
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.UUID

object MediaStoreRecordingOutput {
    private const val MINIMUM_FREE_BYTES = 32L * 1024L * 1024L
    private const val FOLDER_NAME = "LiteScreenRecorder"

    private fun availableBytes(): Long =
        StatFs(Environment.getExternalStorageDirectory().absolutePath).availableBytes

    fun ensureStorageAvailable() {
        if (availableBytes() < MINIMUM_FREE_BYTES) {
            throw IOException("المساحة المتاحة غير كافية لبدء التسجيل.")
        }
    }

    fun create(context: Context): Uri {
        ensureStorageAvailable()
        val filename = createUniqueFilename()
        val values = ContentValues().apply {
            put(MediaStore.MediaColumns.DISPLAY_NAME, filename)
            put(MediaStore.MediaColumns.MIME_TYPE, "video/mp4")
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                put(
                    MediaStore.MediaColumns.RELATIVE_PATH,
                    Environment.DIRECTORY_MOVIES + "/" + FOLDER_NAME
                )
                put(MediaStore.MediaColumns.IS_PENDING, 1)
            } else {
                if (context.checkSelfPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE) !=
                    PackageManager.PERMISSION_GRANTED
                ) {
                    throw SecurityException("يلزم منح إذن التخزين على Android 8 وAndroid 9.")
                }
                val directory = File(
                    Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_MOVIES),
                    FOLDER_NAME
                )
                if (!directory.exists() && !directory.mkdirs()) {
                    throw IOException("تعذر إنشاء مجلد حفظ التسجيلات.")
                }
                val outputFile = File(directory, filename)
                put(MediaStore.MediaColumns.DATA, outputFile.absolutePath)
                put(MediaStore.Video.Media.DATE_ADDED, System.currentTimeMillis() / 1000L)
            }
        }

        return context.contentResolver.insert(
            MediaStore.Video.Media.EXTERNAL_CONTENT_URI,
            values
        ) ?: throw IOException("تعذر إنشاء ملف التسجيل في مكتبة الوسائط.")
    }

    fun finalizeOutput(context: Context, uri: Uri) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            val values = ContentValues().apply {
                put(MediaStore.MediaColumns.IS_PENDING, 0)
            }
            val updated = context.contentResolver.update(uri, values, null, null)
            if (updated <= 0) throw IOException("تعذر اعتماد ملف الفيديو في مكتبة الوسائط.")
        }
    }

    fun delete(context: Context, uri: Uri?) {
        if (uri == null) return
        runCatching { context.contentResolver.delete(uri, null, null) }
    }

    private fun createUniqueFilename(): String {
        val stamp = SimpleDateFormat("yyyyMMdd_HHmmss_SSS", Locale.US).format(Date())
        return "LiteScreenRecorder_${stamp}_${UUID.randomUUID().toString().take(8)}.mp4"
    }
}
