package com.lite.screenrecorder

import android.Manifest
import android.app.Activity
import android.content.*
import android.content.pm.PackageManager
import android.media.projection.MediaProjectionManager
import android.os.*
import android.view.View
import android.widget.*

class MainActivity : Activity() {
    private val settings by lazy { SettingsManager(this) }
    private lateinit var quality: Spinner; private lateinit var fps: Spinner
    private lateinit var status: TextView; private lateinit var duration: TextView
    private lateinit var start: Button; private lateinit var pause: Button; private lateinit var stop: Button
    private val receiver = object : BroadcastReceiver() { override fun onReceive(c: Context?, i: Intent?) { render(i?.getStringExtra(RecordingService.EXTRA_STATE) ?: "جاهز", i?.getBooleanExtra(RecordingService.EXTRA_ACTIVE, false) ?: false, i?.getBooleanExtra(RecordingService.EXTRA_PAUSED, false) ?: false, i?.getLongExtra(RecordingService.EXTRA_DURATION, 0L) ?: 0L) } }
    override fun onCreate(savedInstanceState: Bundle?) { super.onCreate(savedInstanceState); setContentView(R.layout.activity_main)
        quality=findViewById(R.id.quality); fps=findViewById(R.id.fps); status=findViewById(R.id.status); duration=findViewById(R.id.duration); start=findViewById(R.id.start); pause=findViewById(R.id.pause); stop=findViewById(R.id.stop)
        quality.adapter=ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, listOf("480p · منخفضة", "720p · متوسطة", "1080p · عالية")); fps.adapter=ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, listOf("30 FPS", "60 FPS", "90 FPS")); quality.setSelection(settings.quality); fps.setSelection(listOf(30,60,90).indexOf(settings.fps))
        start.setOnClickListener { settings.quality=quality.selectedItemPosition;settings.fps=intArrayOf(30,60,90)[fps.selectedItemPosition]; if(Build.VERSION.SDK_INT>=33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)!=PackageManager.PERMISSION_GRANTED) requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS),3) else askCapture() }
        pause.setOnClickListener { send(if(pause.text.toString().contains("استئناف")) RecordingService.PAUSE_RESUME else RecordingService.PAUSE_RESUME) }; stop.setOnClickListener { send(RecordingService.STOP) }
    }
    private fun askCapture(){ @Suppress("DEPRECATION") startActivityForResult((getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager).createScreenCaptureIntent(),1) }
    @Deprecated("Platform callback") override fun onActivityResult(r:Int,c:Int,d:Intent?){super.onActivityResult(r,c,d); if(r==1 && c==RESULT_OK && d!=null){val i=Intent(this,RecordingService::class.java).setAction(RecordingService.START).putExtra(RecordingService.CODE,c).putExtra(RecordingService.DATA,d).putExtra(RecordingService.QUALITY,quality.selectedItemPosition).putExtra(RecordingService.FPS,intArrayOf(30,60,90)[fps.selectedItemPosition]); if(Build.VERSION.SDK_INT>=26) startForegroundService(i) else startService(i)}}
    @Deprecated("Platform permission callback") override fun onRequestPermissionsResult(r:Int,p:Array<out String>,g:IntArray){super.onRequestPermissionsResult(r,p,g);if(r==3)askCapture()}
    override fun onStart(){super.onStart(); val f=IntentFilter(RecordingService.STATE); if(Build.VERSION.SDK_INT>=33) registerReceiver(receiver,f,RECEIVER_NOT_EXPORTED) else @Suppress("DEPRECATION") registerReceiver(receiver,f); send(Intent(this,RecordingService::class.java).setAction(RecordingService.QUERY))}
    override fun onStop(){unregisterReceiver(receiver); super.onStop()}
    private fun send(i:Intent){i.setClass(this,RecordingService::class.java); startService(i)}
    private fun render(s:String,a:Boolean,p:Boolean,t:Long){status.text=s; duration.text=String.format("%02d:%02d",t/60000,(t/1000)%60); start.isEnabled=!a; quality.isEnabled=!a;fps.isEnabled=!a;pause.isEnabled=a;stop.isEnabled=a;pause.text=if(p)"استئناف" else "إيقاف مؤقت"}
}
