package com.lite.screenrecorder

import android.content.Context

/** Small persistent preference wrapper; no recording resources are held here. */
internal class SettingsManager(context:Context){
 private val preferences=context.getSharedPreferences("recorder_settings",Context.MODE_PRIVATE)
 var quality:Int
  get()=preferences.getInt("quality",1).coerceIn(0,2)
  set(value){preferences.edit().putInt("quality",value.coerceIn(0,2)).apply()}
 var fps:Int
  get()=preferences.getInt("fps",30).let{if(it in listOf(30,60,90))it else 30}
  set(value){preferences.edit().putInt("fps",if(value in listOf(30,60,90))value else 30).apply()}
}
