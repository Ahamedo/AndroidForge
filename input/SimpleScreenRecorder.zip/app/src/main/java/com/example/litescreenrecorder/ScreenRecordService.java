package com.example.litescreenrecorder;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ServiceInfo;
import android.graphics.PixelFormat;
import android.hardware.display.DisplayManager;
import android.hardware.display.VirtualDisplay;
import android.media.AudioAttributes;
import android.media.AudioFormat;
import android.media.AudioPlaybackCaptureConfiguration;
import android.media.AudioRecord;
import android.media.MediaCodec;
import android.media.MediaCodecInfo;
import android.media.MediaFormat;
import android.media.MediaMuxer;
import android.media.MediaScannerConnection;
import android.media.projection.MediaProjection;
import android.media.projection.MediaProjectionManager;
import android.net.Uri;
import android.os.Build;
import android.os.Environment;
import android.os.IBinder;
import android.provider.MediaStore;
import android.provider.Settings;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.core.app.NotificationCompat;

import java.io.File;
import java.io.FileDescriptor;
import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.ByteBuffer;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;
import java.util.concurrent.atomic.AtomicBoolean;

public class ScreenRecordService extends Service {

    private static final String TAG = "LiteScreenRecorderSvc";
    private static final String CHANNEL_ID = "screen_recorder_channel";
    private static final int NOTIFICATION_ID = 1001;

    public static final String ACTION_START_RECORDING = "com.example.litescreenrecorder.START";
    public static final String ACTION_STOP_RECORDING = "com.example.litescreenrecorder.STOP";
    public static final String ACTION_PAUSE_RECORDING = "com.example.litescreenrecorder.PAUSE";
    public static final String ACTION_RESUME_RECORDING = "com.example.litescreenrecorder.RESUME";
    public static final String ACTION_SHOW_BUBBLE = "com.example.litescreenrecorder.SHOW_BUBBLE";
    public static final String ACTION_HIDE_BUBBLE = "com.example.litescreenrecorder.HIDE_BUBBLE";
    public static final String ACTION_STATE_CHANGED = "com.example.litescreenrecorder.STATE_CHANGED";

    public static final String EXTRA_RESULT_CODE = "result_code";
    public static final String EXTRA_RESULT_DATA = "result_data";
    public static final String EXTRA_RESOLUTION = "resolution";
    public static final String EXTRA_FPS = "fps";
    public static final String EXTRA_AUDIO_MODE = "audio_mode";

    private static volatile boolean recordingActive = false;
    private static volatile boolean pausedState = false;
    private static volatile String lastSavedFilePath = "";

    private WindowManager windowManager;
    private View bubbleView;
    private View controlsPopupView;

    private MediaProjectionManager projectionManager;
    private MediaProjection mediaProjection;
    private VirtualDisplay virtualDisplay;

    private MediaCodec videoEncoder;
    private MediaCodec audioEncoder;
    private MediaMuxer mediaMuxer;
    private int videoTrackIndex = -1;
    private int audioTrackIndex = -1;
    private boolean muxerStarted = false;
    private long presentationTimeOffsetUs = 0L;
    private long pauseStartRealtimeUs = 0L;
    private long lastVideoTimestampUs = -1L;

    private AudioRecord internalAudioRecord;
    private AudioRecord micAudioRecord;
    private Thread videoDrainThread;
    private Thread audioCaptureThread;

    private final AtomicBoolean isRunning = new AtomicBoolean(false);
    private final AtomicBoolean isPaused = new AtomicBoolean(false);
    private final Object muxerLock = new Object();

    private File activeOutputFile;
    private Uri activeMediaStoreUri;

    private final MediaProjection.Callback projectionCallback = new MediaProjection.Callback() {
        @Override
        public void onStop() {
            Log.w(TAG, "MediaProjection stopped by system or user");
            stopRecordingSession(true);
        }
    };

    public static boolean isRecordingActive() {
        return recordingActive;
    }

    public static boolean isPausedState() {
        return pausedState;
    }

    public static String getLastSavedFilePath() {
        return lastSavedFilePath;
    }

    public static void showFloatingBubble(Context context) {
        Intent i = new Intent(context, ScreenRecordService.class);
        i.setAction(ACTION_SHOW_BUBBLE);
        ContextCompat.startForegroundService(context, i);
    }

    public static void hideFloatingBubble(Context context) {
        Intent i = new Intent(context, ScreenRecordService.class);
        i.setAction(ACTION_HIDE_BUBBLE);
        context.startService(i);
    }

    public static void pauseRecording(Context context) {
        Intent i = new Intent(context, ScreenRecordService.class);
        i.setAction(ACTION_PAUSE_RECORDING);
        context.startService(i);
    }

    public static void resumeRecording(Context context) {
        Intent i = new Intent(context, ScreenRecordService.class);
        i.setAction(ACTION_RESUME_RECORDING);
        context.startService(i);
    }

    public static void stopRecording(Context context) {
        Intent i = new Intent(context, ScreenRecordService.class);
        i.setAction(ACTION_STOP_RECORDING);
        context.startService(i);
    }

    @Override
    public void onCreate() {
        super.onCreate();
        windowManager = (WindowManager) getSystemService(Context.WINDOW_SERVICE);
        projectionManager = (MediaProjectionManager) getSystemService(Context.MEDIA_PROJECTION_SERVICE);
        createNotificationChannel();
        promoteToForeground(getString(R.string.notif_ready));
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        promoteToForeground(isRunning.get() ? getString(R.string.status_recording) : getString(R.string.notif_ready));

        if (intent == null || intent.getAction() == null) {
            return START_NOT_STICKY;
        }

        String action = intent.getAction();
        switch (action) {
            case ACTION_START_RECORDING:
                int resultCode = intent.getIntExtra(EXTRA_RESULT_CODE, 0);
                Intent data = intent.getParcelableExtra(EXTRA_RESULT_DATA);
                String resolution = intent.getStringExtra(EXTRA_RESOLUTION);
                int fps = intent.getIntExtra(EXTRA_FPS, RecordingPreferences.FPS_30);
                String audioMode = intent.getStringExtra(EXTRA_AUDIO_MODE);
                startRecordingSession(resultCode, data, resolution, fps, audioMode);
                break;
            case ACTION_PAUSE_RECORDING:
                setRecordingPaused(true);
                break;
            case ACTION_RESUME_RECORDING:
                setRecordingPaused(false);
                break;
            case ACTION_STOP_RECORDING:
                stopRecordingSession(false);
                break;
            case ACTION_SHOW_BUBBLE:
                attachFloatingBubbleIfPermitted();
                break;
            case ACTION_HIDE_BUBBLE:
                removeFloatingBubble();
                if (!isRunning.get()) {
                    stopForeground(STOP_FOREGROUND_REMOVE);
                    stopSelf();
                }
                break;
            default:
                break;
        }
        return START_NOT_STICKY;
    }

    private void promoteToForeground(String contentText) {
        Notification notification = buildForegroundNotification(contentText);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            int serviceType = Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE
                    ? ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION
                    : ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION;
            startForeground(NOTIFICATION_ID, notification, serviceType);
        } else {
            startForeground(NOTIFICATION_ID, notification);
        }
    }

    private Notification buildForegroundNotification(String contentText) {
        Intent openIntent = new Intent(this, MainActivity.class);
        PendingIntent pendingIntent = PendingIntent.getActivity(
                this, 0, openIntent,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE
        );

        return new NotificationCompat.Builder(this, CHANNEL_ID)
                .setContentTitle(getString(R.string.app_name))
                .setContentText(contentText)
                .setSmallIcon(android.R.drawable.ic_menu_camera)
                .setContentIntent(pendingIntent)
                .setOngoing(true)
                .build();
    }

    private void createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel channel = new NotificationChannel(
                    CHANNEL_ID,
                    getString(R.string.notif_channel_name),
                    NotificationManager.IMPORTANCE_LOW
            );
            NotificationManager manager = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
            if (manager != null) {
                manager.createNotificationChannel(channel);
            }
        }
    }

    private void startRecordingSession(int resultCode, Intent data, String resolution, int fps, String audioMode) {
        if (isRunning.get()) {
            stopRecordingSession(false);
        }

        if (projectionManager == null || data == null) {
            return;
        }

        try {
            mediaProjection = projectionManager.getMediaProjection(resultCode, data);
            if (mediaProjection == null) {
                return;
            }
            mediaProjection.registerCallback(projectionCallback, null);

            DisplayMetrics metrics = getResources().getDisplayMetrics();
            int[] dims = resolveDimensions(resolution, metrics.widthPixels, metrics.heightPixels);
            int width = dims[0];
            int height = dims[1];
            int effectiveFps = clampFpsForDevice(fps, resolution);
            int bitrate = calculateBitrate(width, height, effectiveFps);

            String fileName = "Rec_" + new SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(new Date()) + ".mp4";
            FileDescriptor outputFd = createOutputTarget(fileName);
            if (outputFd == null && activeOutputFile == null) {
                Log.e(TAG, "Failed to create output file or descriptor");
                cleanupRecordingResources();
                return;
            }

            videoEncoder = MediaCodec.createEncoderByType(MediaFormat.MIMETYPE_VIDEO_AVC);
            MediaFormat videoFormat = MediaFormat.createVideoFormat(MediaFormat.MIMETYPE_VIDEO_AVC, width, height);
            videoFormat.setInteger(MediaFormat.KEY_COLOR_FORMAT, MediaCodecInfo.CodecCapabilities.COLOR_FormatSurface);
            videoFormat.setInteger(MediaFormat.KEY_BIT_RATE, bitrate);
            videoFormat.setInteger(MediaFormat.KEY_FRAME_RATE, effectiveFps);
            videoFormat.setInteger(MediaFormat.KEY_I_FRAME_INTERVAL, 1);
            videoEncoder.configure(videoFormat, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE);
            android.view.Surface inputSurface = videoEncoder.createInputSurface();
            videoEncoder.start();

            boolean captureInternal = Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q;
            boolean captureMic = RecordingPreferences.AUDIO_INTERNAL_AND_MIC.equals(audioMode);

            if (captureInternal) {
                setupAudioCaptureAndEncoder(captureMic);
            }

            if (outputFd != null) {
                mediaMuxer = new MediaMuxer(outputFd, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4);
            } else {
                mediaMuxer = new MediaMuxer(activeOutputFile.getAbsolutePath(), MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4);
            }

            virtualDisplay = mediaProjection.createVirtualDisplay(
                    "LiteScreenRecorderDisplay",
                    width,
                    height,
                    metrics.densityDpi,
                    DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
                    inputSurface,
                    null,
                    null
            );

            isRunning.set(true);
            isPaused.set(false);
            presentationTimeOffsetUs = 0L;
            pauseStartRealtimeUs = 0L;
            lastVideoTimestampUs = -1L;
            recordingActive = true;
            pausedState = false;
            promoteToForeground(getString(R.string.status_recording));
            broadcastState();

            startVideoDrainLoop();
            if (captureInternal) {
                startAudioCaptureLoop(captureMic);
            }
        } catch (Exception e) {
            Log.e(TAG, "Error starting recording session", e);
            Toast.makeText(this, R.string.recording_start_error, Toast.LENGTH_SHORT).show();
            cleanupRecordingResources();
            recordingActive = false;
            pausedState = false;
            broadcastState();
        }
    }

    private void setupAudioCaptureAndEncoder(boolean includeMic) {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.Q) {
            return;
        }
        int sampleRate = 44100;
        int channelConfig = AudioFormat.CHANNEL_IN_MONO;
        int audioFormat = AudioFormat.ENCODING_PCM_16BIT;
        int minBuf = Math.max(AudioRecord.getMinBufferSize(sampleRate, channelConfig, audioFormat), 4096);

        AudioPlaybackCaptureConfiguration config = new AudioPlaybackCaptureConfiguration.Builder(mediaProjection)
                .addMatchingUsage(AudioAttributes.USAGE_MEDIA)
                .addMatchingUsage(AudioAttributes.USAGE_GAME)
                .build();

        AudioFormat formatSpec = new AudioFormat.Builder()
                .setEncoding(audioFormat)
                .setSampleRate(sampleRate)
                .setChannelMask(channelConfig)
                .build();

        internalAudioRecord = new AudioRecord.Builder()
                .setAudioFormat(formatSpec)
                .setBufferSizeInBytes(minBuf)
                .setAudioPlaybackCaptureConfig(config)
                .build();

        if (includeMic) {
            micAudioRecord = new AudioRecord(
                    android.media.MediaRecorder.AudioSource.MIC,
                    sampleRate,
                    channelConfig,
                    audioFormat,
                    minBuf
            );
        }

        try {
            audioEncoder = MediaCodec.createEncoderByType(MediaFormat.MIMETYPE_AUDIO_AAC);
            MediaFormat audioMediaFormat = MediaFormat.createAudioFormat(MediaFormat.MIMETYPE_AUDIO_AAC, sampleRate, 1);
            audioMediaFormat.setInteger(MediaFormat.KEY_AAC_PROFILE, MediaCodecInfo.CodecProfileLevel.AACObjectLC);
            audioMediaFormat.setInteger(MediaFormat.KEY_BIT_RATE, 96000);
            audioEncoder.configure(audioMediaFormat, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE);
            audioEncoder.start();
        } catch (IOException e) {
            Log.w(TAG, "Audio AAC encoder unavailable; continuing with video only", e);
            audioEncoder = null;
        }
    }

    private void startVideoDrainLoop() {
        videoDrainThread = new Thread(() -> {
            MediaCodec.BufferInfo bufferInfo = new MediaCodec.BufferInfo();
            while (isRunning.get()) {
                try {
                    int outIndex = videoEncoder.dequeueOutputBuffer(bufferInfo, 10000);
                    if (outIndex == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) {
                        synchronized (muxerLock) {
                            if (videoTrackIndex < 0) {
                                videoTrackIndex = mediaMuxer.addTrack(videoEncoder.getOutputFormat());
                                maybeStartMuxerLocked();
                            }
                        }
                    } else if (outIndex >= 0) {
                        ByteBuffer encodedData = videoEncoder.getOutputBuffer(outIndex);
                        if (encodedData != null && bufferInfo.size > 0
                                && (bufferInfo.flags & MediaCodec.BUFFER_FLAG_CODEC_CONFIG) == 0) {
                            long adjustedPts = bufferInfo.presentationTimeUs - presentationTimeOffsetUs;
                            if (!isPaused.get() && adjustedPts > lastVideoTimestampUs) {
                                lastVideoTimestampUs = adjustedPts;
                                bufferInfo.presentationTimeUs = adjustedPts;
                                synchronized (muxerLock) {
                                    if (muxerStarted && videoTrackIndex >= 0) {
                                        encodedData.position(bufferInfo.offset);
                                        encodedData.limit(bufferInfo.offset + bufferInfo.size);
                                        mediaMuxer.writeSampleData(videoTrackIndex, encodedData, bufferInfo);
                                    }
                                }
                            }
                        }
                        videoEncoder.releaseOutputBuffer(outIndex, false);
                        if ((bufferInfo.flags & MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0) {
                            break;
                        }
                    }
                } catch (Exception e) {
                    if (isRunning.get()) {
                        Log.e(TAG, "Video drain loop error", e);
                    }
                    break;
                }
            }
        }, "VideoDrainThread");
        videoDrainThread.start();
    }

    private void startAudioCaptureLoop(boolean includeMic) {
        if (internalAudioRecord == null || audioEncoder == null) {
            return;
        }
        try {
            internalAudioRecord.startRecording();
            if (includeMic && micAudioRecord != null && micAudioRecord.getState() == AudioRecord.STATE_INITIALIZED) {
                micAudioRecord.startRecording();
            }
        } catch (IllegalStateException e) {
            Log.w(TAG, "AudioRecord start failed", e);
            return;
        }

        audioCaptureThread = new Thread(() -> {
            int frameSamples = 1024;
            short[] internalPcm = new short[frameSamples];
            short[] micPcm = new short[frameSamples];
            short[] mixedPcm = new short[frameSamples];
            long sampleCount = 0L;
            int sampleRate = 44100;

            while (isRunning.get()) {
                int readInternal = internalAudioRecord.read(internalPcm, 0, frameSamples);
                int readMic = 0;
                if (includeMic && micAudioRecord != null && micAudioRecord.getRecordingState() == AudioRecord.RECORDSTATE_RECORDING) {
                    readMic = micAudioRecord.read(micPcm, 0, frameSamples);
                }

                if (!isPaused.get() && readInternal > 0) {
                    for (int i = 0; i < frameSamples; i++) {
                        int s = i < readInternal ? internalPcm[i] : 0;
                        if (includeMic && i < readMic) {
                            s = (s + micPcm[i]) / 2;
                        }
                        mixedPcm[i] = (short) Math.max(Short.MIN_VALUE, Math.min(Short.MAX_VALUE, s));
                    }

                    try {
                        int inIdx = audioEncoder.dequeueInputBuffer(5000);
                        if (inIdx >= 0) {
                            ByteBuffer inBuf = audioEncoder.getInputBuffer(inIdx);
                            if (inBuf != null) {
                                inBuf.clear();
                                ByteBuffer shortAsBytes = ByteBuffer.allocate(frameSamples * 2);
                                shortAsBytes.order(java.nio.ByteOrder.LITTLE_ENDIAN);
                                shortAsBytes.asShortBuffer().put(mixedPcm);
                                byte[] bytes = shortAsBytes.array();
                                inBuf.put(bytes, 0, Math.min(bytes.length, inBuf.capacity()));
                                long ptsUs = (sampleCount * 1_000_000L) / sampleRate;
                                audioEncoder.queueInputBuffer(inIdx, 0, Math.min(bytes.length, inBuf.capacity()), ptsUs, 0);
                                sampleCount += frameSamples;
                            }
                        }

                        MediaCodec.BufferInfo info = new MediaCodec.BufferInfo();
                        int outIdx = audioEncoder.dequeueOutputBuffer(info, 0);
                        if (outIdx == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) {
                            synchronized (muxerLock) {
                                if (audioTrackIndex < 0) {
                                    audioTrackIndex = mediaMuxer.addTrack(audioEncoder.getOutputFormat());
                                    maybeStartMuxerLocked();
                                }
                            }
                        } else if (outIdx >= 0) {
                            ByteBuffer outBuf = audioEncoder.getOutputBuffer(outIdx);
                            if (outBuf != null && info.size > 0
                                    && (info.flags & MediaCodec.BUFFER_FLAG_CODEC_CONFIG) == 0) {
                                synchronized (muxerLock) {
                                    if (muxerStarted && audioTrackIndex >= 0) {
                                        outBuf.position(info.offset);
                                        outBuf.limit(info.offset + info.size);
                                        mediaMuxer.writeSampleData(audioTrackIndex, outBuf, info);
                                    }
                                }
                            }
                            audioEncoder.releaseOutputBuffer(outIdx, false);
                        }
                    } catch (Exception e) {
                        if (isRunning.get()) {
                            Log.w(TAG, "Audio encoding error", e);
                        }
                    }
                }
            }
        }, "AudioCaptureThread");
        audioCaptureThread.start();
    }

    private void maybeStartMuxerLocked() {
        if (muxerStarted) return;
        boolean expectsAudio = audioEncoder != null;
        if (videoTrackIndex >= 0 && (!expectsAudio || audioTrackIndex >= 0)) {
            mediaMuxer.start();
            muxerStarted = true;
        }
    }

    private void setRecordingPaused(boolean pause) {
        if (!isRunning.get()) return;
        long nowUs = System.nanoTime() / 1000L;
        if (pause && !isPaused.get()) {
            isPaused.set(true);
            pausedState = true;
            pauseStartRealtimeUs = nowUs;
            promoteToForeground(getString(R.string.status_paused));
            broadcastState();
        } else if (!pause && isPaused.get()) {
            if (pauseStartRealtimeUs > 0L && nowUs > pauseStartRealtimeUs) {
                presentationTimeOffsetUs += (nowUs - pauseStartRealtimeUs);
            }
            isPaused.set(false);
            pausedState = false;
            promoteToForeground(getString(R.string.status_recording));
            broadcastState();
        }
    }

    private void stopRecordingSession(boolean fromSystemCallback) {
        if (!isRunning.get() && !recordingActive) {
            return;
        }
        isRunning.set(false);
        isPaused.set(false);
        recordingActive = false;
        pausedState = false;

        cleanupRecordingResources();
        notifyMediaScannerAndUpdateLastFile();
        promoteToForeground(getString(R.string.notif_ready));
        broadcastState();

        if (fromSystemCallback) {
            Toast.makeText(this, R.string.projection_revoked_saved, Toast.LENGTH_SHORT).show();
        }
    }

    private void cleanupRecordingResources() {
        if (videoDrainThread != null) {
            try {
                videoDrainThread.join(1500);
            } catch (InterruptedException ignored) {
                Thread.currentThread().interrupt();
            }
            videoDrainThread = null;
        }
        if (audioCaptureThread != null) {
            try {
                audioCaptureThread.join(1500);
            } catch (InterruptedException ignored) {
                Thread.currentThread().interrupt();
            }
            audioCaptureThread = null;
        }

        if (virtualDisplay != null) {
            try {
                virtualDisplay.release();
            } catch (Exception ignored) {
            }
            virtualDisplay = null;
        }

        if (videoEncoder != null) {
            try {
                videoEncoder.stop();
            } catch (Exception ignored) {
            }
            try {
                videoEncoder.release();
            } catch (Exception ignored) {
            }
            videoEncoder = null;
        }

        if (internalAudioRecord != null) {
            try {
                internalAudioRecord.stop();
            } catch (Exception ignored) {
            }
            try {
                internalAudioRecord.release();
            } catch (Exception ignored) {
            }
            internalAudioRecord = null;
        }

        if (micAudioRecord != null) {
            try {
                micAudioRecord.stop();
            } catch (Exception ignored) {
            }
            try {
                micAudioRecord.release();
            } catch (Exception ignored) {
            }
            micAudioRecord = null;
        }

        if (audioEncoder != null) {
            try {
                audioEncoder.stop();
            } catch (Exception ignored) {
            }
            try {
                audioEncoder.release();
            } catch (Exception ignored) {
            }
            audioEncoder = null;
        }

        synchronized (muxerLock) {
            if (mediaMuxer != null) {
                try {
                    if (muxerStarted) {
                        mediaMuxer.stop();
                    }
                } catch (Exception e) {
                    Log.w(TAG, "Muxer stop warning", e);
                }
                try {
                    mediaMuxer.release();
                } catch (Exception ignored) {
                }
                mediaMuxer = null;
            }
            muxerStarted = false;
            videoTrackIndex = -1;
            audioTrackIndex = -1;
        }

        if (mediaProjection != null) {
            try {
                mediaProjection.unregisterCallback(projectionCallback);
                mediaProjection.stop();
            } catch (Exception ignored) {
            }
            mediaProjection = null;
        }
    }

    private FileDescriptor createOutputTarget(String fileName) {
        activeOutputFile = null;
        activeMediaStoreUri = null;
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                ContentValues values = new ContentValues();
                values.put(MediaStore.Video.Media.DISPLAY_NAME, fileName);
                values.put(MediaStore.Video.Media.MIME_TYPE, "video/mp4");
                values.put(MediaStore.Video.Media.RELATIVE_PATH, Environment.DIRECTORY_MOVIES + "/LiteScreenRecorder");
                activeMediaStoreUri = getContentResolver().insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, values);
                if (activeMediaStoreUri != null) {
                    android.os.ParcelFileDescriptor pfd = getContentResolver().openFileDescriptor(activeMediaStoreUri, "rw");
                    if (pfd != null) {
                        return pfd.getFileDescriptor();
                    }
                }
            }
            File dir = new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_MOVIES), "LiteScreenRecorder");
            if (!dir.exists() && !dir.mkdirs()) {
                dir = getExternalFilesDir(Environment.DIRECTORY_MOVIES);
            }
            activeOutputFile = new File(dir, fileName);
            FileOutputStream fos = new FileOutputStream(activeOutputFile);
            return fos.getFD();
        } catch (Exception e) {
            Log.e(TAG, "Error preparing output target", e);
            return null;
        }
    }

    private void notifyMediaScannerAndUpdateLastFile() {
        String pathToScan = null;
        if (activeOutputFile != null && activeOutputFile.exists()) {
            pathToScan = activeOutputFile.getAbsolutePath();
        } else if (activeMediaStoreUri != null) {
            pathToScan = activeMediaStoreUri.toString();
        }

        if (pathToScan != null) {
            lastSavedFilePath = pathToScan;
            if (activeOutputFile != null && activeOutputFile.exists()) {
                MediaScannerConnection.scanFile(
                        getApplicationContext(),
                        new String[]{activeOutputFile.getAbsolutePath()},
                        new String[]{"video/mp4"},
                        null
                );
            }
        }
    }

    private void attachFloatingBubbleIfPermitted() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && !Settings.canDrawOverlays(this)) {
            return;
        }
        if (bubbleView != null) {
            return;
        }
        LayoutInflater inflater = LayoutInflater.from(this);
        bubbleView = inflater.inflate(R.layout.floating_bubble, null);

        int layoutFlag = Build.VERSION.SDK_INT >= Build.VERSION_CODES.O
                ? WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
                : WindowManager.LayoutParams.TYPE_PHONE;

        WindowManager.LayoutParams params = new WindowManager.LayoutParams(
                WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.WRAP_CONTENT,
                layoutFlag,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
                PixelFormat.TRANSLUCENT
        );
        params.gravity = Gravity.TOP | Gravity.END;
        params.x = 24;
        params.y = 240;

        bubbleView.setOnClickListener(v -> toggleControlsPopup());
        windowManager.addView(bubbleView, params);
    }

    private void toggleControlsPopup() {
        if (controlsPopupView != null) {
            removeControlsPopup();
            return;
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && !Settings.canDrawOverlays(this)) {
            return;
        }
        LayoutInflater inflater = LayoutInflater.from(this);
        controlsPopupView = inflater.inflate(R.layout.floating_controls, null);

        int layoutFlag = Build.VERSION.SDK_INT >= Build.VERSION_CODES.O
                ? WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
                : WindowManager.LayoutParams.TYPE_PHONE;

        WindowManager.LayoutParams params = new WindowManager.LayoutParams(
                WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.WRAP_CONTENT,
                layoutFlag,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
                PixelFormat.TRANSLUCENT
        );
        params.gravity = Gravity.TOP | Gravity.END;
        params.x = 24;
        params.y = 380;

        Button btnStartNew = controlsPopupView.findViewById(R.id.bubble_start_new);
        Button btnPauseResume = controlsPopupView.findViewById(R.id.bubble_pause_resume);
        Button btnStopSave = controlsPopupView.findViewById(R.id.bubble_stop_save);

        btnPauseResume.setText(isRunning.get() && isPaused.get() ? R.string.action_resume : R.string.action_pause);

        btnStartNew.setOnClickListener(v -> {
            removeControlsPopup();
            Intent launchApp = new Intent(this, MainActivity.class);
            launchApp.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(launchApp);
        });

        btnPauseResume.setOnClickListener(v -> {
            removeControlsPopup();
            if (isRunning.get()) {
                setRecordingPaused(!isPaused.get());
            }
        });

        btnStopSave.setOnClickListener(v -> {
            removeControlsPopup();
            stopRecordingSession(false);
        });

        windowManager.addView(controlsPopupView, params);
    }

    private void removeControlsPopup() {
        if (controlsPopupView != null && windowManager != null) {
            try {
                windowManager.removeView(controlsPopupView);
            } catch (Exception ignored) {
            }
            controlsPopupView = null;
        }
    }

    private void removeFloatingBubble() {
        removeControlsPopup();
        if (bubbleView != null && windowManager != null) {
            try {
                windowManager.removeView(bubbleView);
            } catch (Exception ignored) {
            }
            bubbleView = null;
        }
    }

    private void broadcastState() {
        Intent intent = new Intent(ACTION_STATE_CHANGED);
        intent.setPackage(getPackageName());
        sendBroadcast(intent);
    }

    private int[] resolveDimensions(String resolution, int screenW, int screenH) {
        boolean portrait = screenH >= screenW;
        int shortSide;
        if (RecordingPreferences.RES_480P.equals(resolution)) {
            shortSide = 480;
        } else if (RecordingPreferences.RES_1080P.equals(resolution)) {
            shortSide = 1080;
        } else {
            shortSide = 720;
        }

        int longSide = (int) Math.round(shortSide * (portrait ? ((float) screenH / Math.max(1, screenW)) : ((float) screenW / Math.max(1, screenH))));
        // Ensure dimensions are even numbers for hardware encoders
        shortSide = even(shortSide);
        longSide = even(longSide);

        return portrait ? new int[]{shortSide, longSide} : new int[]{longSide, shortSide};
    }

    private int clampFpsForDevice(int requestedFps, String resolution) {
        int maxFps = requestedFps;
        if (RecordingPreferences.RES_1080P.equals(resolution) && requestedFps > 60) {
            maxFps = 60;
        }
        return Math.max(24, Math.min(maxFps, 90));
    }

    private int calculateBitrate(int width, int height, int fps) {
        float pixels = (float) width * height;
        float fpsFactor = fps / 30.0f;
        int bps = Math.round(pixels * 0.14f * fpsFactor * 30.0f);
        return Math.max(1_200_000, Math.min(bps, 16_000_000));
    }

    private int even(int value) {
        return (value % 2 == 0) ? value : value - 1;
    }

    @Override
    public void onDestroy() {
        stopRecordingSession(false);
        removeFloatingBubble();
        super.onDestroy();
    }

    @Nullable
    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }
}
