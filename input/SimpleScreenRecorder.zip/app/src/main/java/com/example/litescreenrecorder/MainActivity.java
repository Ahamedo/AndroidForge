package com.example.litescreenrecorder;

import android.Manifest;
import android.app.Activity;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.PackageManager;
import android.media.projection.MediaProjectionManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.view.View;
import android.widget.Button;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

import com.google.android.material.materialswitch.MaterialSwitch;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    private RecordingPreferences preferences;
    private MediaProjectionManager projectionManager;

    private RadioGroup resolutionGroup;
    private RadioGroup fpsGroup;
    private RadioGroup audioGroup;
    private MaterialSwitch floatingBubbleSwitch;
    private TextView statusText;
    private TextView lastFileText;
    private Button primaryActionBtn;
    private Button pauseResumeBtn;

    private boolean pendingStartAfterProjection = false;

    private final ActivityResultLauncher<String[]> runtimePermissionsLauncher =
            registerForActivityResult(new ActivityResultContracts.RequestMultiplePermissions(), result -> {
                if (pendingStartAfterProjection) {
                    requestScreenCaptureConsent();
                }
            });

    private final ActivityResultLauncher<Intent> overlayPermissionLauncher =
            registerForActivityResult(new ActivityResultContracts.StartActivityForResult(), result -> {
                boolean granted = Build.VERSION.SDK_INT < Build.VERSION_CODES.M || Settings.canDrawOverlays(this);
                preferences.setFloatingBubbleEnabled(granted);
                floatingBubbleSwitch.setChecked(granted);
                if (granted) {
                    ScreenRecordService.showFloatingBubble(this);
                } else {
                    Toast.makeText(this, R.string.overlay_permission_required, Toast.LENGTH_SHORT).show();
                }
                syncUiWithServiceState();
            });

    private final ActivityResultLauncher<Intent> screenCaptureLauncher =
            registerForActivityResult(new ActivityResultContracts.StartActivityForResult(), result -> {
                pendingStartAfterProjection = false;
                if (result.getResultCode() == Activity.RESULT_OK && result.getData() != null) {
                    Intent startIntent = new Intent(this, ScreenRecordService.class);
                    startIntent.setAction(ScreenRecordService.ACTION_START_RECORDING);
                    startIntent.putExtra(ScreenRecordService.EXTRA_RESULT_CODE, result.getResultCode());
                    startIntent.putExtra(ScreenRecordService.EXTRA_RESULT_DATA, result.getData());
                    startIntent.putExtra(ScreenRecordService.EXTRA_RESOLUTION, preferences.getResolution());
                    startIntent.putExtra(ScreenRecordService.EXTRA_FPS, preferences.getFps());
                    startIntent.putExtra(ScreenRecordService.EXTRA_AUDIO_MODE, preferences.getAudioMode());
                    ContextCompat.startForegroundService(this, startIntent);
                } else {
                    Toast.makeText(this, R.string.capture_permission_denied, Toast.LENGTH_SHORT).show();
                }
                syncUiWithServiceState();
            });

    private final BroadcastReceiver stateReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            syncUiWithServiceState();
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        preferences = new RecordingPreferences(this);
        projectionManager = (MediaProjectionManager) getSystemService(Context.MEDIA_PROJECTION_SERVICE);

        resolutionGroup = findViewById(R.id.resolution_group);
        fpsGroup = findViewById(R.id.fps_group);
        audioGroup = findViewById(R.id.audio_group);
        floatingBubbleSwitch = findViewById(R.id.floating_bubble_switch);
        statusText = findViewById(R.id.status_text);
        lastFileText = findViewById(R.id.last_file_text);
        primaryActionBtn = findViewById(R.id.primary_action_btn);
        pauseResumeBtn = findViewById(R.id.pause_resume_btn);

        loadSavedSettingsIntoUi();
        bindListeners();
    }

    @Override
    protected void onResume() {
        super.onResume();
        IntentFilter filter = new IntentFilter(ScreenRecordService.ACTION_STATE_CHANGED);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            registerReceiver(stateReceiver, filter, Context.RECEIVER_NOT_EXPORTED);
        } else {
            registerReceiver(stateReceiver, filter);
        }
        syncUiWithServiceState();
    }

    @Override
    protected void onPause() {
        super.onPause();
        try {
            unregisterReceiver(stateReceiver);
        } catch (IllegalArgumentException ignored) {
        }
    }

    private void loadSavedSettingsIntoUi() {
        String res = preferences.getResolution();
        if (RecordingPreferences.RES_480P.equals(res)) {
            resolutionGroup.check(R.id.res_480p);
        } else if (RecordingPreferences.RES_1080P.equals(res)) {
            resolutionGroup.check(R.id.res_1080p);
        } else {
            resolutionGroup.check(R.id.res_720p);
        }

        int fps = preferences.getFps();
        if (fps == RecordingPreferences.FPS_60) {
            fpsGroup.check(R.id.fps_60);
        } else if (fps == RecordingPreferences.FPS_90) {
            fpsGroup.check(R.id.fps_90);
        } else {
            fpsGroup.check(R.id.fps_30);
        }

        String audioMode = preferences.getAudioMode();
        if (RecordingPreferences.AUDIO_INTERNAL_AND_MIC.equals(audioMode)) {
            audioGroup.check(R.id.audio_internal_mic);
        } else {
            audioGroup.check(R.id.audio_internal_only);
        }

        boolean overlayAllowed = Build.VERSION.SDK_INT < Build.VERSION_CODES.M || Settings.canDrawOverlays(this);
        floatingBubbleSwitch.setChecked(preferences.isFloatingBubbleEnabled() && overlayAllowed);
    }

    private void bindListeners() {
        resolutionGroup.setOnCheckedChangeListener((group, checkedId) -> {
            if (checkedId == R.id.res_480p) {
                preferences.setResolution(RecordingPreferences.RES_480P);
            } else if (checkedId == R.id.res_1080p) {
                preferences.setResolution(RecordingPreferences.RES_1080P);
            } else {
                preferences.setResolution(RecordingPreferences.RES_720P);
            }
        });

        fpsGroup.setOnCheckedChangeListener((group, checkedId) -> {
            if (checkedId == R.id.fps_60) {
                preferences.setFps(RecordingPreferences.FPS_60);
            } else if (checkedId == R.id.fps_90) {
                preferences.setFps(RecordingPreferences.FPS_90);
            } else {
                preferences.setFps(RecordingPreferences.FPS_30);
            }
        });

        audioGroup.setOnCheckedChangeListener((group, checkedId) -> {
            if (checkedId == R.id.audio_internal_mic) {
                preferences.setAudioMode(RecordingPreferences.AUDIO_INTERNAL_AND_MIC);
            } else {
                preferences.setAudioMode(RecordingPreferences.AUDIO_INTERNAL_ONLY);
            }
        });

        floatingBubbleSwitch.setOnCheckedChangeListener((buttonView, isChecked) -> {
            if (!buttonView.isPressed()) return;
            if (isChecked) {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && !Settings.canDrawOverlays(this)) {
                    floatingBubbleSwitch.setChecked(false);
                    Intent intent = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                            Uri.parse("package:" + getPackageName()));
                    overlayPermissionLauncher.launch(intent);
                    return;
                }
                preferences.setFloatingBubbleEnabled(true);
                ScreenRecordService.showFloatingBubble(this);
            } else {
                preferences.setFloatingBubbleEnabled(false);
                ScreenRecordService.hideFloatingBubble(this);
            }
        });

        primaryActionBtn.setOnClickListener(v -> {
            if (ScreenRecordService.isRecordingActive()) {
                ScreenRecordService.stopRecording(this);
            } else {
                beginRecordingFlow();
            }
        });

        pauseResumeBtn.setOnClickListener(v -> {
            if (!ScreenRecordService.isRecordingActive()) return;
            if (ScreenRecordService.isPausedState()) {
                ScreenRecordService.resumeRecording(this);
            } else {
                ScreenRecordService.pauseRecording(this);
            }
        });
    }

    private void beginRecordingFlow() {
        List<String> needed = new ArrayList<>();
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS)
                    != PackageManager.PERMISSION_GRANTED) {
                needed.add(Manifest.permission.POST_NOTIFICATIONS);
            }
        }
        boolean needsMic = RecordingPreferences.AUDIO_INTERNAL_AND_MIC.equals(preferences.getAudioMode());
        if (needsMic && ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO)
                != PackageManager.PERMISSION_GRANTED) {
            needed.add(Manifest.permission.RECORD_AUDIO);
        }
        if (Build.VERSION.SDK_INT <= Build.VERSION_CODES.P) {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.WRITE_EXTERNAL_STORAGE)
                    != PackageManager.PERMISSION_GRANTED) {
                needed.add(Manifest.permission.WRITE_EXTERNAL_STORAGE);
            }
        }

        pendingStartAfterProjection = true;
        if (!needed.isEmpty()) {
            runtimePermissionsLauncher.launch(needed.toArray(new String[0]));
        } else {
            requestScreenCaptureConsent();
        }
    }

    private void requestScreenCaptureConsent() {
        if (projectionManager == null) return;
        screenCaptureLauncher.launch(projectionManager.createScreenCaptureIntent());
    }

    private void syncUiWithServiceState() {
        boolean recording = ScreenRecordService.isRecordingActive();
        boolean paused = ScreenRecordService.isPausedState();

        if (!recording) {
            statusText.setText(getString(R.string.status_idle));
            primaryActionBtn.setText(getString(R.string.action_start_recording));
            pauseResumeBtn.setVisibility(View.GONE);
        } else if (paused) {
            statusText.setText(getString(R.string.status_paused));
            primaryActionBtn.setText(getString(R.string.action_stop_save));
            pauseResumeBtn.setVisibility(View.VISIBLE);
            pauseResumeBtn.setText(getString(R.string.action_resume));
        } else {
            statusText.setText(getString(R.string.status_recording));
            primaryActionBtn.setText(getString(R.string.action_stop_save));
            pauseResumeBtn.setVisibility(View.VISIBLE);
            pauseResumeBtn.setText(getString(R.string.action_pause));
        }

        String lastFile = ScreenRecordService.getLastSavedFilePath();
        if (lastFile != null && !lastFile.isEmpty()) {
            lastFileText.setVisibility(View.VISIBLE);
            lastFileText.setText(getString(R.string.last_saved_prefix, lastFile));
        } else {
            lastFileText.setVisibility(View.GONE);
        }

        boolean overlayAllowed = Build.VERSION.SDK_INT < Build.VERSION_CODES.M || Settings.canDrawOverlays(this);
        floatingBubbleSwitch.setChecked(preferences.isFloatingBubbleEnabled() && overlayAllowed);
    }
}
