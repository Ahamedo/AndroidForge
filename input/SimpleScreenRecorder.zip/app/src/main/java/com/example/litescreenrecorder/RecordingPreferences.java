package com.example.litescreenrecorder;

import android.content.Context;
import android.content.SharedPreferences;

public class RecordingPreferences {

    private static final String PREFS_NAME = "lite_recorder_prefs";

    public static final String KEY_RESOLUTION = "resolution";
    public static final String KEY_FPS = "fps";
    public static final String KEY_AUDIO_MODE = "audio_mode";
    public static final String KEY_FLOATING_BUBBLE = "floating_bubble";

    public static final String RES_480P = "480p";
    public static final String RES_720P = "720p";
    public static final String RES_1080P = "1080p";

    public static final int FPS_30 = 30;
    public static final int FPS_60 = 60;
    public static final int FPS_90 = 90;

    public static final String AUDIO_INTERNAL_ONLY = "internal_only";
    public static final String AUDIO_INTERNAL_AND_MIC = "internal_and_mic";

    private final SharedPreferences prefs;

    public RecordingPreferences(Context context) {
        this.prefs = context.getApplicationContext().getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
    }

    public String getResolution() {
        return prefs.getString(KEY_RESOLUTION, RES_720P);
    }

    public void setResolution(String resolution) {
        prefs.edit().putString(KEY_RESOLUTION, resolution).apply();
    }

    public int getFps() {
        return prefs.getInt(KEY_FPS, FPS_30);
    }

    public void setFps(int fps) {
        prefs.edit().putInt(KEY_FPS, fps).apply();
    }

    public String getAudioMode() {
        return prefs.getString(KEY_AUDIO_MODE, AUDIO_INTERNAL_ONLY);
    }

    public void setAudioMode(String audioMode) {
        prefs.edit().putString(KEY_AUDIO_MODE, audioMode).apply();
    }

    public boolean isFloatingBubbleEnabled() {
        return prefs.getBoolean(KEY_FLOATING_BUBBLE, false);
    }

    public void setFloatingBubbleEnabled(boolean enabled) {
        prefs.edit().putBoolean(KEY_FLOATING_BUBBLE, enabled).apply();
    }
}
