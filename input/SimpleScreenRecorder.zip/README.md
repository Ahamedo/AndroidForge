# مسجل الشاشة الخفيف (LiteScreenRecorder)

مشروع أندرويد خفيف مبني بلغة Java وواجهة Material بسيطة بدون مكتبات ثقيلة، ومهيأ للبناء السحابي عبر GitHub Actions وAndroidForge.

## محتويات المشروع
- `app/src/main/AndroidManifest.xml`: الأذونات والخدمة الأمامية من نوع `mediaProjection`.
- `app/src/main/java/com/example/litescreenrecorder/RecordingPreferences.java`: حفظ إعدادات الجودة ومعدل الإطارات والصوت والكرة العائمة.
- `app/src/main/java/com/example/litescreenrecorder/MainActivity.java`: الواجهة الرئيسية وإدارة الأذونات ومزامنة الحالة في `onResume`.
- `app/src/main/java/com/example/litescreenrecorder/ScreenRecordService.java`: تسجيل الشاشة والمرمّزات والصوت الداخلي والميكروفون والكرة العائمة وحفظ MP4 وتنبيه ماسح الوسائط.
