package com.example.simplescreenrecorderlite;

import android.content.Context;
import android.content.SharedPreferences;

public final class RecorderPrefs {

    public static final String PREFS_NAME = "recorder_lite_prefs";
    public static final String KEY_RESOLUTION = "resolution";
    public static final String KEY_FPS = "fps";
    public static final String KEY_AUDIO_MODE = "audio_mode";
    public static final String KEY_BUBBLE_ENABLED = "bubble_enabled";

    public static final String RES_480 = "480p";
    public static final String RES_720 = "720p";
    public static final String RES_1080 = "1080p";

    public static final String AUDIO_INTERNAL_ONLY = "INTERNAL_ONLY";
    public static final String AUDIO_INTERNAL_AND_MIC = "INTERNAL_AND_MIC";

    private RecorderPrefs() {
    }

    public static SharedPreferences get(Context context) {
        return context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
    }

    public static String getResolution(Context context) {
        return get(context).getString(KEY_RESOLUTION, RES_720);
    }

    public static void setResolution(Context context, String res) {
        get(context).edit().putString(KEY_RESOLUTION, res).apply();
    }

    public static int getFps(Context context) {
        return get(context).getInt(KEY_FPS, 30);
    }

    public static void setFps(Context context, int fps) {
        get(context).edit().putInt(KEY_FPS, fps).apply();
    }

    public static String getAudioMode(Context context) {
        return get(context).getString(KEY_AUDIO_MODE, AUDIO_INTERNAL_ONLY);
    }

    public static void setAudioMode(Context context, String mode) {
        get(context).edit().putString(KEY_AUDIO_MODE, mode).apply();
    }

    public static boolean isBubbleEnabled(Context context) {
        return get(context).getBoolean(KEY_BUBBLE_ENABLED, true);
    }

    public static void setBubbleEnabled(Context context, boolean enabled) {
        get(context).edit().putBoolean(KEY_BUBBLE_ENABLED, enabled).apply();
    }
}
