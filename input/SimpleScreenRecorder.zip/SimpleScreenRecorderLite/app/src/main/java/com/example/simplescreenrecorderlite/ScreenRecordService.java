package com.example.simplescreenrecorderlite;

import android.Manifest;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.ServiceInfo;
import android.graphics.PixelFormat;
import android.hardware.display.DisplayManager;
import android.hardware.display.VirtualDisplay;
import android.media.AudioAttributes;
import android.media.AudioFormat;
import android.media.AudioPlaybackCaptureConfiguration;
import android.media.AudioRecord;
import android.media.MediaCodec;
import android.media.MediaCodecInfo;
import android.media.MediaFormat;
import android.media.MediaMuxer;
import android.media.MediaRecorder;
import android.media.projection.MediaProjection;
import android.media.projection.MediaProjectionManager;
import android.os.Build;
import android.os.Environment;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.provider.Settings;
import android.util.DisplayMetrics;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.Surface;
import android.view.View;
import android.view.WindowManager;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.core.app.ActivityCompat;
import androidx.core.app.NotificationCompat;

import java.io.File;
import java.io.IOException;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;
import java.util.concurrent.atomic.AtomicBoolean;

public class ScreenRecordService extends Service {

    public static final String ACTION_SHOW_BUBBLE = "com.example.simplescreenrecorderlite.SHOW_BUBBLE";
    public static final String ACTION_HIDE_BUBBLE = "com.example.simplescreenrecorderlite.HIDE_BUBBLE";
    public static final String ACTION_START_RECORDING = "com.example.simplescreenrecorderlite.START_REC";
    public static final String ACTION_PAUSE = "com.example.simplescreenrecorderlite.PAUSE_REC";
    public static final String ACTION_RESUME = "com.example.simplescreenrecorderlite.RESUME_REC";
    public static final String ACTION_STOP_RECORDING = "com.example.simplescreenrecorderlite.STOP_REC";

    public static final String EXTRA_RESULT_CODE = "result_code";
    public static final String EXTRA_RESULT_DATA = "result_data";

    private static final String CHANNEL_ID = "recorder_lite_channel";
    private static final int NOTIF_ID = 2001;

    private static final int SAMPLE_RATE = 44100;
    private static final int CHANNEL_COUNT = 1;

    private final Handler mainHandler = new Handler(Looper.getMainLooper());
    private WindowManager windowManager;
    private View bubbleView;
    private TextView btnBubbleRec;
    private TextView btnBubblePause;
    private TextView btnBubbleStop;

    private MediaProjectionManager projectionManager;
    private MediaProjection mediaProjection;
    private VirtualDisplay virtualDisplay;

    private MediaCodec videoEncoder;
    private Surface inputSurface;
    private MediaCodec audioEncoder;
    private MediaMuxer muxer;

    private AudioRecord internalAudioRecord;
    private AudioRecord micAudioRecord;

    private Thread videoDrainThread;
    private Thread audioCaptureThread;

    private final AtomicBoolean isRecording = new AtomicBoolean(false);
    private final AtomicBoolean isPaused = new AtomicBoolean(false);
    private final AtomicBoolean muxerStarted = new AtomicBoolean(false);

    private int videoTrackIndex = -1;
    private int audioTrackIndex = -1;
    private long pausedAccumulatedUs = 0L;
    private long pauseStartElapsedUs = 0L;
    private long recordingStartElapsedUs = 0L;

    private int lastResultCode = 0;
    private Intent lastResultData = null;
    private String lastOutputPath = null;

    private final MediaProjection.Callback projectionCallback = new MediaProjection.Callback() {
        @Override
        public void onStop() {
            mainHandler.post(() -> stopRecordingInternal(true));
        }
    };

    @Override
    public void onCreate() {
        super.onCreate();
        projectionManager = (MediaProjectionManager) getSystemService(MEDIA_PROJECTION_SERVICE);
        windowManager = (WindowManager) getSystemService(WINDOW_SERVICE);
        createNotificationChannel();
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent == null) {
            return START_NOT_STICKY;
        }

        ensureForeground(getString(R.string.notif_text_idle));

        String action = intent.getAction();
        if (ACTION_SHOW_BUBBLE.equals(action)) {
            showFloatingBubble();
        } else if (ACTION_HIDE_BUBBLE.equals(action)) {
            hideFloatingBubble();
            if (!isRecording.get()) {
                stopForeground(STOP_FOREGROUND_REMOVE);
                stopSelf();
            }
        } else if (ACTION_START_RECORDING.equals(action)) {
            int code = intent.getIntExtra(EXTRA_RESULT_CODE, 0);
            Intent data = intent.getParcelableExtra(EXTRA_RESULT_DATA);
            if (code != 0 && data != null) {
                lastResultCode = code;
                lastResultData = data;
                startRecordingSession(code, data);
            } else {
                openMainActivityForCapture();
            }
        } else if (ACTION_PAUSE.equals(action)) {
            pauseRecordingInternal();
        } else if (ACTION_RESUME.equals(action)) {
            resumeRecordingInternal();
        } else if (ACTION_STOP_RECORDING.equals(action)) {
            stopRecordingInternal(false);
        }

        return START_NOT_STICKY;
    }

    private void ensureForeground(String text) {
        Intent openIntent = new Intent(this, MainActivity.class);
        PendingIntent pendingIntent = PendingIntent.getActivity(
                this, 0, openIntent, PendingIntent.FLAG_IMMUTABLE
        );

        Notification notification = new NotificationCompat.Builder(this, CHANNEL_ID)
                .setContentTitle(getString(R.string.notif_title))
                .setContentText(text)
                .setSmallIcon(android.R.drawable.ic_media_ff)
                .setContentIntent(pendingIntent)
                .setOngoing(true)
                .build();

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            startForeground(NOTIF_ID, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION);
        } else {
            startForeground(NOTIF_ID, notification);
        }
    }

    private void showFloatingBubble() {
        if (bubbleView != null || windowManager == null) {
            return;
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && !Settings.canDrawOverlays(this)) {
            return;
        }

        bubbleView = LayoutInflater.from(this).inflate(R.layout.floating_bubble, null);
        btnBubbleRec = bubbleView.findViewById(R.id.btnBubbleRec);
        btnBubblePause = bubbleView.findViewById(R.id.btnBubblePause);
        btnBubbleStop = bubbleView.findViewById(R.id.btnBubbleStop);

        int layoutType = Build.VERSION.SDK_INT >= Build.VERSION_CODES.O
                ? WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
                : WindowManager.LayoutParams.TYPE_PHONE;

        final WindowManager.LayoutParams params = new WindowManager.LayoutParams(
                WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.WRAP_CONTENT,
                layoutType,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
                PixelFormat.TRANSLUCENT
        );
        params.gravity = Gravity.TOP | Gravity.START;
        params.x = 32;
        params.y = 260;

        bubbleView.setOnTouchListener(new View.OnTouchListener() {
            private int initialX;
            private int initialY;
            private float initialTouchX;
            private float initialTouchY;
            private boolean moved;

            @Override
            public boolean onTouch(View v, MotionEvent event) {
                switch (event.getAction()) {
                    case MotionEvent.ACTION_DOWN:
                        initialX = params.x;
                        initialY = params.y;
                        initialTouchX = event.getRawX();
                        initialTouchY = event.getRawY();
                        moved = false;
                        return false;
                    case MotionEvent.ACTION_MOVE:
                        int dx = Math.round(event.getRawX() - initialTouchX);
                        int dy = Math.round(event.getRawY() - initialTouchY);
                        if (Math.abs(dx) > 8 || Math.abs(dy) > 8) {
                            moved = true;
                        }
                        params.x = Math.max(0, initialX + dx);
                        params.y = Math.max(0, initialY + dy);
                        windowManager.updateViewLayout(bubbleView, params);
                        return moved;
                    default:
                        return false;
                }
            }
        });

        btnBubbleRec.setOnClickListener(v -> {
            if (!isRecording.get()) {
                if (lastResultCode != 0 && lastResultData != null) {
                    startRecordingSession(lastResultCode, lastResultData);
                } else {
                    openMainActivityForCapture();
                }
            }
        });

        btnBubblePause.setOnClickListener(v -> {
            if (isRecording.get()) {
                if (!isPaused.get()) {
                    pauseRecordingInternal();
                } else {
                    resumeRecordingInternal();
                }
            }
        });

        btnBubbleStop.setOnClickListener(v -> {
            if (isRecording.get()) {
                stopRecordingInternal(false);
            }
        });

        windowManager.addView(bubbleView, params);
        refreshBubbleState();
    }

    private void hideFloatingBubble() {
        if (bubbleView != null && windowManager != null) {
            try {
                windowManager.removeView(bubbleView);
            } catch (RuntimeException ignored) {
            }
            bubbleView = null;
        }
    }

    private void refreshBubbleState() {
        if (btnBubbleRec == null || btnBubblePause == null || btnBubbleStop == null) {
            return;
        }
        boolean rec = isRecording.get();
        boolean paused = isPaused.get();
        btnBubbleRec.setAlpha(rec ? 0.4f : 1.0f);
        btnBubblePause.setAlpha(rec ? 1.0f : 0.4f);
        btnBubbleStop.setAlpha(rec ? 1.0f : 0.4f);
        btnBubblePause.setText(paused ? "RESUME" : "PAUSE");
    }

    private void openMainActivityForCapture() {
        Intent launch = new Intent(this, MainActivity.class);
        launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_SINGLE_TOP);
        startActivity(launch);
        Toast.makeText(this, "Tap Start Recording to grant screen capture", Toast.LENGTH_SHORT).show();
    }

    private void startRecordingSession(int resultCode, Intent data) {
        if (isRecording.get()) {
            return;
        }

        try {
            String resPref = RecorderPrefs.getResolution(this);
            int fps = RecorderPrefs.getFps(this);
            String audioMode = RecorderPrefs.getAudioMode(this);

            DisplayMetrics metrics = new DisplayMetrics();
            WindowManager wm = (WindowManager) getSystemService(WINDOW_SERVICE);
            if (wm != null && wm.getDefaultDisplay() != null) {
                wm.getDefaultDisplay().getRealMetrics(metrics);
            } else {
                metrics = getResources().getDisplayMetrics();
            }

            boolean portrait = metrics.heightPixels >= metrics.widthPixels;
            int shortSide;
            switch (resPref) {
                case RecorderPrefs.RES_480:
                    shortSide = 480;
                    break;
                case RecorderPrefs.RES_1080:
                    shortSide = 1080;
                    break;
                case RecorderPrefs.RES_720:
                default:
                    shortSide = 720;
                    break;
            }
            int longSide = Math.round(shortSide * (16f / 9f));
            int width = portrait ? shortSide : longSide;
            int height = portrait ? longSide : shortSide;
            int density = metrics.densityDpi;
            int bitrate = (resPref.equals(RecorderPrefs.RES_1080) ? 6_000_000 :
                    resPref.equals(RecorderPrefs.RES_720) ? 3_500_000 : 1_800_000)
                    * Math.max(1, fps / 30);

            File baseDir = getExternalFilesDir(Environment.DIRECTORY_MOVIES);
            if (baseDir == null) {
                baseDir = getFilesDir();
            }
            File outDir = new File(baseDir, "SimpleScreenRecorderLite");
            if (!outDir.exists() && !outDir.mkdirs()) {
                outDir = baseDir;
            }
            String stamp = new SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(new Date());
            File outFile = new File(outDir, "rec_" + stamp + ".mp4");
            lastOutputPath = outFile.getAbsolutePath();

            MediaFormat videoFormat = MediaFormat.createVideoFormat(MediaFormat.MIMETYPE_VIDEO_AVC, width, height);
            videoFormat.setInteger(MediaFormat.KEY_COLOR_FORMAT, MediaCodecInfo.CodecCapabilities.COLOR_FormatSurface);
            videoFormat.setInteger(MediaFormat.KEY_BIT_RATE, bitrate);
            videoFormat.setInteger(MediaFormat.KEY_FRAME_RATE, fps);
            videoFormat.setInteger(MediaFormat.KEY_I_FRAME_INTERVAL, 1);

            videoEncoder = MediaCodec.createEncoderByType(MediaFormat.MIMETYPE_VIDEO_AVC);
            videoEncoder.configure(videoFormat, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE);
            inputSurface = videoEncoder.createInputSurface();
            videoEncoder.start();

            boolean enableAudio = Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q;
            if (enableAudio) {
                MediaFormat audioFormat = MediaFormat.createAudioFormat(
                        MediaFormat.MIMETYPE_AUDIO_AAC, SAMPLE_RATE, CHANNEL_COUNT
                );
                audioFormat.setInteger(MediaFormat.KEY_AAC_PROFILE, MediaCodecInfo.CodecProfileLevel.AACObjectLC);
                audioFormat.setInteger(MediaFormat.KEY_BIT_RATE, 128_000);
                audioEncoder = MediaCodec.createEncoderByType(MediaFormat.MIMETYPE_AUDIO_AAC);
                audioEncoder.configure(audioFormat, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE);
                audioEncoder.start();
                setupAudioRecorders(audioMode);
            }

            muxer = new MediaMuxer(lastOutputPath, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4);
            videoTrackIndex = -1;
            audioTrackIndex = -1;
            muxerStarted.set(false);
            pausedAccumulatedUs = 0L;
            pauseStartElapsedUs = 0L;
            recordingStartElapsedUs = System.nanoTime() / 1000L;

            mediaProjection = projectionManager.getMediaProjection(resultCode, data);
            mediaProjection.registerCallback(projectionCallback, mainHandler);

            virtualDisplay = mediaProjection.createVirtualDisplay(
                    "RecorderLiteDisplay",
                    width,
                    height,
                    density,
                    DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
                    inputSurface,
                    null,
                    null
            );

            isRecording.set(true);
            isPaused.set(false);
            ensureForeground(getString(R.string.notif_text_recording));
            refreshBubbleState();

            startVideoDrainLoop();
            if (enableAudio && audioEncoder != null) {
                startAudioCaptureLoop();
            }

            Toast.makeText(this, "Recording started (" + resPref + " @ " + fps + "fps)", Toast.LENGTH_SHORT).show();
        } catch (IOException | RuntimeException e) {
            releaseMediaResources();
            isRecording.set(false);
            isPaused.set(false);
            refreshBubbleState();
            Toast.makeText(this, "Failed to start: " + e.getMessage(), Toast.LENGTH_LONG).show();
        }
    }

    private void setupAudioRecorders(String audioMode) {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.Q || mediaProjection == null) {
            return;
        }
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            return;
        }

        int minBuf = AudioRecord.getMinBufferSize(
                SAMPLE_RATE,
                AudioFormat.CHANNEL_IN_MONO,
                AudioFormat.ENCODING_PCM_16BIT
        );
        int bufferSize = Math.max(minBuf * 2, 4096);

        AudioPlaybackCaptureConfiguration config = new AudioPlaybackCaptureConfiguration.Builder(mediaProjection)
                .addMatchingUsage(AudioAttributes.USAGE_MEDIA)
                .addMatchingUsage(AudioAttributes.USAGE_GAME)
                .addMatchingUsage(AudioAttributes.USAGE_UNKNOWN)
                .build();

        AudioFormat pcmFormat = new AudioFormat.Builder()
                .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                .setSampleRate(SAMPLE_RATE)
                .setChannelMask(AudioFormat.CHANNEL_IN_MONO)
                .build();

        internalAudioRecord = new AudioRecord.Builder()
                .setAudioFormat(pcmFormat)
                .setBufferSizeInBytes(bufferSize)
                .setAudioPlaybackCaptureConfig(config)
                .build();

        if (internalAudioRecord.getState() == AudioRecord.STATE_INITIALIZED) {
            internalAudioRecord.startRecording();
        } else {
            internalAudioRecord.release();
            internalAudioRecord = null;
        }

        if (RecorderPrefs.AUDIO_INTERNAL_AND_MIC.equals(audioMode)) {
            micAudioRecord = new AudioRecord(
                    MediaRecorder.AudioSource.MIC,
                    SAMPLE_RATE,
                    AudioFormat.CHANNEL_IN_MONO,
                    AudioFormat.ENCODING_PCM_16BIT,
                    bufferSize
            );
            if (micAudioRecord.getState() == AudioRecord.STATE_INITIALIZED) {
                micAudioRecord.startRecording();
            } else {
                micAudioRecord.release();
                micAudioRecord = null;
            }
        }
    }

    private long currentAdjustedPtsUs() {
        long nowUs = System.nanoTime() / 1000L;
        long activePauseUs = isPaused.get() && pauseStartElapsedUs > 0L
                ? (nowUs - pauseStartElapsedUs)
                : 0L;
        return Math.max(0L, nowUs - recordingStartElapsedUs - pausedAccumulatedUs - activePauseUs);
    }

    private void startVideoDrainLoop() {
        videoDrainThread = new Thread(() -> {
            MediaCodec.BufferInfo info = new MediaCodec.BufferInfo();
            while (isRecording.get() && videoEncoder != null) {
                try {
                    int outIndex = videoEncoder.dequeueOutputBuffer(info, 10_000);
                    if (outIndex == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) {
                        synchronized (ScreenRecordService.this) {
                            if (videoTrackIndex == -1 && muxer != null) {
                                videoTrackIndex = muxer.addTrack(videoEncoder.getOutputFormat());
                                maybeStartMuxer();
                            }
                        }
                    } else if (outIndex >= 0) {
                        ByteBuffer encodedData = videoEncoder.getOutputBuffer(outIndex);
                        if (encodedData != null && info.size > 0 && !isPaused.get() && muxerStarted.get()) {
                            info.presentationTimeUs = currentAdjustedPtsUs();
                            encodedData.position(info.offset);
                            encodedData.limit(info.offset + info.size);
                            synchronized (ScreenRecordService.this) {
                                muxer.writeSampleData(videoTrackIndex, encodedData, info);
                            }
                        }
                        videoEncoder.releaseOutputBuffer(outIndex, false);
                        if ((info.flags & MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0) {
                            break;
                        }
                    }
                } catch (RuntimeException e) {
                    break;
                }
            }
        }, "VideoEncoderThread");
        videoDrainThread.start();
    }

    private void startAudioCaptureLoop() {
        audioCaptureThread = new Thread(() -> {
            byte[] internalBuf = new byte[2048];
            byte[] micBuf = new byte[2048];
            MediaCodec.BufferInfo outInfo = new MediaCodec.BufferInfo();

            while (isRecording.get() && audioEncoder != null) {
                try {
                    if (!isPaused.get()) {
                        int readInternal = internalAudioRecord != null
                                ? internalAudioRecord.read(internalBuf, 0, internalBuf.length)
                                : 0;
                        int readMic = micAudioRecord != null
                                ? micAudioRecord.read(micBuf, 0, micBuf.length)
                                : 0;

                        int validBytes = Math.max(Math.max(0, readInternal), Math.max(0, readMic));
                        if (validBytes > 0) {
                            byte[] mixed = mixPcm16(internalBuf, readInternal, micBuf, readMic, validBytes);
                            feedAudioToEncoder(mixed, validBytes, currentAdjustedPtsUs());
                        }
                    }
                    drainAudioEncoder(outInfo, 2_000);
                } catch (RuntimeException e) {
                    break;
                }
            }
        }, "AudioCaptureThread");
        audioCaptureThread.start();
    }

    private byte[] mixPcm16(byte[] a, int lenA, byte[] b, int lenB, int totalBytes) {
        byte[] out = new byte[totalBytes];
        ByteBuffer bufA = ByteBuffer.wrap(a, 0, Math.max(0, lenA)).order(ByteOrder.LITTLE_ENDIAN);
        ByteBuffer bufB = ByteBuffer.wrap(b, 0, Math.max(0, lenB)).order(ByteOrder.LITTLE_ENDIAN);
        ByteBuffer bufOut = ByteBuffer.wrap(out).order(ByteOrder.LITTLE_ENDIAN);

        int samples = totalBytes / 2;
        for (int i = 0; i < samples; i++) {
            short sA = bufA.remaining() >= 2 ? bufA.getShort() : 0;
            short sB = bufB.remaining() >= 2 ? bufB.getShort() : 0;
            int sum = (int) sA + (int) sB;
            if (sum > Short.MAX_VALUE) {
                sum = Short.MAX_VALUE;
            } else if (sum < Short.MIN_VALUE) {
                sum = Short.MIN_VALUE;
            }
            bufOut.putShort((short) sum);
        }
        return out;
    }

    private void feedAudioToEncoder(byte[] pcmData, int length, long ptsUs) {
        if (audioEncoder == null || length <= 0) {
            return;
        }
        int inIndex = audioEncoder.dequeueInputBuffer(5_000);
        if (inIndex >= 0) {
            ByteBuffer inputBuffer = audioEncoder.getInputBuffer(inIndex);
            if (inputBuffer != null) {
                inputBuffer.clear();
                int toCopy = Math.min(length, inputBuffer.remaining());
                inputBuffer.put(pcmData, 0, toCopy);
                audioEncoder.queueInputBuffer(inIndex, 0, toCopy, ptsUs, 0);
            }
        }
    }

    private void drainAudioEncoder(MediaCodec.BufferInfo info, long timeoutUs) {
        if (audioEncoder == null) {
            return;
        }
        int outIndex = audioEncoder.dequeueOutputBuffer(info, timeoutUs);
        if (outIndex == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) {
            synchronized (ScreenRecordService.this) {
                if (audioTrackIndex == -1 && muxer != null) {
                    audioTrackIndex = muxer.addTrack(audioEncoder.getOutputFormat());
                    maybeStartMuxer();
                }
            }
        } else if (outIndex >= 0) {
            ByteBuffer encoded = audioEncoder.getOutputBuffer(outIndex);
            if (encoded != null && info.size > 0 && !isPaused.get() && muxerStarted.get() && audioTrackIndex != -1) {
                info.presentationTimeUs = currentAdjustedPtsUs();
                encoded.position(info.offset);
                encoded.limit(info.offset + info.size);
                synchronized (ScreenRecordService.this) {
                    muxer.writeSampleData(audioTrackIndex, encoded, info);
                }
            }
            audioEncoder.releaseOutputBuffer(outIndex, false);
        }
    }

    private void maybeStartMuxer() {
        if (muxer == null || muxerStarted.get()) {
            return;
        }
        boolean expectsAudio = audioEncoder != null;
        boolean videoReady = videoTrackIndex != -1;
        boolean audioReady = !expectsAudio || audioTrackIndex != -1;
        if (videoReady && audioReady) {
            muxer.start();
            muxerStarted.set(true);
        }
    }

    private void pauseRecordingInternal() {
        if (!isRecording.get() || isPaused.get()) {
            return;
        }
        isPaused.set(true);
        pauseStartElapsedUs = System.nanoTime() / 1000L;
        ensureForeground(getString(R.string.notif_text_paused));
        refreshBubbleState();
        Toast.makeText(this, "Recording paused", Toast.LENGTH_SHORT).show();
    }

    private void resumeRecordingInternal() {
        if (!isRecording.get() || !isPaused.get()) {
            return;
        }
        long nowUs = System.nanoTime() / 1000L;
        if (pauseStartElapsedUs > 0L) {
            pausedAccumulatedUs += Math.max(0L, nowUs - pauseStartElapsedUs);
            pauseStartElapsedUs = 0L;
        }
        isPaused.set(false);
        ensureForeground(getString(R.string.notif_text_recording));
        refreshBubbleState();
        Toast.makeText(this, "Recording resumed", Toast.LENGTH_SHORT).show();
    }

    private void stopRecordingInternal(boolean fromSystemCallback) {
        if (!isRecording.get()) {
            releaseMediaResources();
            refreshBubbleState();
            return;
        }

        isRecording.set(false);
        isPaused.set(false);

        if (videoDrainThread != null) {
            try {
                videoDrainThread.join(1500);
            } catch (InterruptedException ignored) {
                Thread.currentThread().interrupt();
            }
            videoDrainThread = null;
        }
        if (audioCaptureThread != null) {
            try {
                audioCaptureThread.join(1500);
            } catch (InterruptedException ignored) {
                Thread.currentThread().interrupt();
            }
            audioCaptureThread = null;
        }

        releaseMediaResources();
        ensureForeground(getString(R.string.notif_text_idle));
        refreshBubbleState();

        String msg = lastOutputPath != null ? "Saved: " + lastOutputPath : "Recording stopped";
        Toast.makeText(this, msg, Toast.LENGTH_LONG).show();
    }

    private void releaseMediaResources() {
        if (virtualDisplay != null) {
            virtualDisplay.release();
            virtualDisplay = null;
        }
        if (mediaProjection != null) {
            try {
                mediaProjection.unregisterCallback(projectionCallback);
                mediaProjection.stop();
            } catch (RuntimeException ignored) {
            }
            mediaProjection = null;
        }
        if (internalAudioRecord != null) {
            try {
                internalAudioRecord.stop();
                internalAudioRecord.release();
            } catch (RuntimeException ignored) {
            }
            internalAudioRecord = null;
        }
        if (micAudioRecord != null) {
            try {
                micAudioRecord.stop();
                micAudioRecord.release();
            } catch (RuntimeException ignored) {
            }
            micAudioRecord = null;
        }
        if (videoEncoder != null) {
            try {
                videoEncoder.stop();
                videoEncoder.release();
            } catch (RuntimeException ignored) {
            }
            videoEncoder = null;
        }
        if (inputSurface != null) {
            inputSurface.release();
            inputSurface = null;
        }
        if (audioEncoder != null) {
            try {
                audioEncoder.stop();
                audioEncoder.release();
            } catch (RuntimeException ignored) {
            }
            audioEncoder = null;
        }
        if (muxer != null) {
            try {
                if (muxerStarted.get()) {
                    muxer.stop();
                }
                muxer.release();
            } catch (RuntimeException ignored) {
            }
            muxer = null;
        }
        muxerStarted.set(false);
        videoTrackIndex = -1;
        audioTrackIndex = -1;
    }

    private void createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel channel = new NotificationChannel(
                    CHANNEL_ID,
                    getString(R.string.notif_channel_name),
                    NotificationManager.IMPORTANCE_LOW
            );
            NotificationManager manager = getSystemService(NotificationManager.class);
            if (manager != null) {
                manager.createNotificationChannel(channel);
            }
        }
    }

    @Nullable
    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    @Override
    public void onDestroy() {
        stopRecordingInternal(false);
        hideFloatingBubble();
        super.onDestroy();
    }
}
