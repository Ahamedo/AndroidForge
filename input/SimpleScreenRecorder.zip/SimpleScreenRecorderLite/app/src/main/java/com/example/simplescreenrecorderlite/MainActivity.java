package com.example.simplescreenrecorderlite;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.media.projection.MediaProjectionManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

import com.google.android.material.switchmaterial.SwitchMaterial;

public class MainActivity extends AppCompatActivity {

    private Spinner spResolution;
    private Spinner spFps;
    private Spinner spAudio;
    private SwitchMaterial swBubble;
    private Button btnStart;
    private Button btnPauseResume;
    private Button btnStop;
    private TextView tvStatus;
    private TextView tvLastFile;

    private MediaProjectionManager projectionManager;
    private boolean isPaused = false;
    private boolean pendingStartAfterCapturePermission = false;

    private final ActivityResultLauncher<String[]> permissionLauncher =
            registerForActivityResult(new ActivityResultContracts.RequestMultiplePermissions(), result -> {
                if (pendingStartAfterCapturePermission) {
                    pendingStartAfterCapturePermission = false;
                    launchScreenCapturePrompt();
                }
            });

    private final ActivityResultLauncher<Intent> screenCaptureLauncher =
            registerForActivityResult(new ActivityResultContracts.StartActivityForResult(), result -> {
                if (result.getResultCode() == Activity.RESULT_OK && result.getData() != null) {
                    Intent intent = new Intent(this, ScreenRecordService.class);
                    intent.setAction(ScreenRecordService.ACTION_START_RECORDING);
                    intent.putExtra(ScreenRecordService.EXTRA_RESULT_CODE, result.getResultCode());
                    intent.putExtra(ScreenRecordService.EXTRA_RESULT_DATA, result.getData());
                    ContextCompat.startForegroundService(this, intent);
                    isPaused = false;
                    updateButtons(true, false);
                    tvStatus.setText("Status: Recording");
                } else {
                    Toast.makeText(this, "Screen capture permission denied", Toast.LENGTH_SHORT).show();
                }
            });

    private final ActivityResultLauncher<Intent> overlaySettingsLauncher =
            registerForActivityResult(new ActivityResultContracts.StartActivityForResult(), result -> {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && Settings.canDrawOverlays(this)) {
                    RecorderPrefs.setBubbleEnabled(this, true);
                    swBubble.setChecked(true);
                    startBubbleService();
                } else {
                    RecorderPrefs.setBubbleEnabled(this, false);
                    swBubble.setChecked(false);
                    Toast.makeText(this, "Overlay permission not granted", Toast.LENGTH_SHORT).show();
                }
            });

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        projectionManager = (MediaProjectionManager) getSystemService(MEDIA_PROJECTION_SERVICE);

        spResolution = findViewById(R.id.spResolution);
        spFps = findViewById(R.id.spFps);
        spAudio = findViewById(R.id.spAudio);
        swBubble = findViewById(R.id.swBubble);
        btnStart = findViewById(R.id.btnStart);
        btnPauseResume = findViewById(R.id.btnPauseResume);
        btnStop = findViewById(R.id.btnStop);
        tvStatus = findViewById(R.id.tvStatus);
        tvLastFile = findViewById(R.id.tvLastFile);

        setupSpinners();
        setupBubbleSwitch();
        setupActionButtons();

        if (RecorderPrefs.isBubbleEnabled(this)) {
            if (Build.VERSION.SDK_INT < Build.VERSION_CODES.M || Settings.canDrawOverlays(this)) {
                startBubbleService();
            }
        }
    }

    private void setupSpinners() {
        String[] resolutions = {RecorderPrefs.RES_480, RecorderPrefs.RES_720, RecorderPrefs.RES_1080};
        ArrayAdapter<String> resAdapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, resolutions);
        resAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spResolution.setAdapter(resAdapter);
        String savedRes = RecorderPrefs.getResolution(this);
        for (int i = 0; i < resolutions.length; i++) {
            if (resolutions[i].equals(savedRes)) {
                spResolution.setSelection(i);
                break;
            }
        }
        spResolution.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                RecorderPrefs.setResolution(MainActivity.this, resolutions[position]);
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
            }
        });

        Integer[] fpsOptions = {30, 60, 90};
        ArrayAdapter<Integer> fpsAdapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, fpsOptions);
        fpsAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spFps.setAdapter(fpsAdapter);
        int savedFps = RecorderPrefs.getFps(this);
        for (int i = 0; i < fpsOptions.length; i++) {
            if (fpsOptions[i] == savedFps) {
                spFps.setSelection(i);
                break;
            }
        }
        spFps.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                RecorderPrefs.setFps(MainActivity.this, fpsOptions[position]);
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
            }
        });

        String[] audioModes = {RecorderPrefs.AUDIO_INTERNAL_ONLY, RecorderPrefs.AUDIO_INTERNAL_AND_MIC};
        ArrayAdapter<String> audioAdapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, audioModes);
        audioAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spAudio.setAdapter(audioAdapter);
        String savedAudio = RecorderPrefs.getAudioMode(this);
        for (int i = 0; i < audioModes.length; i++) {
            if (audioModes[i].equals(savedAudio)) {
                spAudio.setSelection(i);
                break;
            }
        }
        spAudio.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                RecorderPrefs.setAudioMode(MainActivity.this, audioModes[position]);
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
            }
        });
    }

    private void setupBubbleSwitch() {
        boolean enabled = RecorderPrefs.isBubbleEnabled(this);
        swBubble.setChecked(enabled);
        swBubble.setOnCheckedChangeListener((buttonView, isChecked) -> {
            if (isChecked) {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && !Settings.canDrawOverlays(this)) {
                    Intent overlayIntent = new Intent(
                            Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                            Uri.parse("package:" + getPackageName())
                    );
                    overlaySettingsLauncher.launch(overlayIntent);
                } else {
                    RecorderPrefs.setBubbleEnabled(this, true);
                    startBubbleService();
                }
            } else {
                RecorderPrefs.setBubbleEnabled(this, false);
                Intent intent = new Intent(this, ScreenRecordService.class);
                intent.setAction(ScreenRecordService.ACTION_HIDE_BUBBLE);
                ContextCompat.startForegroundService(this, intent);
            }
        });
    }

    private void setupActionButtons() {
        btnStart.setOnClickListener(v -> ensurePermissionsAndStart());

        btnPauseResume.setOnClickListener(v -> {
            Intent intent = new Intent(this, ScreenRecordService.class);
            if (!isPaused) {
                intent.setAction(ScreenRecordService.ACTION_PAUSE);
                isPaused = true;
                btnPauseResume.setText(R.string.resume_recording);
                tvStatus.setText("Status: Paused");
            } else {
                intent.setAction(ScreenRecordService.ACTION_RESUME);
                isPaused = false;
                btnPauseResume.setText(R.string.pause_recording);
                tvStatus.setText("Status: Recording");
            }
            ContextCompat.startForegroundService(this, intent);
        });

        btnStop.setOnClickListener(v -> {
            Intent intent = new Intent(this, ScreenRecordService.class);
            intent.setAction(ScreenRecordService.ACTION_STOP_RECORDING);
            ContextCompat.startForegroundService(this, intent);
            isPaused = false;
            updateButtons(false, false);
            tvStatus.setText("Status: Saved");
        });
    }

    private void startBubbleService() {
        Intent intent = new Intent(this, ScreenRecordService.class);
        intent.setAction(ScreenRecordService.ACTION_SHOW_BUBBLE);
        ContextCompat.startForegroundService(this, intent);
    }

    private void ensurePermissionsAndStart() {
        boolean needMic = RecorderPrefs.AUDIO_INTERNAL_AND_MIC.equals(RecorderPrefs.getAudioMode(this))
                && ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO)
                != PackageManager.PERMISSION_GRANTED;
        boolean needNotif = Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU
                && ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS)
                != PackageManager.PERMISSION_GRANTED;

        if (needMic || needNotif) {
            pendingStartAfterCapturePermission = true;
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                permissionLauncher.launch(new String[]{
                        Manifest.permission.RECORD_AUDIO,
                        Manifest.permission.POST_NOTIFICATIONS
                });
            } else {
                permissionLauncher.launch(new String[]{Manifest.permission.RECORD_AUDIO});
            }
        } else {
            launchScreenCapturePrompt();
        }
    }

    private void launchScreenCapturePrompt() {
        if (projectionManager != null) {
            screenCaptureLauncher.launch(projectionManager.createScreenCaptureIntent());
        }
    }

    private void updateButtons(boolean recording, boolean paused) {
        btnStart.setEnabled(!recording);
        btnPauseResume.setEnabled(recording);
        btnStop.setEnabled(recording);
        btnPauseResume.setText(paused ? R.string.resume_recording : R.string.pause_recording);
    }
}
