# Default proguard rules for SimpleScreenRecorderLite
