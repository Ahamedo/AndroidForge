# SimpleScreenRecorderLite

Lightweight Android screen recording app featuring:
- Resolution options: 480p, 720p, 1080p (auto-oriented to screen)
- Frame rate options: 30, 60, 90 FPS
- Audio capture modes: Internal audio only (AudioPlaybackCapture on Android 10+) or Internal + Microphone mixed audio
- Toggleable floating bubble with Start, Pause/Resume, and Stop controls
