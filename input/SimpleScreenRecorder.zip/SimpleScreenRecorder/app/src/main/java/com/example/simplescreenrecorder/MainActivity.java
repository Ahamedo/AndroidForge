package com.example.simplescreenrecorder;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.media.projection.MediaProjectionManager;
import android.os.Build;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

public class MainActivity extends AppCompatActivity {

    private Button btnStart;
    private Button btnStop;
    private TextView tvStatus;
    private MediaProjectionManager projectionManager;

    private final ActivityResultLauncher<String[]> permissionLauncher =
            registerForActivityResult(new ActivityResultContracts.RequestMultiplePermissions(), result -> requestScreenCapture());

    private final ActivityResultLauncher<Intent> screenCaptureLauncher =
            registerForActivityResult(new ActivityResultContracts.StartActivityForResult(), result -> {
                if (result.getResultCode() == Activity.RESULT_OK && result.getData() != null) {
                    Intent serviceIntent = new Intent(this, ScreenRecordService.class);
                    serviceIntent.setAction(ScreenRecordService.ACTION_START);
                    serviceIntent.putExtra(ScreenRecordService.EXTRA_RESULT_CODE, result.getResultCode());
                    serviceIntent.putExtra(ScreenRecordService.EXTRA_RESULT_DATA, result.getData());
                    ContextCompat.startForegroundService(this, serviceIntent);
                    setRecordingUi(true);
                } else {
                    Toast.makeText(this, "Screen recording permission was not granted", Toast.LENGTH_SHORT).show();
                }
            });

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        projectionManager = (MediaProjectionManager) getSystemService(MEDIA_PROJECTION_SERVICE);
        tvStatus = findViewById(R.id.tvStatus);
        btnStart = findViewById(R.id.btnStart);
        btnStop = findViewById(R.id.btnStop);

        btnStart.setOnClickListener(v -> ensurePermissionsAndStart());
        btnStop.setOnClickListener(v -> {
            Intent stopIntent = new Intent(this, ScreenRecordService.class);
            stopIntent.setAction(ScreenRecordService.ACTION_STOP);
            ContextCompat.startForegroundService(this, stopIntent);
            setRecordingUi(false);
        });
    }

    private void ensurePermissionsAndStart() {
        boolean needAudio = ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO)
                != PackageManager.PERMISSION_GRANTED;
        boolean needNotif = Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU
                && ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS)
                != PackageManager.PERMISSION_GRANTED;

        if (needAudio || needNotif) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                permissionLauncher.launch(new String[]{
                        Manifest.permission.RECORD_AUDIO,
                        Manifest.permission.POST_NOTIFICATIONS
                });
            } else {
                permissionLauncher.launch(new String[]{Manifest.permission.RECORD_AUDIO});
            }
        } else {
            requestScreenCapture();
        }
    }

    private void requestScreenCapture() {
        if (projectionManager != null) {
            screenCaptureLauncher.launch(projectionManager.createScreenCaptureIntent());
        }
    }

    private void setRecordingUi(boolean recording) {
        btnStart.setEnabled(!recording);
        btnStop.setEnabled(recording);
        tvStatus.setText(recording ? "Recording..." : "Ready");
    }
}
