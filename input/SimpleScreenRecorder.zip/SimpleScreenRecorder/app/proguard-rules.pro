# Default proguard rules for SimpleScreenRecorder
