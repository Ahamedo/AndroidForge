# SimpleScreenRecorder

Minimal Android screen recording starter project using `MediaProjection` and `MediaRecorder`.

## How to build without Android Studio
1. Fork https://github.com/Professional-X/AndroidForge on GitHub.
2. Zip the contents of `SimpleScreenRecorder` into `SimpleScreenRecorder.zip`.
3. Upload the ZIP into `input/` in your forked repository (or via the AndroidForge web UI) and run the **Build Android APK** workflow under **Actions**.
4. Download the generated APK from workflow artifacts and install it on your Android device.
