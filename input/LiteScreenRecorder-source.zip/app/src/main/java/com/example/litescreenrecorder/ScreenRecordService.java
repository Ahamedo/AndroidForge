package com.example.litescreenrecorder;

import android.Manifest;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.ServiceInfo;
import android.graphics.PixelFormat;
import android.hardware.display.DisplayManager;
import android.hardware.display.VirtualDisplay;
import android.media.AudioAttributes;
import android.media.AudioFormat;
import android.media.AudioPlaybackCaptureConfiguration;
import android.media.AudioRecord;
import android.media.MediaCodec;
import android.media.MediaCodecInfo;
import android.media.MediaFormat;
import android.media.MediaMuxer;
import android.media.MediaRecorder;
import android.media.projection.MediaProjection;
import android.media.projection.MediaProjectionManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.HandlerThread;
import android.os.Looper;
import android.os.PowerManager;
import android.os.IBinder;
import android.os.SystemClock;
import android.provider.MediaStore;
import android.provider.Settings;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.Surface;
import android.view.View;
import android.view.WindowManager;
import android.widget.TextView;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;
import java.util.concurrent.atomic.AtomicBoolean;

/**
 * Owns the MediaProjection, fixed-size AVC/AAC encoder pipeline, MP4 muxer and optional overlays.
 * The service is intentionally self-contained and uses only Android platform media APIs.
 */
public class ScreenRecordService extends Service {
    private static final String TAG = "LiteScreenRecorderSvc";
    public static final String ACTION_START = "com.example.litescreenrecorder.action.START";
    public static final String ACTION_STOP = "com.example.litescreenrecorder.action.STOP";
    public static final String ACTION_TOGGLE_PAUSE = "com.example.litescreenrecorder.action.TOGGLE_PAUSE";
    public static final String ACTION_OVERLAY_ENABLE = "com.example.litescreenrecorder.action.OVERLAY_ENABLE";
    public static final String ACTION_OVERLAY_DISABLE = "com.example.litescreenrecorder.action.OVERLAY_DISABLE";
    public static final String ACTION_STATE_CHANGED = "com.example.litescreenrecorder.action.STATE_CHANGED";
    public static final String EXTRA_RESULT_CODE = "projection_result_code";
    public static final String EXTRA_PROJECTION_DATA = "projection_result_data";
    public static final String EXTRA_AUDIO_MODE = "audio_mode";
    public static final String EXTRA_STATE = "state";
    private static final String EXTRA_SAVED_LABEL = "saved_label";
    public static final String EXTRA_DURATION_MS = "duration_ms";
    public static final String EXTRA_RESULT_MESSAGE = "result_message";

    private static final int NOTIFICATION_ID = 7204;
    private static final String NOTIFICATION_CHANNEL_ID = "lite_screen_recording";
    private static final int AUDIO_SAMPLE_RATE = 44_100;
    private static final int AUDIO_CHANNEL_COUNT = 1;
    private static final int AUDIO_BUFFER_SAMPLES = 2048;
    private static volatile boolean sessionActive;

    private final Object lifecycleLock = new Object();
    private final Object muxerLock = new Object();
    private final Object audioLock = new Object();
    private final AtomicBoolean stopStarted = new AtomicBoolean(false);
    private final Handler mainHandler = new Handler(Looper.getMainLooper());
    private final Runnable durationTicker = new Runnable() {
        @Override public void run() {
            if (!sessionActive) return;
            long duration = getActiveTimeUs() / 1000L;
            preferences.setLiveDurationMs(duration);
            // Keep the capture pipeline alive with the screen off, and stop cleanly before
            // the temporary MP4 approaches common 32-bit/container/provider size limits.
            if (outputTempFile != null && outputTempFile.exists()
                    && outputTempFile.length() >= 3L * 1024L * 1024L * 1024L) {
                Log.w(TAG, "Recording reached the 3 GiB safety limit; finalizing to protect the MP4.");
                requestStop(false);
                return;
            }
            if (outputTempFile != null && outputTempFile.exists()
                    && outputTempFile.getFreeSpace() < 256L * 1024L * 1024L) {
                Log.w(TAG, "Low storage reserve; stopping recording cleanly.");
                requestStop(false);
                return;
            }
            updateBubbleText();
            broadcastState(null);
            mainHandler.postDelayed(this, 1000L);
        }
    };

    private RecordingPreferences preferences;
    private HandlerThread callbackThread;
    private PowerManager.WakeLock recordingWakeLock;
    private Handler callbackHandler;
    private volatile String state = RecordingPreferences.STATE_IDLE;
    private volatile boolean stopRequested;
    private volatile boolean paused;
    private volatile boolean muxerFailed;
    private volatile boolean audioCaptureRunning;
    private volatile boolean foregroundStarted;
    private volatile String sessionResultMessage;
    private long videoSamplesWritten;

    private MediaProjection mediaProjection;
    private MediaProjection.Callback projectionCallback;
    private volatile VirtualDisplay virtualDisplay;
    private MediaCodec videoEncoder;
    private Surface videoInputSurface;
    private MediaCodec audioEncoder;
    private AudioRecord playbackAudioRecord;
    private AudioRecord microphoneAudioRecord;

    private Thread setupThread;
    private Thread videoDrainThread;
    private Thread audioDrainThread;
    private Thread audioCaptureThread;

    private MediaFormat videoOutputFormat;
    private MediaFormat audioOutputFormat;
    private MediaMuxer mediaMuxer;
    private boolean muxerStarted;
    private int videoTrackIndex = -1;
    private int audioTrackIndex = -1;
    private boolean audioTrackExpected;
    private long muxerWaitStartedMs;

    private int videoWidth;
    private int videoHeight;
    private int videoFps;
    private int videoBitrate;
    private volatile long sessionStartNanos;
    private volatile long pauseStartNanos;
    // Total paused duration subtracted from the monotonic capture clock.
    private volatile long presentationTimeOffsetUs;
    private volatile long audioPtsUs = -1L;
    private long lastVideoPtsUs = -1L;
    private long videoOriginPtsUs = -1L;
    private long lastAudioPtsUs = -1L;
    private String requestedAudioMode;

    private Uri outputUri;
    private File outputFile;
    private File outputTempFile;
    private boolean preserveOutputTempFile;
    private String outputDisplayName;
    private String outputRelativePath = "Movies/LiteScreenRecorder";

    // Overlay state; overlays are shown only when explicitly enabled and system permission exists.
    private WindowManager windowManager;
    private View bubbleView;
    private View controlsView;
    private WindowManager.LayoutParams bubbleParams;
    private WindowManager.LayoutParams controlsParams;

    @Override
    public void onCreate() {
        super.onCreate();
        preferences = new RecordingPreferences(this);
        callbackThread = new HandlerThread("LiteRecorderProjectionCallbacks");
        callbackThread.start();
        callbackHandler = new Handler(callbackThread.getLooper());
        windowManager = (WindowManager) getSystemService(WINDOW_SERVICE);
        createNotificationChannel();
        if (preferences.isOverlayEnabled()) showOverlayIfAllowed();
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        String action = intent == null ? null : intent.getAction();
        if (ACTION_START.equals(action)) {
            if (sessionActive) {
                Log.w(TAG, "Ignoring START because a projection session is already active.");
                updateBubbleText();
                showFloatingControls();
                return START_NOT_STICKY;
            }
            hideFloatingControls();
            try {
                startAsForegroundRecorder();
            } catch (Throwable error) {
                Log.e(TAG, "Could not promote ScreenRecordService to foreground.", error);
                state = RecordingPreferences.STATE_IDLE;
                preferences.setRecorderState(state);
                sessionResultMessage = "Android did not allow the recording foreground service to start. Check permissions and Logcat.";
                broadcastState(null);
                stopSelf(startId);
                return START_NOT_STICKY;
            }
            startSession(intent);
        } else if (ACTION_STOP.equals(action)) {
            requestStop(false);
        } else if (ACTION_TOGGLE_PAUSE.equals(action)) {
            if (RecordingPreferences.STATE_RECORDING.equals(state)) pauseSession();
            else if (RecordingPreferences.STATE_PAUSED.equals(state)) resumeSession();
        } else if (ACTION_OVERLAY_ENABLE.equals(action)) {
            showOverlayIfAllowed();
        } else if (ACTION_OVERLAY_DISABLE.equals(action)) {
            removeOverlayViews();
            if (!sessionActive) stopSelf(startId);
        }
        return START_NOT_STICKY;
    }

    @Override
    public IBinder onBind(Intent intent) { return null; }

    public static boolean isSessionActive() { return sessionActive; }

    private void startAsForegroundRecorder() {
        Notification notification = buildNotification(false);
        if (Build.VERSION.SDK_INT >= 29) {
            int types = ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION;
            // RECORD_AUDIO is requested before the service is started. Add the microphone
            // foreground type only when the runtime permission is actually granted.
            if (Build.VERSION.SDK_INT >= 30 && checkSelfPermission(Manifest.permission.RECORD_AUDIO)
                    == PackageManager.PERMISSION_GRANTED) {
                types |= ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE;
            }
            startForeground(NOTIFICATION_ID, notification, types);
        } else {
            startForeground(NOTIFICATION_ID, notification);
        }
        foregroundStarted = true;
    }

    private void startSession(Intent serviceIntent) {
        synchronized (lifecycleLock) {
            if (sessionActive) return;
            sessionActive = true;
            stopRequested = false;
            paused = false;
            muxerFailed = false;
            stopStarted.set(false);
            state = RecordingPreferences.STATE_RECORDING;
            // Reset all per-session state because the service may remain alive for the bubble.
            videoOutputFormat = null;
            audioOutputFormat = null;
            mediaMuxer = null;
            muxerStarted = false;
            muxerFailed = false;
            videoTrackIndex = -1;
            audioTrackIndex = -1;
            audioTrackExpected = false;
            muxerWaitStartedMs = 0L;
            outputMuxerCompleted = false;
            videoSamplesWritten = 0L;
            audioPtsUs = -1L;
            lastVideoPtsUs = -1L;
            videoOriginPtsUs = -1L;
            lastAudioPtsUs = -1L;
            presentationTimeOffsetUs = 0L;
            pauseStartNanos = 0L;
            sessionStartNanos = 0L;
            audioCaptureRunning = false;
            videoEncoder = null;
            audioEncoder = null;
            videoInputSurface = null;
            virtualDisplay = null;
            mediaProjection = null;
            projectionCallback = null;
            playbackAudioRecord = null;
            microphoneAudioRecord = null;
            videoDrainThread = null;
            audioDrainThread = null;
            audioCaptureThread = null;
            setupThread = null;
            outputUri = null;
            outputFile = null;
            outputTempFile = null;
            preserveOutputTempFile = false;
            outputDisplayName = null;
            preferences.setLiveDurationMs(0L);
            sessionResultMessage = null;
            preferences.setRecorderState(state);
        }
        // Android captures application-overlay windows as black rectangles when FLAG_SECURE
        // is used. Remove overlays entirely for the capture session; restore them after stop.
        removeOverlayViews();
        acquireRecordingWakeLock();
        final int resultCode = serviceIntent.getIntExtra(EXTRA_RESULT_CODE, 0);
        final Intent projectionData = getProjectionData(serviceIntent);
        requestedAudioMode = serviceIntent.getStringExtra(EXTRA_AUDIO_MODE);
        if (requestedAudioMode == null) requestedAudioMode = RecordingPreferences.AUDIO_INTERNAL_ONLY;
        broadcastState(null);
        mainHandler.removeCallbacks(durationTicker);
        mainHandler.post(durationTicker);

        setupThread = new Thread(() -> {
            try {
                if (projectionData == null || resultCode == 0) {
                    throw new IllegalStateException("Missing MediaProjection consent result.");
                }
                MediaProjectionManager manager = (MediaProjectionManager)
                        getSystemService(Context.MEDIA_PROJECTION_SERVICE);
                if (manager == null) throw new IllegalStateException("MediaProjection service unavailable.");
                // Foreground service has been started before obtaining the projection object.
                mediaProjection = manager.getMediaProjection(resultCode, projectionData);
                if (mediaProjection == null) throw new IllegalStateException("MediaProjection was not created.");
                if (stopRequested) return;
                RecordingPreferences.CaptureSpec spec = preferences.makeCaptureSpec(this);
                videoWidth = spec.width;
                videoHeight = spec.height;
                videoFps = spec.fps;
                videoBitrate = spec.bitrate;
                float displayHz = windowManager.getDefaultDisplay().getRefreshRate();
                Log.i(TAG, "Physical display refresh rate=" + displayHz + " Hz; encoder frame-rate hint=" + videoFps + " FPS.");
                if (videoFps > displayHz + 1.0f) {
                    Log.w(TAG, "Requested FPS exceeds display refresh rate; captured frames cannot exceed display delivery cadence.");
                }
                if (spec.constrainedFallback) {
                    Log.w(TAG, "Constrained device: requested " + spec.requestedQuality
                            + " above 60 FPS reduced to 720p/60 FPS.");
                }
                Log.i(TAG, "Capture profile " + videoWidth + "x" + videoHeight + " @ "
                        + videoFps + " FPS, " + videoBitrate + " bps.");

                prepareOutputTarget();
                if (stopRequested) return;
                prepareVideoEncoder();
                if (stopRequested) return;
                prepareAudioCaptureAndEncoder();
                if (stopRequested) return;

                // The callback must be registered before the first createVirtualDisplay call.
                projectionCallback = new MediaProjection.Callback() {
                    @Override public void onStop() {
                        Log.w(TAG, "MediaProjection revoked by system/user.");
                        requestStop(true);
                    }
                };
                mediaProjection.registerCallback(projectionCallback, callbackHandler);

                DisplayMetrics metrics = new DisplayMetrics();
                windowManager.getDefaultDisplay().getRealMetrics(metrics);
                int densityDpi = metrics.densityDpi > 0 ? metrics.densityDpi : 320;
                sessionStartNanos = System.nanoTime();
                virtualDisplay = mediaProjection.createVirtualDisplay(
                        "LiteScreenRecorder", videoWidth, videoHeight, densityDpi,
                        DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
                        videoInputSurface, null, callbackHandler);
                if (virtualDisplay == null) throw new IllegalStateException("VirtualDisplay creation failed.");

                startDrainThreads();
                startAudioCaptureThreadIfAvailable();
                updateNotification(false);
                broadcastState(null);
            } catch (Throwable error) {
                Log.e(TAG, "Unable to initialize recording session", error);
                requestStop(false);
            }
        }, "LiteRecorderSetup");
        setupThread.start();
    }

    private Intent getProjectionData(Intent serviceIntent) {
        if (Build.VERSION.SDK_INT >= 33) {
            return serviceIntent.getParcelableExtra(EXTRA_PROJECTION_DATA, Intent.class);
        }
        //noinspection deprecation
        return serviceIntent.getParcelableExtra(EXTRA_PROJECTION_DATA);
    }

    private void prepareVideoEncoder() throws IOException {
        MediaFormat format = MediaFormat.createVideoFormat(
                MediaFormat.MIMETYPE_VIDEO_AVC, videoWidth, videoHeight);
        format.setInteger(MediaFormat.KEY_COLOR_FORMAT,
                MediaCodecInfo.CodecCapabilities.COLOR_FormatSurface);
        format.setInteger(MediaFormat.KEY_BIT_RATE, videoBitrate);
        format.setInteger(MediaFormat.KEY_FRAME_RATE, videoFps);
        format.setInteger(MediaFormat.KEY_I_FRAME_INTERVAL, 2);
        try {
            format.setInteger(MediaFormat.KEY_BITRATE_MODE,
                    MediaCodecInfo.EncoderCapabilities.BITRATE_MODE_VBR);
        } catch (RuntimeException ignored) { }

        videoEncoder = MediaCodec.createEncoderByType(MediaFormat.MIMETYPE_VIDEO_AVC);
        videoEncoder.configure(format, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE);
        videoInputSurface = videoEncoder.createInputSurface();
        videoEncoder.start();
    }

    private void prepareAudioCaptureAndEncoder() {
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            Log.w(TAG, "RECORD_AUDIO is not granted; video will continue without audio.");
            return;
        }
        int channelMask = AudioFormat.CHANNEL_IN_MONO;
        int encoding = AudioFormat.ENCODING_PCM_16BIT;
        int minBuffer = AudioRecord.getMinBufferSize(AUDIO_SAMPLE_RATE, channelMask, encoding);
        if (minBuffer <= 0) minBuffer = AUDIO_BUFFER_SAMPLES * 2;
        int bufferBytes = Math.max(minBuffer * 2, AUDIO_BUFFER_SAMPLES * 4);

        if (Build.VERSION.SDK_INT >= 29 && mediaProjection != null) {
            try {
                AudioPlaybackCaptureConfiguration captureConfig =
                        new AudioPlaybackCaptureConfiguration.Builder(mediaProjection)
                                .addMatchingUsage(AudioAttributes.USAGE_MEDIA)
                                .addMatchingUsage(AudioAttributes.USAGE_GAME)
                                .build();
                AudioFormat format = new AudioFormat.Builder()
                        .setEncoding(encoding)
                        .setSampleRate(AUDIO_SAMPLE_RATE)
                        .setChannelMask(channelMask)
                        .build();
                AudioRecord record = new AudioRecord.Builder()
                        .setAudioFormat(format)
                        .setBufferSizeInBytes(bufferBytes)
                        .setAudioPlaybackCaptureConfig(captureConfig)
                        .build();
                if (record.getState() == AudioRecord.STATE_INITIALIZED) playbackAudioRecord = record;
                else record.release();
            } catch (Throwable error) {
                Log.w(TAG, "Internal playback capture unavailable; continuing without that source.", error);
            }
        } else {
            Log.i(TAG, "Internal playback audio is unavailable before Android 10 (API 29).");
        }

        if (RecordingPreferences.AUDIO_INTERNAL_AND_MIC.equals(requestedAudioMode)) {
            try {
                AudioFormat micFormat = new AudioFormat.Builder()
                        .setEncoding(encoding)
                        .setSampleRate(AUDIO_SAMPLE_RATE)
                        .setChannelMask(channelMask)
                        .build();
                AudioRecord mic = new AudioRecord.Builder()
                        .setAudioSource(MediaRecorder.AudioSource.MIC)
                        .setAudioFormat(micFormat)
                        .setBufferSizeInBytes(bufferBytes)
                        .build();
                if (mic.getState() == AudioRecord.STATE_INITIALIZED) microphoneAudioRecord = mic;
                else mic.release();
            } catch (Throwable error) {
                Log.w(TAG, "Microphone capture unavailable; internal playback may still be recorded.", error);
            }
        }

        if (playbackAudioRecord == null && microphoneAudioRecord == null) {
            Log.w(TAG, "No audio source could be initialized; continuing video-only.");
            return;
        }

        try {
            MediaFormat audioFormat = MediaFormat.createAudioFormat(
                    MediaFormat.MIMETYPE_AUDIO_AAC, AUDIO_SAMPLE_RATE, AUDIO_CHANNEL_COUNT);
            audioFormat.setInteger(MediaFormat.KEY_AAC_PROFILE,
                    MediaCodecInfo.CodecProfileLevel.AACObjectLC);
            audioFormat.setInteger(MediaFormat.KEY_BIT_RATE, 96_000);
            audioFormat.setInteger(MediaFormat.KEY_MAX_INPUT_SIZE, 16_384);
            audioEncoder = MediaCodec.createEncoderByType(MediaFormat.MIMETYPE_AUDIO_AAC);
            audioEncoder.configure(audioFormat, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE);
            audioEncoder.start();
            startAudioRecords();
            audioTrackExpected = audioCaptureRunning;
        } catch (Throwable error) {
            Log.e(TAG, "AAC encoder could not be initialized; disabling audio only.", error);
            safeReleaseAudioRecords();
            if (audioEncoder != null) {
                try { audioEncoder.stop(); } catch (Throwable ignored) { }
                try { audioEncoder.release(); } catch (Throwable ignored) { }
                audioEncoder = null;
            }
            audioTrackExpected = false;
        }
    }

    private void startAudioRecords() {
        synchronized (audioLock) {
            if (playbackAudioRecord != null) {
                try { playbackAudioRecord.startRecording(); }
                catch (Throwable error) {
                    Log.w(TAG, "Could not start internal playback AudioRecord.", error);
                    safeStopReleasePlaybackRecord();
                }
            }
            if (microphoneAudioRecord != null) {
                try { microphoneAudioRecord.startRecording(); }
                catch (Throwable error) {
                    Log.w(TAG, "Could not start microphone AudioRecord.", error);
                    safeStopReleaseMicrophoneRecord();
                }
            }
            audioCaptureRunning = playbackAudioRecord != null || microphoneAudioRecord != null;
        }
    }

    private void startDrainThreads() {
        videoDrainThread = new Thread(this::drainVideoEncoder, "LiteRecorderVideoDrain");
        videoDrainThread.start();
        if (audioEncoder != null) {
            audioDrainThread = new Thread(this::drainAudioEncoder, "LiteRecorderAudioDrain");
            audioDrainThread.start();
        }
    }

    private void startAudioCaptureThreadIfAvailable() {
        if (audioEncoder == null) return;
        if (!audioCaptureRunning) {
            // The AAC format track was prepared but every source failed at start; close it cleanly.
            queueAudioEndOfStream();
            return;
        }
        audioCaptureThread = new Thread(this::captureAndEncodeAudio, "LiteRecorderAudioCapture");
        audioCaptureThread.start();
    }

    private void captureAndEncodeAudio() {
        short[] playback = new short[AUDIO_BUFFER_SAMPLES];
        short[] mic = new short[AUDIO_BUFFER_SAMPLES];
        ByteBuffer pcmBytes = ByteBuffer.allocate(AUDIO_BUFFER_SAMPLES * 2)
                .order(ByteOrder.LITTLE_ENDIAN);
        while (audioCaptureRunning && !stopRequested) {
            if (paused) {
                sleepQuietly(12);
                continue;
            }
            int playbackRead = 0;
            int micRead = 0;
            AudioRecord p = playbackAudioRecord;
            AudioRecord m = microphoneAudioRecord;
            if (p != null) {
                try { playbackRead = Math.max(0, p.read(playback, 0, playback.length, AudioRecord.READ_NON_BLOCKING)); }
                catch (Throwable error) { Log.w(TAG, "Playback AudioRecord read failed.", error); }
            }
            if (m != null) {
                try { micRead = Math.max(0, m.read(mic, 0, mic.length, AudioRecord.READ_NON_BLOCKING)); }
                catch (Throwable error) { Log.w(TAG, "Microphone AudioRecord read failed.", error); }
            }
            int count = Math.max(playbackRead, micRead);
            if (count <= 0) {
                sleepQuietly(5);
                continue;
            }
            pcmBytes.clear();
            for (int i = 0; i < count; i++) {
                int value;
                if (playbackRead > 0 && micRead > 0) {
                    int a = i < playbackRead ? playback[i] : 0;
                    int b = i < micRead ? mic[i] : 0;
                    value = (a + b) / 2; // Headroom before the final saturating clamp.
                } else if (playbackRead > 0) {
                    value = i < playbackRead ? playback[i] : 0;
                } else {
                    value = i < micRead ? mic[i] : 0;
                }
                value = Math.max(Short.MIN_VALUE, Math.min(Short.MAX_VALUE, value));
                pcmBytes.putShort((short) value);
            }
            feedAacEncoder(pcmBytes, count * 2);
        }
        queueAudioEndOfStream();
    }

    private void feedAacEncoder(ByteBuffer pcm, int size) {
        MediaCodec encoder = audioEncoder;
        if (encoder == null || stopRequested) return;
        try {
            int inputIndex = encoder.dequeueInputBuffer(10_000);
            if (inputIndex < 0) return;
            ByteBuffer input = encoder.getInputBuffer(inputIndex);
            if (input == null) {
                encoder.queueInputBuffer(inputIndex, 0, 0, getActiveTimeUs(), 0);
                return;
            }
            input.clear();
            pcm.flip();
            int bytes = Math.min(size, Math.min(input.remaining(), pcm.remaining()));
            input.put(pcm.array(), 0, bytes);
            long sampleCount = bytes / 2L;
            long durationUs = (sampleCount * 1_000_000L) / AUDIO_SAMPLE_RATE;
            // Anchor each PCM block to the same monotonic active-session clock as video.
            // This naturally accounts for AudioRecord scheduling jitter and omitted buffers.
            long pts = Math.max(0L, getActiveTimeUs() - durationUs);
            if (audioPtsUs > pts) pts = audioPtsUs;
            audioPtsUs = pts + durationUs;
            encoder.queueInputBuffer(inputIndex, 0, bytes, pts, 0);
        } catch (IllegalStateException error) {
            if (!stopRequested) Log.e(TAG, "AAC input queue failed.", error);
        } catch (Throwable error) {
            Log.e(TAG, "Unexpected audio encoding error.", error);
        }
    }

    private void queueAudioEndOfStream() {
        MediaCodec encoder = audioEncoder;
        if (encoder == null) return;
        long deadline = SystemClock.elapsedRealtime() + 1800L;
        while (SystemClock.elapsedRealtime() < deadline) {
            try {
                int index = encoder.dequeueInputBuffer(20_000);
                if (index >= 0) {
                    long pts = Math.max(0L, audioPtsUs < 0 ? getActiveTimeUs() : audioPtsUs);
                    encoder.queueInputBuffer(index, 0, 0, pts, MediaCodec.BUFFER_FLAG_END_OF_STREAM);
                    Log.d(TAG, "AAC end-of-stream queued.");
                    return;
                }
            } catch (Throwable error) {
                Log.w(TAG, "Could not queue AAC EOS.", error);
                return;
            }
            sleepQuietly(5L);
        }
        Log.w(TAG, "Timed out waiting for an AAC input buffer to queue EOS.");
    }

    private void drainVideoEncoder() {
        MediaCodec encoder = videoEncoder;
        if (encoder == null) return;
        MediaCodec.BufferInfo info = new MediaCodec.BufferInfo();
        boolean eos = false;
        while (!eos) {
            int index;
            try { index = encoder.dequeueOutputBuffer(info, 10_000); }
            catch (IllegalStateException error) {
                if (!stopRequested) Log.e(TAG, "Video encoder drain failed.", error);
                break;
            }
            if (index == MediaCodec.INFO_TRY_AGAIN_LATER) {
                if (stopRequested && virtualDisplay == null) sleepQuietly(4);
                continue;
            } else if (index == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) {
                synchronized (muxerLock) {
                    videoOutputFormat = encoder.getOutputFormat();
                    if (muxerWaitStartedMs == 0L) muxerWaitStartedMs = SystemClock.elapsedRealtime();
                    tryStartMuxerLocked();
                }
            } else if (index >= 0) {
                ByteBuffer buffer = encoder.getOutputBuffer(index);
                if (buffer != null && info.size > 0
                        && (info.flags & MediaCodec.BUFFER_FLAG_CODEC_CONFIG) == 0) {
                    buffer.position(info.offset);
                    buffer.limit(info.offset + info.size);
                    writeEncodedSample(buffer, info, true);
                }
                if ((info.flags & MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0) eos = true;
                try { encoder.releaseOutputBuffer(index, false); } catch (Throwable ignored) { }
            }
            if (stopRequested && encoder == null) break;
        }
        Log.i(TAG, "Video drain thread finished.");
    }

    private void drainAudioEncoder() {
        MediaCodec encoder = audioEncoder;
        if (encoder == null) return;
        MediaCodec.BufferInfo info = new MediaCodec.BufferInfo();
        boolean eos = false;
        while (!eos) {
            int index;
            try { index = encoder.dequeueOutputBuffer(info, 10_000); }
            catch (IllegalStateException error) {
                if (!stopRequested) Log.e(TAG, "Audio encoder drain failed.", error);
                break;
            }
            if (index == MediaCodec.INFO_TRY_AGAIN_LATER) {
                if (stopRequested && audioCaptureThread == null) sleepQuietly(4);
                continue;
            } else if (index == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) {
                synchronized (muxerLock) {
                    audioOutputFormat = encoder.getOutputFormat();
                    tryStartMuxerLocked();
                }
            } else if (index >= 0) {
                ByteBuffer buffer = encoder.getOutputBuffer(index);
                if (buffer != null && info.size > 0
                        && (info.flags & MediaCodec.BUFFER_FLAG_CODEC_CONFIG) == 0) {
                    buffer.position(info.offset);
                    buffer.limit(info.offset + info.size);
                    writeEncodedSample(buffer, info, false);
                }
                if ((info.flags & MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0) eos = true;
                try { encoder.releaseOutputBuffer(index, false); } catch (Throwable ignored) { }
            }
        }
        Log.i(TAG, "Audio drain thread finished.");
    }

    private void tryStartMuxerLocked() {
        if (muxerStarted || muxerFailed || videoOutputFormat == null) return;
        if (audioTrackExpected && audioOutputFormat == null) return;
        try {
            File muxerTarget = Build.VERSION.SDK_INT >= 29 ? outputTempFile : outputFile;
            if (muxerTarget == null) throw new IOException("No writable output target was prepared.");
            Log.i(TAG, "Creating MP4 muxer target: " + muxerTarget.getAbsolutePath());
            mediaMuxer = new MediaMuxer(muxerTarget.getAbsolutePath(),
                    MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4);
            videoTrackIndex = mediaMuxer.addTrack(videoOutputFormat);
            if (audioTrackExpected && audioOutputFormat != null) {
                audioTrackIndex = mediaMuxer.addTrack(audioOutputFormat);
            }
            mediaMuxer.start();
            muxerStarted = true;
            muxerWaitStartedMs = SystemClock.elapsedRealtime();
            muxerLock.notifyAll();
            Log.i(TAG, "MP4 muxer started. Video track=" + videoTrackIndex
                    + ", audio track=" + audioTrackIndex);
        } catch (Throwable error) {
            muxerFailed = true;
            Log.e(TAG, "Could not start MP4 muxer.", error);
            muxerLock.notifyAll();
        }
    }

    private void writeEncodedSample(ByteBuffer buffer, MediaCodec.BufferInfo sourceInfo, boolean video) {
        synchronized (muxerLock) {
            long waitUntil = SystemClock.elapsedRealtime() + 1800L;
            while (!muxerStarted && !muxerFailed
                    && SystemClock.elapsedRealtime() < waitUntil) {
                if (audioTrackExpected && audioOutputFormat == null && muxerWaitStartedMs > 0L
                        && SystemClock.elapsedRealtime() - muxerWaitStartedMs >= 1200L) {
                    // Audio can remain silent or fail to produce an output format on vendor builds.
                    // Do not let that prevent the video-only MP4 from starting.
                    audioTrackExpected = false;
                    Log.w(TAG, "AAC format did not become ready; falling back to video-only muxing.");
                    tryStartMuxerLocked();
                    break;
                }
                try { muxerLock.wait(40L); } catch (InterruptedException ignored) { Thread.currentThread().interrupt(); break; }
            }
            if (!muxerStarted || mediaMuxer == null) return;
            MediaCodec.BufferInfo adjusted = new MediaCodec.BufferInfo();
            adjusted.set(sourceInfo.offset, sourceInfo.size, sourceInfo.presentationTimeUs, sourceInfo.flags);
            long pts;
            if (video) {
                // Surface-input timestamps normally share CLOCK_MONOTONIC with System.nanoTime().
                // Anchor against the actual session start, but fall back to the first observed PTS
                // on vendor encoders that use a different timestamp origin.
                long sessionBaseUs = sessionStartNanos / 1000L;
                if (videoOriginPtsUs < 0L) {
                    long delta = sourceInfo.presentationTimeUs - sessionBaseUs;
                    videoOriginPtsUs = (delta >= -2_000_000L && delta <= 30_000_000L)
                            ? sessionBaseUs : sourceInfo.presentationTimeUs;
                    Log.i(TAG, "Video timestamp origin=" + videoOriginPtsUs
                            + " sessionStartUs=" + sessionBaseUs + " firstDeltaUs=" + delta);
                }
                pts = sourceInfo.presentationTimeUs - videoOriginPtsUs - getAccumulatedPauseUs();
                if (pts < 0L) pts = 0L;
                if (pts <= lastVideoPtsUs) pts = lastVideoPtsUs + 1L;
                lastVideoPtsUs = pts;
            } else {
                pts = sourceInfo.presentationTimeUs;
                if (pts <= lastAudioPtsUs) pts = lastAudioPtsUs + 1;
                lastAudioPtsUs = pts;
            }
            adjusted.presentationTimeUs = pts;
            int track = video ? videoTrackIndex : audioTrackIndex;
            if (track < 0) return;
            try {
                mediaMuxer.writeSampleData(track, buffer, adjusted);
                if (video) videoSamplesWritten++;
            } catch (Throwable error) {
                muxerFailed = true;
                Log.e(TAG, "MediaMuxer.writeSampleData failed.", error);
            }
        }
    }

    private void pauseSession() {
        // The UI becomes active as soon as the FGS starts; ignore pause taps until
        // the encoder and VirtualDisplay are actually ready.
        if (paused || !sessionActive || stopRequested || videoEncoder == null || virtualDisplay == null) return;
        paused = true;
        pauseStartNanos = System.nanoTime();
        try {
            if (Build.VERSION.SDK_INT >= 29 && videoEncoder != null) {
                Bundle parameters = new Bundle();
                parameters.putInt(MediaCodec.PARAMETER_KEY_SUSPEND, 1);
                videoEncoder.setParameters(parameters);
            }
        } catch (Throwable error) {
            Log.d(TAG, "Encoder suspend parameter unsupported; detaching VirtualDisplay surface instead.", error);
        }
        try { if (virtualDisplay != null) virtualDisplay.setSurface(null); } catch (Throwable ignored) { }
        synchronized (audioLock) { stopAudioRecordsForPause(); }
        state = RecordingPreferences.STATE_PAUSED;
        preferences.setRecorderState(state);
        updateNotification(true);
        updateBubbleText();
        broadcastState(null);
    }

    private void resumeSession() {
        if (!paused || !sessionActive || stopRequested) return;
        long now = System.nanoTime();
        if (pauseStartNanos > 0) presentationTimeOffsetUs += Math.max(0L, now - pauseStartNanos) / 1000L;
        pauseStartNanos = 0L;
        paused = false;
        try {
            if (Build.VERSION.SDK_INT >= 29 && videoEncoder != null) {
                Bundle parameters = new Bundle();
                parameters.putInt(MediaCodec.PARAMETER_KEY_SUSPEND, 0);
                videoEncoder.setParameters(parameters);
            }
        } catch (Throwable error) {
            Log.d(TAG, "Encoder resume parameter unsupported; surface is reattached.", error);
        }
        try { if (virtualDisplay != null) virtualDisplay.setSurface(videoInputSurface); } catch (Throwable error) {
            Log.e(TAG, "Could not resume VirtualDisplay surface.", error);
        }
        synchronized (audioLock) { startAudioRecords(); }
        state = RecordingPreferences.STATE_RECORDING;
        preferences.setRecorderState(state);
        updateNotification(false);
        updateBubbleText();
        broadcastState(null);
    }

    private void stopAudioRecordsForPause() {
        try { if (playbackAudioRecord != null && playbackAudioRecord.getRecordingState() == AudioRecord.RECORDSTATE_RECORDING) playbackAudioRecord.stop(); }
        catch (Throwable ignored) { }
        try { if (microphoneAudioRecord != null && microphoneAudioRecord.getRecordingState() == AudioRecord.RECORDSTATE_RECORDING) microphoneAudioRecord.stop(); }
        catch (Throwable ignored) { }
    }

    private long getAccumulatedPauseUs() {
        long offset = presentationTimeOffsetUs;
        if (paused && pauseStartNanos > 0) offset += Math.max(0L, System.nanoTime() - pauseStartNanos) / 1000L;
        return offset;
    }

    private long getActiveTimeUs() {
        if (sessionStartNanos == 0L) return 0L;
        return Math.max(0L, (System.nanoTime() - sessionStartNanos) / 1000L - getAccumulatedPauseUs());
    }

    private void requestStop(boolean projectionAlreadyStopped) {
        if (!sessionActive && !foregroundStarted) {
            if (!preferences.isOverlayEnabled()) stopSelf();
            return;
        }
        if (!stopStarted.compareAndSet(false, true)) return;
        stopRequested = true;
        mainHandler.removeCallbacks(durationTicker);
        Thread worker = new Thread(() -> finishSession(projectionAlreadyStopped), "LiteRecorderStop");
        worker.start();
    }

    private void finishSession(boolean projectionAlreadyStopped) {
        Log.i(TAG, "Finalizing recording session.");
        // If a stop arrives during setup, wait for setup to leave its critical section before
        // releasing objects it may still be constructing.
        joinThread(setupThread, 15000L);
        if (setupThread != null && setupThread.isAlive()) {
            Log.e(TAG, "Setup thread did not finish before teardown; marking the session failed.");
            muxerFailed = true;
        }
        // Unhook the display first so the video encoder receives a finite stream.
        VirtualDisplay display = virtualDisplay;
        virtualDisplay = null;
        if (display != null) {
            try { display.setSurface(null); } catch (Throwable ignored) { }
            try { display.release(); } catch (Throwable ignored) { }
        }

        if (videoEncoder != null) {
            try { videoEncoder.signalEndOfInputStream(); }
            catch (Throwable error) { Log.w(TAG, "signalEndOfInputStream failed.", error); }
        }

        audioCaptureRunning = false;
        synchronized (audioLock) {
            stopAudioRecordsForPause();
            safeReleaseAudioRecords();
        }
        joinThread(audioCaptureThread, 2500L);
        audioCaptureThread = null;
        Thread videoDrain = videoDrainThread;
        Thread audioDrain = audioDrainThread;
        joinThread(videoDrain, 8000L);
        joinThread(audioDrain, 5000L);
        boolean videoDrainComplete = videoDrain == null || !videoDrain.isAlive();
        boolean audioDrainComplete = audioDrain == null || !audioDrain.isAlive();
        if (!videoDrainComplete) {
            Log.e(TAG, "Video encoder drain timed out; MP4 cannot be trusted.");
            muxerFailed = true;
        }
        if (!audioDrainComplete) {
            // Stop a wedged optional AAC encoder so its drain thread can exit. Video remains
            // publishable only if the AAC drain thread also releases the muxer lock cleanly.
            Log.w(TAG, "AAC drain timed out; stopping the optional audio encoder.");
            releaseAudioEncoder();
            joinThread(audioDrain, 1200L);
            if (audioDrain.isAlive()) {
                Log.e(TAG, "AAC drain thread did not exit after encoder stop.");
                muxerFailed = true;
            }
        }
        videoDrainThread = null;
        audioDrainThread = null;

        releaseVideoEncoder();
        releaseAudioEncoder();

        synchronized (muxerLock) {
            if (mediaMuxer != null && muxerStarted) {
                boolean stoppedSuccessfully = false;
                try {
                    mediaMuxer.stop();
                    stoppedSuccessfully = true;
                } catch (Throwable error) {
                    Log.w(TAG, "MediaMuxer.stop failed while finalizing.", error);
                }
                try { mediaMuxer.release(); }
                catch (Throwable error) { Log.w(TAG, "MediaMuxer.release failed.", error); }
                outputMuxerCompleted = stoppedSuccessfully && videoSamplesWritten > 0L;
                mediaMuxer = null;
                muxerStarted = false;
            }
        }

        if (projectionCallback != null && mediaProjection != null) {
            try { mediaProjection.unregisterCallback(projectionCallback); } catch (Throwable ignored) { }
            projectionCallback = null;
        }
        if (mediaProjection != null) {
            if (!projectionAlreadyStopped) {
                try { mediaProjection.stop(); } catch (Throwable ignored) { }
            }
            mediaProjection = null;
        }
        boolean saved = finalizeOutputTarget();
        mainHandler.removeCallbacks(durationTicker);
        preferences.setLiveDurationMs(getActiveTimeUs() / 1000L);
        state = RecordingPreferences.STATE_IDLE;
        preferences.setRecorderState(state);
        sessionActive = false;
        paused = false;
        stopRequested = false;
        if (saved) {
            String label = outputDisplayName == null ? "Screen recording.mp4" : outputDisplayName;
            String path = Build.VERSION.SDK_INT >= 29
                    ? outputRelativePath + "/" + label
                    : (outputFile == null ? "" : outputFile.getAbsolutePath());
            preferences.setLastRecording(outputUri == null ? "" : outputUri.toString(), label, path);
            Log.i(TAG, "Saved " + label + " at " + path);
        } else {
            sessionResultMessage = preserveOutputTempFile
                    ? "Gallery publishing failed, but the completed MP4 was retained in app storage for recovery. Check LiteScreenRecorderSvc Logcat."
                    : "MP4 save failed. Check LiteScreenRecorderSvc Logcat for the exact storage or encoder error.";
            Log.w(TAG, "Recording produced no valid MP4; removing the incomplete output.");
            deleteOutputTarget();
        }
        if (saved) sessionResultMessage = "Saved: " + outputDisplayName + " in Movies/LiteScreenRecorder.";

        releaseRecordingWakeLock();
        stopForeground(true);
        foregroundStarted = false;
        broadcastState(saved ? outputDisplayName : null);
        mainHandler.post(() -> {
            if (preferences.isOverlayEnabled()) {
                showOverlayIfAllowed();
                updateBubbleText();
            } else {
                removeOverlayViews();
            }
        });
        if (!preferences.isOverlayEnabled()) stopSelf();
    }

    private void acquireRecordingWakeLock() {
        try {
            PowerManager power = (PowerManager) getSystemService(POWER_SERVICE);
            if (power == null) return;
            if (recordingWakeLock == null) {
                recordingWakeLock = power.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK,
                        "LiteScreenRecorder:Capture");
                recordingWakeLock.setReferenceCounted(false);
            }
            if (!recordingWakeLock.isHeld()) recordingWakeLock.acquire(8L * 60L * 60L * 1000L);
            Log.i(TAG, "Partial wake lock acquired for long-running capture.");
        } catch (Throwable error) {
            Log.w(TAG, "Could not acquire partial wake lock; device may suspend capture while screen is off.", error);
        }
    }

    private void releaseRecordingWakeLock() {
        try {
            if (recordingWakeLock != null && recordingWakeLock.isHeld()) recordingWakeLock.release();
        } catch (Throwable error) {
            Log.w(TAG, "Wake lock release failed.", error);
        }
        recordingWakeLock = null;
    }

    private void releaseVideoEncoder() {
        if (videoEncoder != null) {
            try { videoEncoder.stop(); } catch (Throwable ignored) { }
            try { videoEncoder.release(); } catch (Throwable ignored) { }
            videoEncoder = null;
        }
        if (videoInputSurface != null) {
            try { videoInputSurface.release(); } catch (Throwable ignored) { }
            videoInputSurface = null;
        }
    }

    private void releaseAudioEncoder() {
        if (audioEncoder != null) {
            try { audioEncoder.stop(); } catch (Throwable ignored) { }
            try { audioEncoder.release(); } catch (Throwable ignored) { }
            audioEncoder = null;
        }
    }

    private void safeReleaseAudioRecords() {
        safeStopReleasePlaybackRecord();
        safeStopReleaseMicrophoneRecord();
        audioCaptureRunning = false;
    }

    private void safeStopReleasePlaybackRecord() {
        if (playbackAudioRecord == null) return;
        try { if (playbackAudioRecord.getRecordingState() == AudioRecord.RECORDSTATE_RECORDING) playbackAudioRecord.stop(); }
        catch (Throwable ignored) { }
        try { playbackAudioRecord.release(); } catch (Throwable ignored) { }
        playbackAudioRecord = null;
    }

    private void safeStopReleaseMicrophoneRecord() {
        if (microphoneAudioRecord == null) return;
        try { if (microphoneAudioRecord.getRecordingState() == AudioRecord.RECORDSTATE_RECORDING) microphoneAudioRecord.stop(); }
        catch (Throwable ignored) { }
        try { microphoneAudioRecord.release(); } catch (Throwable ignored) { }
        microphoneAudioRecord = null;
    }

    /**
     * Use an app-owned temporary file while muxing on Android 10+. Publishing directly to a
     * pending MediaStore descriptor proved fragile on a number of vendor storage providers:
     * metadata could remain zero-sized and descriptor lifetime was coupled to the muxer.
     * The finalized MP4 is now copied into MediaStore only after muxer.stop/release succeeds.
     */
    private void prepareOutputTarget() throws IOException {
        String stamp = new SimpleDateFormat("yyyyMMdd_HHmmss_SSS", Locale.US).format(new Date());
        outputDisplayName = "ScreenRecord_" + stamp + ".mp4";
        outputUri = null;
        outputFile = null;
        outputTempFile = null;
        if (Build.VERSION.SDK_INT >= 29) {
            File tempDirectory = getExternalFilesDir(Environment.DIRECTORY_MOVIES);
            if (tempDirectory == null) tempDirectory = getCacheDir();
            if (!tempDirectory.exists() && !tempDirectory.mkdirs()) tempDirectory = getCacheDir();
            outputTempFile = new File(tempDirectory, outputDisplayName);
            if (outputTempFile.exists() && !outputTempFile.delete()) {
                outputTempFile = new File(getCacheDir(), outputDisplayName);
            }
            if (!outputTempFile.createNewFile()) {
                outputTempFile = new File(getCacheDir(), outputDisplayName);
                if (outputTempFile.exists() && !outputTempFile.delete()) {
                    throw new IOException("Could not clear the fallback temporary MP4.");
                }
                if (!outputTempFile.createNewFile()) {
                    throw new IOException("Could not create temporary MP4 file at " + outputTempFile);
                }
            }
        } else {
            File movies = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_MOVIES);
            File folder = new File(movies, "LiteScreenRecorder");
            if (!folder.exists() && !folder.mkdirs()) {
                throw new IOException("Could not create Movies/LiteScreenRecorder.");
            }
            outputFile = new File(folder, outputDisplayName);
            if (outputFile.exists() && !outputFile.delete()) {
                throw new IOException("Could not replace an existing output file.");
            }
        }
    }

    private boolean finalizeOutputTarget() {
        if (muxerFailed || !muxerWasStartedOrSaved() || videoSamplesWritten <= 0L) {
            Log.e(TAG, "MP4 finalization rejected: muxerFailed=" + muxerFailed
                    + ", muxerCompleted=" + outputMuxerCompleted
                    + ", videoSamples=" + videoSamplesWritten);
            return false;
        }

        if (Build.VERSION.SDK_INT >= 29) {
            if (outputTempFile == null || !outputTempFile.exists() || outputTempFile.length() <= 0L) {
                Log.e(TAG, "Temporary MP4 is missing or empty.");
                return false;
            }
            long expectedBytes = outputTempFile.length();
            ContentValues values = new ContentValues();
            values.put(MediaStore.Video.Media.DISPLAY_NAME, outputDisplayName);
            values.put(MediaStore.Video.Media.MIME_TYPE, "video/mp4");
            values.put(MediaStore.Video.Media.RELATIVE_PATH, outputRelativePath);
            values.put(MediaStore.Video.Media.IS_PENDING, 1);
            Uri pendingUri = null;
            long copied = 0L;
            try {
                pendingUri = getContentResolver().insert(
                        MediaStore.Video.Media.EXTERNAL_CONTENT_URI, values);
                if (pendingUri == null) throw new IOException("MediaStore insert returned null.");
                try (FileInputStream input = new FileInputStream(outputTempFile);
                     OutputStream output = getContentResolver().openOutputStream(pendingUri, "w")) {
                    if (output == null) throw new IOException("MediaStore output stream was null.");
                    byte[] buffer = new byte[64 * 1024];
                    int count;
                    while ((count = input.read(buffer)) != -1) {
                        output.write(buffer, 0, count);
                        copied += count;
                    }
                    output.flush();
                }
                if (copied != expectedBytes || copied <= 0L) {
                    throw new IOException("Incomplete MediaStore copy: " + copied + "/" + expectedBytes);
                }
                ContentValues publish = new ContentValues();
                publish.put(MediaStore.Video.Media.IS_PENDING, 0);
                int updated = getContentResolver().update(pendingUri, publish, null, null);
                if (updated <= 0) throw new IOException("Could not publish the completed MediaStore row.");
                outputUri = pendingUri;
                Log.i(TAG, "Published MP4 to MediaStore: " + outputUri + " bytes=" + copied);
                // Query size for diagnostics only. Some providers lag behind the completed copy.
                long indexedSize = queryOutputSize(outputUri);
                Log.i(TAG, "MediaStore reports file size=" + indexedSize);
                if (outputTempFile.exists() && !outputTempFile.delete()) {
                    Log.w(TAG, "Could not remove temporary MP4: " + outputTempFile);
                }
                return true;
            } catch (Throwable error) {
                Log.e(TAG, "Could not publish MP4 to MediaStore.", error);
                if (pendingUri != null) {
                    try { getContentResolver().delete(pendingUri, null, null); }
                    catch (Throwable ignored) { }
                }
                outputUri = null;
                preserveOutputTempFile = outputTempFile != null
                        && outputTempFile.exists() && outputTempFile.length() > 0L;
                if (preserveOutputTempFile) {
                    Log.e(TAG, "Completed MP4 retained for recovery at " + outputTempFile);
                }
                return false;
            }
        }

        if (outputFile != null && outputFile.exists() && outputFile.length() > 0L) {
            try {
                android.media.MediaScannerConnection.scanFile(this,
                        new String[]{outputFile.getAbsolutePath()}, new String[]{"video/mp4"},
                        (path, uri) -> Log.i(TAG, "MediaScanner indexed " + path + " -> " + uri));
            } catch (Throwable error) {
                Log.w(TAG, "MediaScannerConnection failed.", error);
            }
            return true;
        }
        Log.e(TAG, "Legacy MP4 output is missing or empty.");
        return false;
    }

    // This flag is set only after MediaMuxer.stop() and release() complete successfully.
    private boolean muxerWasStartedOrSaved() { return outputMuxerCompleted; }
    private boolean outputMuxerCompleted;

    private long queryOutputSize(Uri uri) {
        android.database.Cursor cursor = null;
        try {
            cursor = getContentResolver().query(uri,
                    new String[]{MediaStore.Video.Media.SIZE}, null, null, null);
            if (cursor != null && cursor.moveToFirst()) return cursor.getLong(0);
        } catch (Throwable error) {
            Log.w(TAG, "Could not query MediaStore file size.", error);
        } finally {
            if (cursor != null) cursor.close();
        }
        return 0L;
    }

    private void deleteOutputTarget() {
        try {
            if (outputUri != null) getContentResolver().delete(outputUri, null, null);
            if (outputFile != null && outputFile.exists()) {
                //noinspection ResultOfMethodCallIgnored
                outputFile.delete();
            }
            if (!preserveOutputTempFile && outputTempFile != null && outputTempFile.exists()) {
                //noinspection ResultOfMethodCallIgnored
                outputTempFile.delete();
            }
        } catch (Throwable error) {
            Log.w(TAG, "Could not delete incomplete recording.", error);
        }
    }

    private void joinThread(Thread thread, long timeoutMs) {
        if (thread == null || thread == Thread.currentThread()) return;
        try { thread.join(timeoutMs); }
        catch (InterruptedException error) { Thread.currentThread().interrupt(); }
        if (thread.isAlive()) Log.w(TAG, "Timed out joining " + thread.getName());
    }

    private static void sleepQuietly(long millis) {
        try { Thread.sleep(millis); } catch (InterruptedException error) { Thread.currentThread().interrupt(); }
    }

    private void broadcastState(String savedLabel) {
        Intent intent = new Intent(ACTION_STATE_CHANGED);
        intent.setPackage(getPackageName());
        intent.putExtra(EXTRA_STATE, state);
        intent.putExtra(EXTRA_DURATION_MS, sessionActive ? getActiveTimeUs() / 1000L
                : preferences.getLiveDurationMs());
        if (savedLabel != null) intent.putExtra(EXTRA_SAVED_LABEL, savedLabel);
        if (sessionResultMessage != null) intent.putExtra(EXTRA_RESULT_MESSAGE, sessionResultMessage);
        sendBroadcast(intent);
    }

    private void createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationChannel channel = new NotificationChannel(NOTIFICATION_CHANNEL_ID,
                    getString(R.string.notification_channel), NotificationManager.IMPORTANCE_LOW);
            channel.setDescription("Shows the ongoing screen recording state and stop action.");
            NotificationManager manager = getSystemService(NotificationManager.class);
            if (manager != null) manager.createNotificationChannel(channel);
        }
    }

    private Notification buildNotification(boolean isPaused) {
        Intent open = new Intent(this, MainActivity.class);
        open.addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        PendingIntent content = PendingIntent.getActivity(this, 10, open,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        Intent stop = new Intent(this, ScreenRecordService.class);
        stop.setAction(ACTION_STOP);
        PendingIntent stopPending = PendingIntent.getService(this, 11, stop,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        Notification.Builder builder = Build.VERSION.SDK_INT >= 26
                ? new Notification.Builder(this, NOTIFICATION_CHANNEL_ID)
                : new Notification.Builder(this);
        builder.setSmallIcon(android.R.drawable.presence_video_online)
                .setContentTitle(getString(R.string.app_name))
                .setContentText(getString(isPaused ? R.string.notification_paused : R.string.notification_recording))
                .setContentIntent(content)
                .setOngoing(true)
                .setOnlyAlertOnce(true)
                .addAction(new Notification.Action.Builder(android.R.drawable.ic_media_pause,
                        getString(R.string.notification_stop), stopPending).build());
        return builder.build();
    }

    private void updateNotification(boolean isPaused) {
        NotificationManager manager = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
        if (manager != null) manager.notify(NOTIFICATION_ID, buildNotification(isPaused));
    }

    private void showOverlayIfAllowed() {
        if (!preferences.isOverlayEnabled() || !Settings.canDrawOverlays(this) || windowManager == null) return;
        if (bubbleView != null) {
            updateBubbleText();
            return;
        }
        try {
            bubbleView = LayoutInflater.from(this).inflate(R.layout.floating_bubble, null, false);
            int type = Build.VERSION.SDK_INT >= 26
                    ? WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
                    : WindowManager.LayoutParams.TYPE_PHONE;
            bubbleParams = new WindowManager.LayoutParams(
                    WindowManager.LayoutParams.WRAP_CONTENT,
                    WindowManager.LayoutParams.WRAP_CONTENT,
                    type,
                    WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                            | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
                    PixelFormat.TRANSLUCENT);
            bubbleParams.gravity = Gravity.TOP | Gravity.START;
            bubbleParams.x = dp(18);
            bubbleParams.y = dp(180);
            bubbleView.setOnTouchListener(new BubbleTouchListener());
            windowManager.addView(bubbleView, bubbleParams);
            updateBubbleText();
        } catch (Throwable error) {
            Log.e(TAG, "Could not show floating bubble.", error);
            removeOverlayViews();
        }
    }

    private void updateBubbleText() {
        if (bubbleView != null) {
            TextView status = bubbleView.findViewById(R.id.bubbleStatus);
            TextView timer = bubbleView.findViewById(R.id.bubbleTimer);
            if (status != null) {
                if (RecordingPreferences.STATE_RECORDING.equals(state)) {
                    status.setText("● REC");
                    status.setTextColor(0xFFFF7272);
                } else if (RecordingPreferences.STATE_PAUSED.equals(state)) {
                    status.setText("Ⅱ PAUSE");
                    status.setTextColor(0xFFFFD166);
                } else {
                    status.setText("LSR");
                    status.setTextColor(0xFFFFFFFF);
                }
            }
            if (timer != null) {
                timer.setText(sessionActive ? formatDuration(getActiveTimeUs() / 1000L) : "READY");
            }
        }
        updateFloatingControls();
    }

    private String formatDuration(long durationMs) {
        long seconds = Math.max(0L, durationMs / 1000L);
        long hours = seconds / 3600L;
        long minutes = (seconds % 3600L) / 60L;
        long remainder = seconds % 60L;
        if (hours > 0L) return String.format(Locale.US, "%02d:%02d:%02d", hours, minutes, remainder);
        return String.format(Locale.US, "%02d:%02d", minutes, remainder);
    }

    private void toggleFloatingControls() {
        if (controlsView != null) hideFloatingControls();
        else showFloatingControls();
    }

    private void showFloatingControls() {
        if (!Settings.canDrawOverlays(this) || windowManager == null) return;
        if (controlsView != null) {
            updateFloatingControls();
            return;
        }
        try {
            controlsView = LayoutInflater.from(this).inflate(R.layout.floating_controls, null, false);
            updateFloatingControls();
            int type = Build.VERSION.SDK_INT >= 26
                    ? WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
                    : WindowManager.LayoutParams.TYPE_PHONE;
            controlsParams = new WindowManager.LayoutParams(
                    WindowManager.LayoutParams.WRAP_CONTENT,
                    WindowManager.LayoutParams.WRAP_CONTENT,
                    type,
                    WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                            | WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL
                            | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
                    PixelFormat.TRANSLUCENT);
            controlsParams.gravity = Gravity.TOP | Gravity.START;
            controlsView.measure(
                    View.MeasureSpec.makeMeasureSpec(0, View.MeasureSpec.UNSPECIFIED),
                    View.MeasureSpec.makeMeasureSpec(0, View.MeasureSpec.UNSPECIFIED));
            DisplayMetrics screenMetrics = new DisplayMetrics();
            windowManager.getDefaultDisplay().getRealMetrics(screenMetrics);
            int menuWidth = Math.max(dp(48), controlsView.getMeasuredWidth());
            int menuHeight = Math.max(dp(48), controlsView.getMeasuredHeight());
            int wantedX = bubbleParams == null ? dp(16) : bubbleParams.x;
            int wantedY = bubbleParams == null ? dp(250) : bubbleParams.y + dp(74);
            if (wantedY + menuHeight > screenMetrics.heightPixels && bubbleParams != null) {
                wantedY = bubbleParams.y - menuHeight - dp(8);
            }
            controlsParams.x = Math.max(0, Math.min(wantedX, screenMetrics.widthPixels - menuWidth));
            controlsParams.y = Math.max(0, Math.min(wantedY, screenMetrics.heightPixels - menuHeight));

            TextView start = controlsView.findViewById(R.id.overlayStart);
            TextView pauseResume = controlsView.findViewById(R.id.overlayPauseResume);
            TextView stop = controlsView.findViewById(R.id.overlayStop);
            start.setOnClickListener(v -> {
                hideFloatingControls();
                if (sessionActive) return;
                Intent open = new Intent(this, MainActivity.class);
                open.putExtra(MainActivity.EXTRA_AUTO_START, true);
                open.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP
                        | Intent.FLAG_ACTIVITY_SINGLE_TOP);
                startActivity(open);
            });
            pauseResume.setOnClickListener(v -> {
                hideFloatingControls();
                if (!sessionActive) return;
                Intent command = new Intent(this, ScreenRecordService.class);
                command.setAction(ACTION_TOGGLE_PAUSE);
                startService(command);
            });
            stop.setOnClickListener(v -> {
                hideFloatingControls();
                if (!sessionActive) return;
                Intent command = new Intent(this, ScreenRecordService.class);
                command.setAction(ACTION_STOP);
                startService(command);
            });
            windowManager.addView(controlsView, controlsParams);
            updateFloatingControls();
        } catch (Throwable error) {
            Log.e(TAG, "Could not show floating control menu.", error);
            hideFloatingControls();
        }
    }

    private void updateFloatingControls() {
        if (controlsView == null) return;
        TextView start = controlsView.findViewById(R.id.overlayStart);
        TextView pauseResume = controlsView.findViewById(R.id.overlayPauseResume);
        TextView stop = controlsView.findViewById(R.id.overlayStop);
        boolean active = sessionActive;
        boolean recording = RecordingPreferences.STATE_RECORDING.equals(state);
        boolean pausedNow = RecordingPreferences.STATE_PAUSED.equals(state);
        if (start != null) {
            start.setVisibility(active ? View.GONE : View.VISIBLE);
            start.setContentDescription(getString(R.string.bubble_start));
        }
        if (pauseResume != null) {
            pauseResume.setVisibility(active ? View.VISIBLE : View.GONE);
            pauseResume.setText(pausedNow ? "▶" : "Ⅱ");
            pauseResume.setContentDescription(getString(R.string.bubble_pause_resume));
            pauseResume.setEnabled(active && (recording || pausedNow));
        }
        if (stop != null) {
            stop.setVisibility(active ? View.VISIBLE : View.GONE);
            stop.setContentDescription(getString(R.string.bubble_stop));
            stop.setEnabled(active);
        }
    }

    private void hideFloatingControls() {
        if (controlsView != null && windowManager != null) {
            try { windowManager.removeView(controlsView); } catch (Throwable ignored) { }
        }
        controlsView = null;
        controlsParams = null;
    }

    private void removeOverlayViews() {
        hideFloatingControls();
        if (bubbleView != null && windowManager != null) {
            try { windowManager.removeView(bubbleView); } catch (Throwable ignored) { }
        }
        bubbleView = null;
        bubbleParams = null;
    }

    private int dp(float value) {
        return (int) (value * getResources().getDisplayMetrics().density + 0.5f);
    }

    private final class BubbleTouchListener implements View.OnTouchListener {
        private int startX;
        private int startY;
        private float downX;
        private float downY;
        private boolean dragged;

        @Override public boolean onTouch(View view, MotionEvent event) {
            if (bubbleParams == null) return false;
            switch (event.getAction()) {
                case MotionEvent.ACTION_DOWN:
                    startX = bubbleParams.x;
                    startY = bubbleParams.y;
                    downX = event.getRawX();
                    downY = event.getRawY();
                    dragged = false;
                    return true;
                case MotionEvent.ACTION_MOVE:
                    int dx = (int) (event.getRawX() - downX);
                    int dy = (int) (event.getRawY() - downY);
                    if (Math.abs(dx) > dp(5) || Math.abs(dy) > dp(5)) dragged = true;
                    if (dragged) {
                        DisplayMetrics screenMetrics = new DisplayMetrics();
                        windowManager.getDefaultDisplay().getRealMetrics(screenMetrics);
                        int bubbleWidth = bubbleView.getWidth() > 0 ? bubbleView.getWidth() : dp(68);
                        int bubbleHeight = bubbleView.getHeight() > 0 ? bubbleView.getHeight() : dp(68);
                        bubbleParams.x = Math.max(0, Math.min(startX + dx, screenMetrics.widthPixels - bubbleWidth));
                        bubbleParams.y = Math.max(0, Math.min(startY + dy, screenMetrics.heightPixels - bubbleHeight));
                        try { windowManager.updateViewLayout(bubbleView, bubbleParams); }
                        catch (Throwable error) { Log.d(TAG, "Bubble position update skipped.", error); }
                    }
                    return true;
                case MotionEvent.ACTION_UP:
                    if (!dragged) toggleFloatingControls();
                    return true;
                default:
                    return true;
            }
        }
    }

    @Override
    public void onTaskRemoved(Intent rootIntent) {
        // A correctly running foreground mediaProjection service is allowed to continue
        // after the activity is swiped away. Do not stop a valid session here.
        super.onTaskRemoved(rootIntent);
    }

    @Override
    public void onDestroy() {
        if (sessionActive && !stopStarted.get()) requestStop(false);
        removeOverlayViews();
        releaseRecordingWakeLock();
        if (callbackThread != null) {
            try { callbackThread.quitSafely(); } catch (Throwable ignored) { }
            callbackThread = null;
        }
        super.onDestroy();
    }
}
