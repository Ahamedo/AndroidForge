package com.example.litescreenrecorder;

import android.Manifest;
import android.app.Activity;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.ServiceInfo;
import android.graphics.PixelFormat;
import android.graphics.Point;
import android.media.AudioAttributes;
import android.media.AudioFormat;
import android.media.AudioPlaybackCaptureConfiguration;
import android.media.AudioRecord;
import android.media.MediaCodec;
import android.media.MediaCodecInfo;
import android.media.MediaFormat;
import android.media.MediaMuxer;
import android.media.MediaRecorder;
import android.media.projection.MediaProjection;
import android.media.projection.MediaProjectionManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.os.ParcelFileDescriptor;
import android.provider.MediaStore;
import android.provider.Settings;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.Surface;
import android.view.View;
import android.view.WindowManager;
import android.hardware.display.DisplayManager;
import android.hardware.display.VirtualDisplay;
import android.widget.Button;
import android.widget.TextView;
import android.media.MediaScannerConnection;

import androidx.core.app.NotificationCompat;
import androidx.core.content.ContextCompat;

import java.io.File;
import java.io.IOException;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;
import java.util.concurrent.atomic.AtomicBoolean;

/**
 * Foreground recording engine. It owns the one-use MediaProjection token, virtual display,
 * surface AVC encoder, optional AAC/audio capture, muxer, output URI and floating controls.
 */
public class ScreenRecordService extends Service {
    public static final String ACTION_START = "com.example.litescreenrecorder.action.START";
    public static final String ACTION_STOP = "com.example.litescreenrecorder.action.STOP";
    public static final String ACTION_PAUSE_TOGGLE = "com.example.litescreenrecorder.action.PAUSE_TOGGLE";
    public static final String ACTION_SYNC_OVERLAY = "com.example.litescreenrecorder.action.SYNC_OVERLAY";
    public static final String ACTION_QUERY_STATE = "com.example.litescreenrecorder.action.QUERY_STATE";
    public static final String ACTION_STATE_CHANGED = "com.example.litescreenrecorder.action.STATE_CHANGED";
    public static final String EXTRA_RESULT_CODE = "capture_result_code";
    public static final String EXTRA_RESULT_DATA = "capture_result_data";
    public static final String EXTRA_STATE = "capture_state";
    public static final String EXTRA_SAVED_NAME = "saved_name";
    public static final String EXTRA_SAVED_URI = "saved_uri";
    public static final String EXTRA_AUTO_START = "auto_start_capture";

    private static final String TAG = "LiteScreenRecorderSvc";
    private static final String NOTIFICATION_CHANNEL = "screen_recording";
    private static final int NOTIFICATION_ID = 7401;
    private static final int VIDEO_DRAIN_TIMEOUT_US = 10_000;
    private static final int AUDIO_SAMPLE_RATE = 44_100;
    private static final int AUDIO_CHANNELS = 1;
    private static final int AUDIO_INPUT_SAMPLES = 2_048;

    private final Handler mainHandler = new Handler(Looper.getMainLooper());
    private final AtomicBoolean stopping = new AtomicBoolean(false);
    private RecordingPreferences preferences;

    private volatile String state = RecordingPreferences.STATE_IDLE;
    private volatile boolean paused;
    private boolean foreground;

    private MediaProjection projection;
    private MediaProjection.Callback projectionCallback;
    private VirtualDisplay virtualDisplay;

    private MediaCodec videoEncoder;
    private MediaCodec audioEncoder;
    private Surface videoInputSurface;
    private volatile AudioRecord playbackRecord;
    private volatile AudioRecord microphoneRecord;
    private Thread videoDrainThread;
    private Thread audioThread;
    private MuxerCoordinator muxerCoordinator;

    private volatile boolean stopAudioThread;
    private volatile boolean videoEos;
    private volatile boolean audioEos;
    private volatile long presentationTimeOffsetUs;
    private volatile long pauseStartedAtUs;
    private volatile long sessionStartUs;
    private volatile long videoOriginPtsUs = -1;
    private volatile boolean videoOriginReady;
    private long lastVideoPtsUs = -1;
    private long lastAudioPtsUs = -1;

    private Uri outputUri;
    private File outputFile;
    private ParcelFileDescriptor outputPfd;
    private String outputName;
    private String outputDisplayPath;

    private WindowManager windowManager;
    private View bubbleView;
    private View controlsView;
    private WindowManager.LayoutParams bubbleParams;
    private WindowManager.LayoutParams controlsParams;
    private int bubbleX = 24;
    private int bubbleY = 220;

    @Override
    public void onCreate() {
        super.onCreate();
        preferences = new RecordingPreferences(this);
        windowManager = (WindowManager) getSystemService(WINDOW_SERVICE);
        createNotificationChannel();
        // A newly created service cannot be assumed to own a previous process's codec/projection.
        state = RecordingPreferences.STATE_IDLE;
        preferences.setServiceState(state);
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        String action = intent == null ? ACTION_QUERY_STATE : intent.getAction();
        if (ACTION_START.equals(action)) {
            int resultCode = intent.getIntExtra(EXTRA_RESULT_CODE, 0);
            Intent data = intent.getParcelableExtra(EXTRA_RESULT_DATA);
            beginRecording(resultCode, data);
        } else if (ACTION_STOP.equals(action)) {
            stopRecording(false);
        } else if (ACTION_PAUSE_TOGGLE.equals(action)) {
            togglePauseResume();
        } else if (ACTION_SYNC_OVERLAY.equals(action)) {
            syncOverlay();
            broadcastState();
            stopIdleServiceWhenUnneeded();
        } else {
            syncOverlay();
            broadcastState();
            stopIdleServiceWhenUnneeded();
        }
        return START_NOT_STICKY;
    }


    private void stopIdleServiceWhenUnneeded() {
        boolean idle = RecordingPreferences.STATE_IDLE.equals(state);
        if (idle && !preferences.isOverlayEnabled() && !foreground) {
            stopSelf();
        }
    }

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    private void beginRecording(int resultCode, Intent resultData) {
        if (RecordingPreferences.STATE_RECORDING.equals(state) || RecordingPreferences.STATE_PAUSED.equals(state)) {
            broadcastState();
            return;
        }
        if (resultData == null || resultCode != Activity.RESULT_OK) {
            notifyFailure("Screen-capture consent data is missing.");
            return;
        }

        stopping.set(false);
        paused = false;
        stopAudioThread = false;
        videoEos = false;
        audioEos = false;
        presentationTimeOffsetUs = 0;
        pauseStartedAtUs = 0;
        lastVideoPtsUs = -1;
        lastAudioPtsUs = -1;
        sessionStartUs = System.nanoTime() / 1_000L;
        videoOriginPtsUs = -1;
        videoOriginReady = false;

        try {
            startRecordingForeground();

            // Android 14: the correctly typed FGS must be running before getMediaProjection().
            MediaProjectionManager manager = (MediaProjectionManager) getSystemService(MEDIA_PROJECTION_SERVICE);
            projection = manager == null ? null : manager.getMediaProjection(resultCode, resultData);
            if (projection == null) throw new IllegalStateException("MediaProjection could not be created.");

            projectionCallback = new MediaProjection.Callback() {
                @Override
                public void onStop() {
                    Log.i(TAG, "MediaProjection stopped by system/user.");
                    stopRecording(true);
                }
            };
            projection.registerCallback(projectionCallback, mainHandler);

            createOutputFile();
            prepareVideoEncoder();
            prepareAudioCaptureAndEncoder();

            if (audioEncoder != null) {
                try {
                    audioEncoder.start();
                } catch (Exception audioStartError) {
                    Log.w(TAG, "AAC encoder failed to start; switching to video-only", audioStartError);
                    try { audioEncoder.release(); } catch (Exception ignored) { }
                    audioEncoder = null;
                    stopAndReleaseAudioRecords();
                }
            }
            int expectedTracks = 1 + (audioEncoder != null ? 1 : 0);
            muxerCoordinator = new MuxerCoordinator(outputMuxer, expectedTracks);

            videoDrainThread = new Thread(this::drainVideoEncoder, "LiteRecorder-VideoDrain");
            videoDrainThread.start();
            if (audioEncoder != null) {
                audioThread = new Thread(this::runAudioPipeline, "LiteRecorder-Audio");
                audioThread.start();
            }

            // The callback above is registered before createVirtualDisplay(), as required by API.
            DisplayMetrics metrics = getResources().getDisplayMetrics();
            int densityDpi = metrics.densityDpi;
            virtualDisplay = projection.createVirtualDisplay(
                    "LiteScreenRecorder",
                    videoWidth,
                    videoHeight,
                    densityDpi,
                    DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
                    videoInputSurface,
                    null,
                    mainHandler);
            if (virtualDisplay == null) throw new IllegalStateException("Virtual display creation failed.");

            state = RecordingPreferences.STATE_RECORDING;
            preferences.setServiceState(state);
            updateNotification();
            syncOverlay();
            broadcastState();
            Log.i(TAG, "Recording started: " + videoWidth + "x" + videoHeight + " @ " + effectiveFps + "fps");
        } catch (Exception e) {
            Log.e(TAG, "Unable to start recording", e);
            stopRecording(false);
            notifyFailure("Could not start recording: " + e.getMessage());
        }
    }

    private MediaMuxer outputMuxer;
    private int videoWidth;
    private int videoHeight;
    private int effectiveFps;

    private void startRecordingForeground() {
        Notification notification = buildNotification();
        if (Build.VERSION.SDK_INT >= 29) {
            int serviceTypes = ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION;
            boolean audioPermission = ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO)
                    == PackageManager.PERMISSION_GRANTED;
            if (audioPermission && Build.VERSION.SDK_INT >= 30) {
                serviceTypes |= ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE;
            }
            startForeground(NOTIFICATION_ID, notification, serviceTypes);
        } else {
            startForeground(NOTIFICATION_ID, notification);
        }
        foreground = true;
    }

    private void createOutputFile() throws IOException {
        String stamp = new SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(new Date());
        outputName = "LiteScreenRecorder_" + stamp + ".mp4";
        outputUri = null;
        outputFile = null;
        outputPfd = null;

        if (Build.VERSION.SDK_INT >= 29) {
            ContentValues values = new ContentValues();
            values.put(MediaStore.Video.Media.DISPLAY_NAME, outputName);
            values.put(MediaStore.Video.Media.MIME_TYPE, "video/mp4");
            values.put(MediaStore.Video.Media.RELATIVE_PATH,
                    Environment.DIRECTORY_MOVIES + "/LiteScreenRecorder");
            values.put(MediaStore.Video.Media.IS_PENDING, 1);
            outputUri = getContentResolver().insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, values);
            if (outputUri == null) throw new IOException("MediaStore could not create the recording entry.");
            outputPfd = getContentResolver().openFileDescriptor(outputUri, "w");
            if (outputPfd == null) throw new IOException("Could not open the MediaStore output descriptor.");
            outputMuxer = new MediaMuxer(outputPfd.getFileDescriptor(), MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4);
            outputDisplayPath = "Movies/LiteScreenRecorder/" + outputName;
        } else {
            File movies;
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.WRITE_EXTERNAL_STORAGE)
                    == PackageManager.PERMISSION_GRANTED) {
                movies = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_MOVIES);
            } else {
                movies = getExternalFilesDir(Environment.DIRECTORY_MOVIES);
            }
            if (movies == null) throw new IOException("No writable Movies directory is available.");
            File folder = new File(movies, "LiteScreenRecorder");
            if (!folder.exists() && !folder.mkdirs()) throw new IOException("Could not create Movies/LiteScreenRecorder.");
            outputFile = new File(folder, outputName);
            outputMuxer = new MediaMuxer(outputFile.getAbsolutePath(), MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4);
            outputDisplayPath = outputFile.getAbsolutePath();
        }
    }

    private void prepareVideoEncoder() throws IOException {
        String quality = preferences.getQuality();
        Point initialSize = RecordingPreferences.calculateVideoSize(this, quality);
        int initialFps = RecordingPreferences.getEffectiveFrameRate(this, quality, preferences.getFrameRate());

        // Devices differ substantially. Retry downwards instead of failing the whole session.
        int[][] attempts;
        if (RecordingPreferences.QUALITY_1080.equals(quality)) {
            attempts = new int[][]{{initialSize.x, initialSize.y, initialFps},
                    {initialSize.x, initialSize.y, 30},
                    {RecordingPreferences.calculateVideoSize(this, RecordingPreferences.QUALITY_720).x,
                            RecordingPreferences.calculateVideoSize(this, RecordingPreferences.QUALITY_720).y, 30},
                    {RecordingPreferences.calculateVideoSize(this, RecordingPreferences.QUALITY_480).x,
                            RecordingPreferences.calculateVideoSize(this, RecordingPreferences.QUALITY_480).y, 30}};
        } else if (RecordingPreferences.QUALITY_720.equals(quality)) {
            attempts = initialFps > 60
                    ? new int[][]{{initialSize.x, initialSize.y, initialFps}, {initialSize.x, initialSize.y, 60},
                    {initialSize.x, initialSize.y, 30},
                    {RecordingPreferences.calculateVideoSize(this, RecordingPreferences.QUALITY_480).x,
                            RecordingPreferences.calculateVideoSize(this, RecordingPreferences.QUALITY_480).y, 30}}
                    : new int[][]{{initialSize.x, initialSize.y, initialFps}, {initialSize.x, initialSize.y, 30},
                    {RecordingPreferences.calculateVideoSize(this, RecordingPreferences.QUALITY_480).x,
                            RecordingPreferences.calculateVideoSize(this, RecordingPreferences.QUALITY_480).y, 30}};
        } else {
            attempts = initialFps > 60
                    ? new int[][]{{initialSize.x, initialSize.y, initialFps}, {initialSize.x, initialSize.y, 60},
                    {initialSize.x, initialSize.y, 30}}
                    : new int[][]{{initialSize.x, initialSize.y, initialFps}, {initialSize.x, initialSize.y, 30}};
        }

        Exception lastError = null;
        for (int[] attempt : attempts) {
            MediaCodec candidate = null;
            Surface candidateSurface = null;
            try {
                int width = RecordingPreferences.makeEven(attempt[0]);
                int height = RecordingPreferences.makeEven(attempt[1]);
                int fps = Math.max(15, Math.min(90, attempt[2]));
                int bitrate = RecordingPreferences.calculateVideoBitrate(new Point(width, height), fps);
                MediaFormat format = MediaFormat.createVideoFormat(MediaFormat.MIMETYPE_VIDEO_AVC, width, height);
                format.setInteger(MediaFormat.KEY_COLOR_FORMAT, MediaCodecInfo.CodecCapabilities.COLOR_FormatSurface);
                format.setInteger(MediaFormat.KEY_BIT_RATE, bitrate);
                format.setInteger(MediaFormat.KEY_FRAME_RATE, fps);
                format.setInteger(MediaFormat.KEY_I_FRAME_INTERVAL, 2);
                format.setInteger(MediaFormat.KEY_BITRATE_MODE, MediaCodecInfo.EncoderCapabilities.BITRATE_MODE_VBR);

                candidate = MediaCodec.createEncoderByType(MediaFormat.MIMETYPE_VIDEO_AVC);
                candidate.configure(format, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE);
                candidateSurface = candidate.createInputSurface();
                candidate.start();

                videoEncoder = candidate;
                videoInputSurface = candidateSurface;
                videoWidth = width;
                videoHeight = height;
                effectiveFps = fps;
                return;
            } catch (Exception e) {
                lastError = e;
                Log.w(TAG, "Video encoder rejected " + attempt[0] + "x" + attempt[1] + " @" + attempt[2] + "; trying fallback", e);
                if (candidateSurface != null) {
                    try { candidateSurface.release(); } catch (Exception ignored) { }
                }
                if (candidate != null) {
                    try { candidate.stop(); } catch (Exception ignored) { }
                    try { candidate.release(); } catch (Exception ignored) { }
                }
            }
        }
        if (lastError instanceof IOException) throw (IOException) lastError;
        throw new IOException("No supported H.264 surface encoder configuration was found.", lastError);
    }

    private void prepareAudioCaptureAndEncoder() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO)
                != PackageManager.PERMISSION_GRANTED) {
            Log.w(TAG, "RECORD_AUDIO not granted; continuing video-only.");
            return;
        }

        String mode = preferences.getAudioMode();
        boolean combined = RecordingPreferences.AUDIO_INTERNAL_AND_MIC.equals(mode);
        int minBuffer = AudioRecord.getMinBufferSize(AUDIO_SAMPLE_RATE,
                AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT);
        if (minBuffer <= 0) minBuffer = 16_384;
        int bufferBytes = Math.max(minBuffer * 2, 16_384);

        if (Build.VERSION.SDK_INT >= 29) {
            try {
                AudioPlaybackCaptureConfiguration config = new AudioPlaybackCaptureConfiguration.Builder(projection)
                        .addMatchingUsage(AudioAttributes.USAGE_MEDIA)
                        .addMatchingUsage(AudioAttributes.USAGE_GAME)
                        .build();
                AudioFormat format = new AudioFormat.Builder()
                        .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                        .setSampleRate(AUDIO_SAMPLE_RATE)
                        .setChannelMask(AudioFormat.CHANNEL_IN_MONO)
                        .build();
                playbackRecord = new AudioRecord.Builder()
                        .setAudioFormat(format)
                        .setBufferSizeInBytes(bufferBytes)
                        .setAudioPlaybackCaptureConfig(config)
                        .build();
                if (playbackRecord.getState() != AudioRecord.STATE_INITIALIZED) {
                    playbackRecord.release();
                    playbackRecord = null;
                }
            } catch (Exception e) {
                Log.w(TAG, "Internal playback capture unavailable; video path remains active.", e);
                releaseAudioRecord(playbackRecord);
                playbackRecord = null;
            }
        } else {
            Log.i(TAG, "API <= 28 has no AudioPlaybackCapture; internal playback audio is unavailable.");
        }

        if (combined) {
            try {
                AudioFormat microphoneFormat = new AudioFormat.Builder()
                        .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                        .setSampleRate(AUDIO_SAMPLE_RATE)
                        .setChannelMask(AudioFormat.CHANNEL_IN_MONO)
                        .build();
                microphoneRecord = new AudioRecord.Builder()
                        .setAudioSource(MediaRecorder.AudioSource.MIC)
                        .setAudioFormat(microphoneFormat)
                        .setBufferSizeInBytes(bufferBytes)
                        .build();
                if (microphoneRecord.getState() != AudioRecord.STATE_INITIALIZED) {
                    microphoneRecord.release();
                    microphoneRecord = null;
                }
            } catch (Exception e) {
                Log.w(TAG, "Microphone capture unavailable; continuing with any internal audio.", e);
                releaseAudioRecord(microphoneRecord);
                microphoneRecord = null;
            }
        }

        boolean anyAudio = playbackRecord != null || microphoneRecord != null;
        if (!anyAudio) return;

        try {
            if (playbackRecord != null) playbackRecord.startRecording();
            if (playbackRecord != null && playbackRecord.getRecordingState() != AudioRecord.RECORDSTATE_RECORDING) {
                releaseAudioRecord(playbackRecord);
                playbackRecord = null;
            }
            if (microphoneRecord != null) microphoneRecord.startRecording();
            if (microphoneRecord != null && microphoneRecord.getRecordingState() != AudioRecord.RECORDSTATE_RECORDING) {
                releaseAudioRecord(microphoneRecord);
                microphoneRecord = null;
            }
        } catch (Exception e) {
            Log.w(TAG, "AudioRecord start failed; attempting video-only recording.", e);
            stopAndReleaseAudioRecords();
        }

        if (playbackRecord == null && microphoneRecord == null) return;

        try {
            MediaFormat audioFormat = MediaFormat.createAudioFormat(MediaFormat.MIMETYPE_AUDIO_AAC,
                    AUDIO_SAMPLE_RATE, AUDIO_CHANNELS);
            audioFormat.setInteger(MediaFormat.KEY_AAC_PROFILE, MediaCodecInfo.CodecProfileLevel.AACObjectLC);
            audioFormat.setInteger(MediaFormat.KEY_BIT_RATE, 96_000);
            audioFormat.setInteger(MediaFormat.KEY_MAX_INPUT_SIZE, 16_384);
            audioEncoder = MediaCodec.createEncoderByType(MediaFormat.MIMETYPE_AUDIO_AAC);
            audioEncoder.configure(audioFormat, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE);
        } catch (Exception e) {
            Log.w(TAG, "AAC encoder unavailable; continuing video-only.", e);
            if (audioEncoder != null) {
                try { audioEncoder.release(); } catch (Exception ignored) { }
                audioEncoder = null;
            }
            stopAndReleaseAudioRecords();
        }
    }

    private void drainVideoEncoder() {
        MediaCodec.BufferInfo info = new MediaCodec.BufferInfo();
        while (!videoEos) {
            int outputIndex;
            try {
                outputIndex = videoEncoder.dequeueOutputBuffer(info, VIDEO_DRAIN_TIMEOUT_US);
            } catch (Exception e) {
                Log.e(TAG, "Video encoder drain failed", e);
                break;
            }
            if (outputIndex == MediaCodec.INFO_TRY_AGAIN_LATER) continue;
            if (outputIndex == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) {
                try {
                    muxerCoordinator.addTrack(true, videoEncoder.getOutputFormat());
                } catch (Exception e) {
                    Log.e(TAG, "Unable to add video track", e);
                    break;
                }
            } else if (outputIndex >= 0) {
                ByteBuffer encoded = videoEncoder.getOutputBuffer(outputIndex);
                if (encoded != null && info.size > 0) {
                    encoded.position(info.offset);
                    encoded.limit(info.offset + info.size);
                    MediaCodec.BufferInfo adjusted = copyBufferInfo(info);
                    if (!videoOriginReady) {
                        // Surface timestamps can be device-clock based. Establish a local origin
                        // from the first encoded frame and use the same monotonic origin for AAC.
                        videoOriginPtsUs = info.presentationTimeUs;
                        sessionStartUs = System.nanoTime() / 1_000L;
                        videoOriginReady = true;
                    }
                    long relativePts = info.presentationTimeUs - videoOriginPtsUs - presentationTimeOffsetUs;
                    if (relativePts <= lastVideoPtsUs) relativePts = lastVideoPtsUs + 1;
                    lastVideoPtsUs = relativePts;
                    adjusted.presentationTimeUs = Math.max(0, relativePts);
                    try {
                        muxerCoordinator.writeSample(true, encoded, adjusted);
                    } catch (Exception e) {
                        Log.e(TAG, "Unable to mux video sample", e);
                    }
                }
                if ((info.flags & MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0) videoEos = true;
                videoEncoder.releaseOutputBuffer(outputIndex, false);
            }
        }
    }

    private void runAudioPipeline() {
        short[] internalPcm = new short[AUDIO_INPUT_SAMPLES];
        short[] microphonePcm = new short[AUDIO_INPUT_SAMPLES];
        short[] mixedPcm = new short[AUDIO_INPUT_SAMPLES];
        MediaCodec.BufferInfo outputInfo = new MediaCodec.BufferInfo();
        boolean inputEosQueued = false;

        // Keep capture-source startup aligned to the first encoded display frame.
        while (!videoOriginReady && !stopAudioThread) sleepQuietly(2);
        if (!stopAudioThread) restartAudioSourcesAtEpoch();
        long lastAudioInputNs = System.nanoTime();

        while (!stopAudioThread) {
            if (paused) {
                drainAudioEncoder(outputInfo);
                sleepQuietly(8);
                continue;
            }
            int internalCount = readAudio(playbackRecord, internalPcm);
            int microphoneCount = readAudio(microphoneRecord, microphonePcm);
            int samples = Math.max(internalCount, microphoneCount);
            if (samples > 0) {
                for (int i = 0; i < samples; i++) {
                    int a = i < internalCount ? internalPcm[i] : 0;
                    int b = i < microphoneCount ? microphonePcm[i] : 0;
                    int sum = a + b;
                    mixedPcm[i] = (short) Math.max(Short.MIN_VALUE, Math.min(Short.MAX_VALUE, sum));
                }
                queuePcm(mixedPcm, samples);
                lastAudioInputNs = System.nanoTime();
            } else {
                // Some devices return silence/no captured frames after source-policy changes.
                // Feed a small silent AAC block periodically so the audio track can initialize;
                // never let a dead/silent audio source stall the independent video muxer track.
                long nowNs = System.nanoTime();
                if (nowNs - lastAudioInputNs >= 20_000_000L) {
                    for (int i = 0; i < 1_024; i++) mixedPcm[i] = 0;
                    queuePcm(mixedPcm, 1_024);
                    lastAudioInputNs = nowNs;
                }
                sleepQuietly(5);
            }
            drainAudioEncoder(outputInfo);
        }

        // Flush AAC with an input EOS marker, then drain until the encoder emits output EOS.
        while (!inputEosQueued) {
            try {
                int inputIndex = audioEncoder.dequeueInputBuffer(1_000);
                if (inputIndex >= 0) {
                    long pts = Math.max(lastAudioPtsUs + 1, getSessionPresentationTimeUs());
                    audioEncoder.queueInputBuffer(inputIndex, 0, 0, pts, MediaCodec.BUFFER_FLAG_END_OF_STREAM);
                    inputEosQueued = true;
                }
            } catch (Exception e) {
                Log.e(TAG, "Unable to signal AAC end of stream", e);
                inputEosQueued = true;
            }
        }
        while (!audioEos) {
            drainAudioEncoder(outputInfo);
            sleepQuietly(4);
        }
    }

    private void restartAudioSourcesAtEpoch() {
        // Drop the short pre-roll accumulated while the VirtualDisplay was being created.
        // Both capture records restart against the same session epoch used by video timestamps.
        AudioRecord playback = playbackRecord;
        if (playback != null) {
            try {
                if (playback.getRecordingState() == AudioRecord.RECORDSTATE_RECORDING) playback.stop();
                playback.startRecording();
            } catch (Exception e) {
                Log.w(TAG, "Playback AudioRecord could not restart; disabling that source", e);
                releaseAudioRecord(playback);
                playbackRecord = null;
            }
        }
        AudioRecord microphone = microphoneRecord;
        if (microphone != null) {
            try {
                if (microphone.getRecordingState() == AudioRecord.RECORDSTATE_RECORDING) microphone.stop();
                microphone.startRecording();
            } catch (Exception e) {
                Log.w(TAG, "Microphone AudioRecord could not restart; disabling that source", e);
                releaseAudioRecord(microphone);
                microphoneRecord = null;
            }
        }
    }

    private int readAudio(AudioRecord record, short[] target) {
        if (record == null) return 0;
        try {
            int count = record.read(target, 0, target.length, AudioRecord.READ_NON_BLOCKING);
            return count > 0 ? Math.min(count, target.length) : 0;
        } catch (Exception e) {
            Log.w(TAG, "AudioRecord read failed", e);
            return 0;
        }
    }

    private void queuePcm(short[] samples, int count) {
        try {
            int inputIndex = audioEncoder.dequeueInputBuffer(10_000);
            if (inputIndex < 0) return;
            ByteBuffer input = audioEncoder.getInputBuffer(inputIndex);
            if (input == null) return;
            input.clear();
            input.order(ByteOrder.LITTLE_ENDIAN);
            int safeCount = Math.min(count, input.remaining() / 2);
            for (int i = 0; i < safeCount; i++) input.putShort(samples[i]);
            long nowPts = getSessionPresentationTimeUs();
            long frameDurationUs = (safeCount * 1_000_000L) / AUDIO_SAMPLE_RATE;
            long pts = Math.max(nowPts, lastAudioPtsUs + Math.max(1, frameDurationUs));
            if (lastAudioPtsUs < 0) pts = Math.max(0, nowPts);
            lastAudioPtsUs = pts;
            audioEncoder.queueInputBuffer(inputIndex, 0, safeCount * 2, pts, 0);
        } catch (Exception e) {
            Log.w(TAG, "AAC input failed; audio may be incomplete", e);
        }
    }

    private void drainAudioEncoder(MediaCodec.BufferInfo info) {
        if (audioEncoder == null || audioEos) return;
        try {
            int outputIndex = audioEncoder.dequeueOutputBuffer(info, 0);
            if (outputIndex == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) {
                muxerCoordinator.addTrack(false, audioEncoder.getOutputFormat());
            } else if (outputIndex >= 0) {
                ByteBuffer encoded = audioEncoder.getOutputBuffer(outputIndex);
                if (encoded != null && info.size > 0) {
                    encoded.position(info.offset);
                    encoded.limit(info.offset + info.size);
                    muxerCoordinator.writeSample(false, encoded, copyBufferInfo(info));
                }
                if ((info.flags & MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0) audioEos = true;
                audioEncoder.releaseOutputBuffer(outputIndex, false);
            }
        } catch (Exception e) {
            Log.e(TAG, "Audio encoder drain failed", e);
            if (stopAudioThread) audioEos = true;
        }
    }

    private long getSessionPresentationTimeUs() {
        long elapsed = (System.nanoTime() / 1_000L) - sessionStartUs - presentationTimeOffsetUs;
        return Math.max(0, elapsed);
    }

    private static MediaCodec.BufferInfo copyBufferInfo(MediaCodec.BufferInfo source) {
        MediaCodec.BufferInfo copy = new MediaCodec.BufferInfo();
        copy.set(source.offset, source.size, source.presentationTimeUs, source.flags);
        return copy;
    }

    private void togglePauseResume() {
        if (RecordingPreferences.STATE_RECORDING.equals(state)) pauseRecording();
        else if (RecordingPreferences.STATE_PAUSED.equals(state)) resumeRecording();
    }

    private void pauseRecording() {
        if (!RecordingPreferences.STATE_RECORDING.equals(state)) return;
        paused = true;
        pauseStartedAtUs = System.nanoTime() / 1_000L;
        try {
            Bundle params = new Bundle();
            params.putInt(MediaCodec.PARAMETER_KEY_SUSPEND, 1);
            videoEncoder.setParameters(params);
        } catch (Exception e) {
            Log.i(TAG, "Encoder suspend parameter unsupported; detaching VirtualDisplay surface instead.");
        }
        try { if (virtualDisplay != null) virtualDisplay.setSurface(null); } catch (Exception ignored) { }
        stopAudioRecordsForPause();
        state = RecordingPreferences.STATE_PAUSED;
        preferences.setServiceState(state);
        updateNotification();
        updateOverlayLabels();
        broadcastState();
    }

    private void resumeRecording() {
        if (!RecordingPreferences.STATE_PAUSED.equals(state)) return;
        long now = System.nanoTime() / 1_000L;
        if (pauseStartedAtUs > 0) presentationTimeOffsetUs += Math.max(0, now - pauseStartedAtUs);
        pauseStartedAtUs = 0;
        try {
            if (virtualDisplay != null) virtualDisplay.setSurface(videoInputSurface);
        } catch (Exception e) {
            Log.e(TAG, "Could not reattach display surface", e);
        }
        try {
            Bundle params = new Bundle();
            params.putInt(MediaCodec.PARAMETER_KEY_SUSPEND, 0);
            videoEncoder.setParameters(params);
        } catch (Exception e) {
            Log.i(TAG, "Encoder resume parameter unsupported; surface reattachment is used.");
        }
        startAudioRecordsAfterPause();
        paused = false;
        state = RecordingPreferences.STATE_RECORDING;
        preferences.setServiceState(state);
        updateNotification();
        updateOverlayLabels();
        broadcastState();
    }

    private void stopRecording(boolean projectionAlreadyStopped) {
        if (!stopping.compareAndSet(false, true)) return;
        Log.i(TAG, "Stopping recording; projectionAlreadyStopped=" + projectionAlreadyStopped);
        if (paused && pauseStartedAtUs > 0) {
            presentationTimeOffsetUs += Math.max(0, (System.nanoTime() / 1_000L) - pauseStartedAtUs);
            pauseStartedAtUs = 0;
        }

        // Keep the documented teardown order: virtual display, EOS, drain/join, encoders, muxer,
        // callback, projection. AudioRecord.stop() unblocks its non-blocking read loop.
        try { if (virtualDisplay != null) virtualDisplay.release(); } catch (Exception e) { Log.w(TAG, "VD release", e); }
        virtualDisplay = null;

        stopAudioThread = true;
        stopAndPauseAudioRecords();

        if (videoEncoder != null) {
            try { videoEncoder.signalEndOfInputStream(); } catch (Exception e) { Log.w(TAG, "Video EOS signal", e); }
        } else {
            videoEos = true;
        }

        joinThread(audioThread, 8_000);
        joinThread(videoDrainThread, 8_000);
        audioThread = null;
        videoDrainThread = null;

        stopAndReleaseAudioRecords();

        if (audioEncoder != null) {
            try { audioEncoder.stop(); } catch (Exception e) { Log.w(TAG, "AAC stop", e); }
            try { audioEncoder.release(); } catch (Exception e) { Log.w(TAG, "AAC release", e); }
            audioEncoder = null;
        }
        if (videoEncoder != null) {
            try { videoEncoder.stop(); } catch (Exception e) { Log.w(TAG, "AVC stop", e); }
            try { videoEncoder.release(); } catch (Exception e) { Log.w(TAG, "AVC release", e); }
            videoEncoder = null;
        }
        if (videoInputSurface != null) {
            try { videoInputSurface.release(); } catch (Exception ignored) { }
            videoInputSurface = null;
        }

        int videoSamples = muxerCoordinator == null ? 0 : muxerCoordinator.getVideoSampleCount();
        boolean muxerStoppedSuccessfully = false;
        if (muxerCoordinator != null) {
            muxerStoppedSuccessfully = muxerCoordinator.finish();
            muxerCoordinator = null;
        } else if (outputMuxer != null) {
            // The muxer may have been allocated before an encoder setup failure.
            try { outputMuxer.release(); } catch (Exception e) { Log.w(TAG, "Unstarted muxer release", e); }
        }
        outputMuxer = null;

        if (projection != null) {
            if (projectionCallback != null) {
                try { projection.unregisterCallback(projectionCallback); } catch (Exception ignored) { }
            }
            projectionCallback = null;
            if (!projectionAlreadyStopped) {
                try { projection.stop(); } catch (Exception e) { Log.w(TAG, "Projection stop", e); }
            }
            projection = null;
        }

        finalizeOutput(videoSamples > 0 && muxerStoppedSuccessfully);

        paused = false;
        state = RecordingPreferences.STATE_IDLE;
        preferences.setServiceState(state);
        updateOverlayLabels();
        broadcastState();

        if (foreground) {
            stopForeground(true);
            foreground = false;
        }
        stopping.set(false);

        if (!preferences.isOverlayEnabled()) {
            removeOverlay();
            stopSelf();
        } else {
            syncOverlay();
        }
    }

    private void finalizeOutput(boolean hadVideoSamples) {
        boolean valid = hadVideoSamples;
        if (Build.VERSION.SDK_INT >= 29 && outputUri != null) {
            try {
                if (valid && outputPfd != null && outputPfd.getStatSize() == 0) valid = false;
                if (valid) {
                    ContentValues values = new ContentValues();
                    values.put(MediaStore.Video.Media.IS_PENDING, 0);
                    int updatedRows = getContentResolver().update(outputUri, values, null, null);
                    if (updatedRows <= 0) throw new IOException("MediaStore did not publish the completed recording.");
                    preferences.saveLastRecording(outputUri.toString(), outputName, outputDisplayPath);
                } else {
                    getContentResolver().delete(outputUri, null, null);
                }
            } catch (Exception e) {
                Log.e(TAG, "Could not finalize MediaStore item", e);
                valid = false;
                try { getContentResolver().delete(outputUri, null, null); } catch (Exception ignored) { }
            }
        } else if (outputFile != null) {
            if (valid && outputFile.exists() && outputFile.length() > 0) {
                MediaScannerConnection.scanFile(this, new String[]{outputFile.getAbsolutePath()},
                        new String[]{"video/mp4"}, (path, uri) -> Log.i(TAG, "Media scan complete: " + uri));
                preferences.saveLastRecording(Uri.fromFile(outputFile).toString(), outputName, outputDisplayPath);
            } else {
                valid = false;
                if (outputFile.exists()) outputFile.delete();
            }
        }

        if (outputPfd != null) {
            try { outputPfd.close(); } catch (Exception ignored) { }
            outputPfd = null;
        }
        if (valid) {
            Log.i(TAG, "Recording saved: " + outputDisplayPath);
        } else {
            Log.w(TAG, "Recording produced no valid video samples; empty output removed.");
        }
        outputUri = null;
        outputFile = null;
        outputName = null;
        outputDisplayPath = null;
    }

    private void stopAndPauseAudioRecords() {
        try { if (playbackRecord != null && playbackRecord.getRecordingState() == AudioRecord.RECORDSTATE_RECORDING) playbackRecord.stop(); }
        catch (Exception ignored) { }
        try { if (microphoneRecord != null && microphoneRecord.getRecordingState() == AudioRecord.RECORDSTATE_RECORDING) microphoneRecord.stop(); }
        catch (Exception ignored) { }
    }

    private void stopAudioRecordsForPause() {
        stopAndPauseAudioRecords();
    }

    private void startAudioRecordsAfterPause() {
        try { if (playbackRecord != null) playbackRecord.startRecording(); } catch (Exception e) { Log.w(TAG, "Playback capture resume failed", e); }
        try { if (microphoneRecord != null) microphoneRecord.startRecording(); } catch (Exception e) { Log.w(TAG, "Microphone resume failed", e); }
    }

    private void stopAndReleaseAudioRecords() {
        stopAndPauseAudioRecords();
        releaseAudioRecord(playbackRecord);
        releaseAudioRecord(microphoneRecord);
        playbackRecord = null;
        microphoneRecord = null;
    }

    private static void releaseAudioRecord(AudioRecord record) {
        if (record == null) return;
        try { record.release(); } catch (Exception ignored) { }
    }

    private static void joinThread(Thread thread, long millis) {
        if (thread == null || thread == Thread.currentThread()) return;
        try { thread.join(millis); } catch (InterruptedException e) { Thread.currentThread().interrupt(); }
        if (thread.isAlive()) Log.w(TAG, "Encoder worker did not exit within " + millis + "ms.");
    }

    private static void sleepQuietly(long millis) {
        try { Thread.sleep(millis); } catch (InterruptedException e) { Thread.currentThread().interrupt(); }
    }

    private void syncOverlay() {
        boolean enabled = preferences.isOverlayEnabled();
        boolean permission = Build.VERSION.SDK_INT < Build.VERSION_CODES.M || Settings.canDrawOverlays(this);
        if (enabled && permission) showOverlay();
        else {
            if (enabled && !permission) preferences.setOverlayEnabled(false);
            removeOverlay();
        }
    }

    private void showOverlay() {
        if (bubbleView != null || windowManager == null) return;
        try {
            bubbleView = LayoutInflater.from(this).inflate(R.layout.floating_bubble, null, false);
            bubbleParams = buildOverlayParams(WindowManager.LayoutParams.WRAP_CONTENT,
                    WindowManager.LayoutParams.WRAP_CONTENT);
            bubbleParams.gravity = Gravity.TOP | Gravity.START;
            bubbleParams.x = bubbleX;
            bubbleParams.y = bubbleY;
            bubbleView.setOnTouchListener(new View.OnTouchListener() {
                private float downRawX;
                private float downRawY;
                private int startX;
                private int startY;
                private boolean dragged;

                @Override
                public boolean onTouch(View view, MotionEvent event) {
                    switch (event.getAction()) {
                        case MotionEvent.ACTION_DOWN:
                            downRawX = event.getRawX();
                            downRawY = event.getRawY();
                            startX = bubbleParams.x;
                            startY = bubbleParams.y;
                            dragged = false;
                            return true;
                        case MotionEvent.ACTION_MOVE:
                            int dx = (int) (event.getRawX() - downRawX);
                            int dy = (int) (event.getRawY() - downRawY);
                            if (Math.abs(dx) + Math.abs(dy) > 8) dragged = true;
                            if (dragged) {
                                bubbleParams.x = Math.max(0, startX + dx);
                                bubbleParams.y = Math.max(0, startY + dy);
                                bubbleX = bubbleParams.x;
                                bubbleY = bubbleParams.y;
                                try { windowManager.updateViewLayout(bubbleView, bubbleParams); } catch (Exception ignored) { }
                            }
                            return true;
                        case MotionEvent.ACTION_UP:
                            if (!dragged) toggleControlsPanel();
                            return true;
                        default:
                            return true;
                    }
                }
            });
            windowManager.addView(bubbleView, bubbleParams);
        } catch (Exception e) {
            Log.e(TAG, "Floating bubble could not be displayed", e);
            preferences.setOverlayEnabled(false);
            removeOverlay();
        }
    }

    private WindowManager.LayoutParams buildOverlayParams(int width, int height) {
        int type = Build.VERSION.SDK_INT >= 26
                ? WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
                : WindowManager.LayoutParams.TYPE_PHONE;
        return new WindowManager.LayoutParams(width, height, type,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
                PixelFormat.TRANSLUCENT);
    }

    private void toggleControlsPanel() {
        if (controlsView != null) {
            removeControlsPanel();
            return;
        }
        if (bubbleView == null) return;
        try {
            controlsView = LayoutInflater.from(this).inflate(R.layout.floating_controls, null, false);
            controlsParams = buildOverlayParams(WindowManager.LayoutParams.WRAP_CONTENT,
                    WindowManager.LayoutParams.WRAP_CONTENT);
            controlsParams.gravity = Gravity.TOP | Gravity.START;
            controlsParams.x = Math.max(0, bubbleX - dp(150));
            controlsParams.y = bubbleY + dp(64);
            Button newButton = controlsView.findViewById(R.id.overlayNewButton);
            Button pauseButton = controlsView.findViewById(R.id.overlayPauseButton);
            Button stopButton = controlsView.findViewById(R.id.overlayStopButton);
            newButton.setOnClickListener(v -> {
                removeControlsPanel();
                // A projection is single-session: finish an existing capture before asking again.
                if (RecordingPreferences.STATE_RECORDING.equals(state)
                        || RecordingPreferences.STATE_PAUSED.equals(state)) {
                    stopRecording(false);
                }
                Intent intent = new Intent(this, MainActivity.class)
                        .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP)
                        .putExtra(EXTRA_AUTO_START, true);
                startActivity(intent);
            });
            pauseButton.setOnClickListener(v -> togglePauseResume());
            stopButton.setOnClickListener(v -> stopRecording(false));
            windowManager.addView(controlsView, controlsParams);
            updateOverlayLabels();
        } catch (Exception e) {
            Log.e(TAG, "Floating controls panel could not be displayed", e);
            removeControlsPanel();
        }
    }

    private void updateOverlayLabels() {
        if (controlsView != null) {
            Button pauseButton = controlsView.findViewById(R.id.overlayPauseButton);
            if (pauseButton != null) {
                pauseButton.setText(RecordingPreferences.STATE_PAUSED.equals(state) ? "استئناف" : "إيقاف مؤقت");
                pauseButton.setEnabled(RecordingPreferences.STATE_RECORDING.equals(state)
                        || RecordingPreferences.STATE_PAUSED.equals(state));
            }
            Button stopButton = controlsView.findViewById(R.id.overlayStopButton);
            if (stopButton != null) stopButton.setEnabled(RecordingPreferences.STATE_RECORDING.equals(state)
                    || RecordingPreferences.STATE_PAUSED.equals(state));
        }
        if (bubbleView != null) {
            TextView text = bubbleView.findViewById(R.id.bubbleText);
            if (text != null) text.setText(RecordingPreferences.STATE_RECORDING.equals(state) ? "REC"
                    : RecordingPreferences.STATE_PAUSED.equals(state) ? "PAUSE" : "LSR");
        }
    }

    private void removeControlsPanel() {
        if (controlsView != null && windowManager != null) {
            try { windowManager.removeView(controlsView); } catch (Exception ignored) { }
        }
        controlsView = null;
        controlsParams = null;
    }

    private void removeOverlay() {
        removeControlsPanel();
        if (bubbleView != null && windowManager != null) {
            try { windowManager.removeView(bubbleView); } catch (Exception ignored) { }
        }
        bubbleView = null;
        bubbleParams = null;
    }

    private int dp(int value) {
        return Math.round(value * getResources().getDisplayMetrics().density);
    }

    private void broadcastState() {
        Intent intent = new Intent(ACTION_STATE_CHANGED)
                .setPackage(getPackageName())
                .putExtra(EXTRA_STATE, state)
                .putExtra(EXTRA_SAVED_NAME, preferences.getLastRecordingName())
                .putExtra(EXTRA_SAVED_URI, preferences.getLastRecordingUri());
        sendBroadcast(intent);
    }

    private void notifyFailure(String message) {
        Log.e(TAG, message);
        mainHandler.post(() -> android.widget.Toast.makeText(getApplicationContext(), message,
                android.widget.Toast.LENGTH_LONG).show());
    }

    private void createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel channel = new NotificationChannel(NOTIFICATION_CHANNEL,
                    "Screen recording", NotificationManager.IMPORTANCE_LOW);
            channel.setDescription("Status notification while screen recording is active.");
            NotificationManager manager = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
            if (manager != null) manager.createNotificationChannel(channel);
        }
    }

    private Notification buildNotification() {
        Intent activityIntent = new Intent(this, MainActivity.class)
                .addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        PendingIntent pendingIntent = PendingIntent.getActivity(this, 10, activityIntent,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        return new NotificationCompat.Builder(this, NOTIFICATION_CHANNEL)
                .setSmallIcon(android.R.drawable.ic_menu_camera)
                .setContentTitle(getString(R.string.recording_notification_title))
                .setContentText(getString(R.string.recording_notification_text))
                .setContentIntent(pendingIntent)
                .setOngoing(true)
                .setOnlyAlertOnce(true)
                .setCategory(NotificationCompat.CATEGORY_SERVICE)
                .setPriority(NotificationCompat.PRIORITY_LOW)
                .build();
    }

    private void updateNotification() {
        if (!foreground) return;
        NotificationManager manager = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
        if (manager != null) manager.notify(NOTIFICATION_ID, buildNotification());
    }

    @Override
    public void onTaskRemoved(Intent rootIntent) {
        super.onTaskRemoved(rootIntent);
        // Do not stop capture: the foreground service is intentionally independent of the activity.
    }

    @Override
    public void onDestroy() {
        if (RecordingPreferences.STATE_RECORDING.equals(state) || RecordingPreferences.STATE_PAUSED.equals(state)) {
            stopRecording(false);
        }
        removeOverlay();
        super.onDestroy();
    }

    /**
     * Synchronized muxer gate: MediaMuxer.start() occurs exactly once after all expected output
     * formats have registered. Encoder threads may safely wait for the other track's format.
     */
    private static final class MuxerCoordinator {
        private final MediaMuxer muxer;
        private final int expectedTracks;
        private int videoTrack = -1;
        private int audioTrack = -1;
        private int tracksAdded;
        private boolean started;
        private boolean finished;
        private int videoSampleCount;

        MuxerCoordinator(MediaMuxer muxer, int expectedTracks) {
            this.muxer = muxer;
            this.expectedTracks = expectedTracks;
        }

        synchronized void addTrack(boolean video, MediaFormat format) throws IOException {
            if (finished || started) return;
            if (video && videoTrack >= 0) return;
            if (!video && audioTrack >= 0) return;
            try {
                int index = muxer.addTrack(format);
                if (video) videoTrack = index;
                else audioTrack = index;
                tracksAdded++;
                if (tracksAdded == expectedTracks) {
                    muxer.start();
                    started = true;
                    notifyAll();
                }
            } catch (Exception e) {
                throw new IOException("MediaMuxer could not add/start its tracks", e);
            }
        }

        synchronized void writeSample(boolean video, ByteBuffer data, MediaCodec.BufferInfo info) throws IOException {
            long deadline = System.currentTimeMillis() + 2_000L;
            while (!started && !finished && System.currentTimeMillis() < deadline) {
                try { wait(40L); } catch (InterruptedException e) { Thread.currentThread().interrupt(); break; }
            }
            if (!started || finished || info.size <= 0) return;
            int track = video ? videoTrack : audioTrack;
            if (track < 0) return;
            try {
                muxer.writeSampleData(track, data, info);
                if (video) videoSampleCount++;
            } catch (Exception e) {
                throw new IOException("MediaMuxer sample write failed", e);
            }
        }

        synchronized int getVideoSampleCount() {
            return videoSampleCount;
        }

        synchronized boolean finish() {
            if (finished) return false;
            finished = true;
            notifyAll();
            if (started) {
                boolean stopSucceeded = false;
                try {
                    muxer.stop();
                    stopSucceeded = true;
                } catch (Exception e) {
                    Log.w(TAG, "Muxer stop failed; output will be discarded", e);
                } finally {
                    try { muxer.release(); } catch (Exception e) { Log.w(TAG, "Muxer release", e); }
                }
                return stopSucceeded;
            } else {
                // No stop() before start(); release still frees the native muxer allocation.
                try { muxer.release(); } catch (Exception e) { Log.w(TAG, "Unstarted muxer release", e); }
                return false;
            }
        }
    }
}
