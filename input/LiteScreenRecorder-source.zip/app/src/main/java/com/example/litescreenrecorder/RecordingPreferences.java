package com.example.litescreenrecorder;

import android.app.ActivityManager;
import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Point;
import android.os.Build;
import android.view.Display;
import android.view.WindowManager;

/**
 * Small, typed SharedPreferences facade. Every setter commits asynchronously with apply();
 * Android persists the change immediately to its in-process preference cache and disk shortly after.
 */
public final class RecordingPreferences {
    public static final String QUALITY_480 = "480p";
    public static final String QUALITY_720 = "720p";
    public static final String QUALITY_1080 = "1080p";

    public static final String AUDIO_INTERNAL_ONLY = "internal_only";
    public static final String AUDIO_INTERNAL_AND_MIC = "internal_and_mic";

    public static final String STATE_IDLE = "Idle";
    public static final String STATE_RECORDING = "Recording";
    public static final String STATE_PAUSED = "Paused";

    private static final String PREFS = "lite_screen_recorder";
    private static final String KEY_QUALITY = "quality";
    private static final String KEY_FPS = "fps";
    private static final String KEY_AUDIO = "audio_mode";
    private static final String KEY_OVERLAY = "overlay_enabled";
    private static final String KEY_STATE = "service_state";
    private static final String KEY_LAST_URI = "last_saved_uri";
    private static final String KEY_LAST_NAME = "last_saved_name";
    private static final String KEY_LAST_PATH = "last_saved_path";

    private final SharedPreferences preferences;

    public RecordingPreferences(Context context) {
        preferences = context.getApplicationContext().getSharedPreferences(PREFS, Context.MODE_PRIVATE);
    }

    public String getQuality() {
        return preferences.getString(KEY_QUALITY, QUALITY_480);
    }

    public void setQuality(String quality) {
        if (!QUALITY_480.equals(quality) && !QUALITY_720.equals(quality) && !QUALITY_1080.equals(quality)) {
            quality = QUALITY_480;
        }
        preferences.edit().putString(KEY_QUALITY, quality).apply();
    }

    public int getFrameRate() {
        int value = preferences.getInt(KEY_FPS, 30);
        return value == 60 || value == 90 ? value : 30;
    }

    public void setFrameRate(int fps) {
        if (fps != 30 && fps != 60 && fps != 90) fps = 30;
        preferences.edit().putInt(KEY_FPS, fps).apply();
    }

    public String getAudioMode() {
        return preferences.getString(KEY_AUDIO, AUDIO_INTERNAL_ONLY);
    }

    public void setAudioMode(String mode) {
        if (!AUDIO_INTERNAL_AND_MIC.equals(mode)) mode = AUDIO_INTERNAL_ONLY;
        preferences.edit().putString(KEY_AUDIO, mode).apply();
    }

    public boolean isOverlayEnabled() {
        return preferences.getBoolean(KEY_OVERLAY, false);
    }

    public void setOverlayEnabled(boolean enabled) {
        preferences.edit().putBoolean(KEY_OVERLAY, enabled).apply();
    }

    public String getServiceState() {
        return preferences.getString(KEY_STATE, STATE_IDLE);
    }

    public void setServiceState(String state) {
        if (!STATE_RECORDING.equals(state) && !STATE_PAUSED.equals(state)) state = STATE_IDLE;
        preferences.edit().putString(KEY_STATE, state).apply();
    }

    public void saveLastRecording(String uri, String displayName, String path) {
        preferences.edit()
                .putString(KEY_LAST_URI, uri == null ? "" : uri)
                .putString(KEY_LAST_NAME, displayName == null ? "" : displayName)
                .putString(KEY_LAST_PATH, path == null ? "" : path)
                .apply();
    }

    public String getLastRecordingUri() {
        return preferences.getString(KEY_LAST_URI, "");
    }

    public String getLastRecordingName() {
        return preferences.getString(KEY_LAST_NAME, "");
    }

    public String getLastRecordingPath() {
        return preferences.getString(KEY_LAST_PATH, "");
    }

    /**
     * Returns encoder dimensions with the shorter side exactly equal to the selected preset
     * (apart from an impossible parity adjustment of at most one pixel), preserving display AR.
     */
    public static Point calculateVideoSize(Context context, String quality) {
        int targetShortSide;
        if (QUALITY_1080.equals(quality)) targetShortSide = 1080;
        else if (QUALITY_720.equals(quality)) targetShortSide = 720;
        else targetShortSide = 480;

        Point displaySize = getDisplaySize(context);
        int shortDisplay = Math.max(1, Math.min(displaySize.x, displaySize.y));
        int longDisplay = Math.max(shortDisplay, Math.max(displaySize.x, displaySize.y));
        int longSide = Math.round(targetShortSide * (longDisplay / (float) shortDisplay));

        int width;
        int height;
        if (displaySize.x >= displaySize.y) {
            width = longSide;
            height = targetShortSide;
        } else {
            width = targetShortSide;
            height = longSide;
        }
        width = makeEven(width);
        height = makeEven(height);
        return new Point(width, height);
    }

    public static Point getDisplaySize(Context context) {
        WindowManager manager = (WindowManager) context.getSystemService(Context.WINDOW_SERVICE);
        Point result = new Point(720, 1280);
        if (manager == null) return result;
        Display display = manager.getDefaultDisplay();
        if (display != null) {
            display.getRealSize(result);
        }
        if (result.x <= 0 || result.y <= 0) return new Point(720, 1280);
        return result;
    }

    public static int makeEven(int value) {
        int positive = Math.max(2, value);
        return (positive & 1) == 0 ? positive : positive - 1;
    }

    /**
     * Device-aware guard. The requested preset is preserved in preferences; only the effective
     * encoder hint is reduced when the selected resolution/device/display cannot reasonably do it.
     */
    public static int getEffectiveFrameRate(Context context, String quality, int requestedFps) {
        int fps = requestedFps == 60 || requestedFps == 90 ? requestedFps : 30;
        if (QUALITY_1080.equals(quality) && fps > 60) fps = 60;

        ActivityManager activityManager = (ActivityManager) context.getSystemService(Context.ACTIVITY_SERVICE);
        boolean lowRam = activityManager != null && activityManager.isLowRamDevice();
        if (lowRam && QUALITY_1080.equals(quality) && fps > 30) fps = 30;

        WindowManager manager = (WindowManager) context.getSystemService(Context.WINDOW_SERVICE);
        if (manager != null && manager.getDefaultDisplay() != null) {
            float refreshRate = manager.getDefaultDisplay().getRefreshRate();
            if (refreshRate > 1f) fps = Math.min(fps, Math.max(30, Math.round(refreshRate)));
        }
        return fps;
    }

    /** Resolution- and frame-rate-scaled H.264 bitrate, with conservative bounds for mobile devices. */
    public static int calculateVideoBitrate(Point size, int fps) {
        double pixels = (double) size.x * (double) size.y;
        double bitsPerSecond = pixels * Math.max(15, fps) * 0.20d;
        return (int) Math.max(1_500_000d, Math.min(24_000_000d, bitsPerSecond));
    }
}
