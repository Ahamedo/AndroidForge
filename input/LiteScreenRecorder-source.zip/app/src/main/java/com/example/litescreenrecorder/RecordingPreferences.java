package com.example.litescreenrecorder;

import android.app.ActivityManager;
import android.content.Context;
import android.content.SharedPreferences;
import android.content.res.Configuration;
import android.os.Build;
import android.util.DisplayMetrics;
import android.view.WindowManager;

/** Small, synchronous SharedPreferences wrapper for recorder settings and live UI state. */
public final class RecordingPreferences {
    private static final String PREFS = "lite_screen_recorder";
    private static final String KEY_QUALITY = "quality";
    private static final String KEY_FPS = "fps";
    private static final String KEY_AUDIO_MODE = "audio_mode";
    private static final String KEY_OVERLAY = "overlay_enabled";
    private static final String KEY_STATE = "recorder_state";
    private static final String KEY_LAST_URI = "last_uri";
    private static final String KEY_LAST_LABEL = "last_label";
    private static final String KEY_LAST_PATH = "last_path";

    public static final String QUALITY_480 = "480p";
    public static final String QUALITY_720 = "720p";
    public static final String QUALITY_1080 = "1080p";
    public static final String AUDIO_INTERNAL_ONLY = "internal_only";
    public static final String AUDIO_INTERNAL_AND_MIC = "internal_and_mic";
    public static final String STATE_IDLE = "Idle";
    public static final String STATE_RECORDING = "Recording";
    public static final String STATE_PAUSED = "Paused";

    private final SharedPreferences preferences;

    public RecordingPreferences(Context context) {
        preferences = context.getApplicationContext()
                .getSharedPreferences(PREFS, Context.MODE_PRIVATE);
    }

    public String getQuality() {
        return preferences.getString(KEY_QUALITY, QUALITY_720);
    }

    public void setQuality(String quality) {
        String safe = QUALITY_480.equals(quality) || QUALITY_1080.equals(quality)
                ? quality : QUALITY_720;
        preferences.edit().putString(KEY_QUALITY, safe).commit();
    }

    public int getFps() {
        int fps = preferences.getInt(KEY_FPS, 30);
        return fps == 60 || fps == 90 ? fps : 30;
    }

    public void setFps(int fps) {
        int safe = fps == 60 || fps == 90 ? fps : 30;
        preferences.edit().putInt(KEY_FPS, safe).commit();
    }

    public String getAudioMode() {
        String mode = preferences.getString(KEY_AUDIO_MODE, AUDIO_INTERNAL_ONLY);
        return AUDIO_INTERNAL_AND_MIC.equals(mode) ? AUDIO_INTERNAL_AND_MIC : AUDIO_INTERNAL_ONLY;
    }

    public void setAudioMode(String mode) {
        String safe = AUDIO_INTERNAL_AND_MIC.equals(mode)
                ? AUDIO_INTERNAL_AND_MIC : AUDIO_INTERNAL_ONLY;
        preferences.edit().putString(KEY_AUDIO_MODE, safe).commit();
    }

    public boolean isOverlayEnabled() {
        return preferences.getBoolean(KEY_OVERLAY, false);
    }

    public void setOverlayEnabled(boolean enabled) {
        preferences.edit().putBoolean(KEY_OVERLAY, enabled).commit();
    }

    public String getRecorderState() {
        String value = preferences.getString(KEY_STATE, STATE_IDLE);
        if (STATE_RECORDING.equals(value) || STATE_PAUSED.equals(value)) return value;
        return STATE_IDLE;
    }

    public void setRecorderState(String state) {
        String safe = STATE_RECORDING.equals(state) || STATE_PAUSED.equals(state)
                ? state : STATE_IDLE;
        preferences.edit().putString(KEY_STATE, safe).commit();
    }

    public void setLastRecording(String uri, String label, String path) {
        preferences.edit()
                .putString(KEY_LAST_URI, uri == null ? "" : uri)
                .putString(KEY_LAST_LABEL, label == null ? "" : label)
                .putString(KEY_LAST_PATH, path == null ? "" : path)
                .commit();
    }

    public String getLastRecordingUri() { return preferences.getString(KEY_LAST_URI, ""); }
    public String getLastRecordingLabel() { return preferences.getString(KEY_LAST_LABEL, ""); }
    public String getLastRecordingPath() { return preferences.getString(KEY_LAST_PATH, ""); }

    public static final class CaptureSpec {
        public final int width;
        public final int height;
        public final int fps;
        public final int bitrate;
        public final String requestedQuality;
        public final boolean constrainedFallback;

        CaptureSpec(int width, int height, int fps, int bitrate,
                    String requestedQuality, boolean constrainedFallback) {
            this.width = width;
            this.height = height;
            this.fps = fps;
            this.bitrate = bitrate;
            this.requestedQuality = requestedQuality;
            this.constrainedFallback = constrainedFallback;
        }
    }

    /**
     * The short display edge becomes the requested preset height; the long edge is
     * scaled from the current physical display aspect ratio. Every encoder edge is even.
     */
    public CaptureSpec makeCaptureSpec(Context context) {
        WindowManager wm = (WindowManager) context.getSystemService(Context.WINDOW_SERVICE);
        DisplayMetrics metrics = new DisplayMetrics();
        if (wm != null && wm.getDefaultDisplay() != null) {
            wm.getDefaultDisplay().getRealMetrics(metrics);
        } else {
            metrics.widthPixels = 720;
            metrics.heightPixels = 1280;
        }

        int shortEdge = Math.max(2, Math.min(metrics.widthPixels, metrics.heightPixels));
        int longEdge = Math.max(shortEdge, Math.max(metrics.widthPixels, metrics.heightPixels));
        float aspect = (float) longEdge / (float) shortEdge;
        boolean landscape = context.getResources().getConfiguration().orientation
                == Configuration.ORIENTATION_LANDSCAPE;

        String requested = getQuality();
        int targetShort = QUALITY_480.equals(requested) ? 480
                : (QUALITY_1080.equals(requested) ? 1080 : 720);
        int fps = getFps();
        boolean lowEnd = isConstrainedDevice(context);
        boolean fallback = false;

        // Avoid the especially expensive 1080p/90 combination on low-memory/low-core devices.
        if (lowEnd && targetShort >= 1080 && fps > 60) {
            targetShort = 720;
            fps = 60;
            fallback = true;
        }
        int scaledLong = evenRound(targetShort * aspect);
        int width = landscape ? scaledLong : evenRound(targetShort);
        int height = landscape ? evenRound(targetShort) : scaledLong;
        width = Math.max(2, width);
        height = Math.max(2, height);

        double pixelScale = ((double) width * (double) height) / (854.0 * 480.0);
        double fpsScale = fps / 30.0;
        int bitrate = (int) Math.round(2_500_000.0 * pixelScale * fpsScale);
        bitrate = Math.max(1_000_000, Math.min(bitrate, lowEnd ? 8_000_000 : 24_000_000));
        return new CaptureSpec(width, height, fps, bitrate, requested, fallback);
    }

    private static int evenRound(float value) {
        int rounded = Math.round(value);
        if ((rounded & 1) != 0) rounded++;
        return rounded;
    }

    public static boolean isConstrainedDevice(Context context) {
        ActivityManager am = (ActivityManager) context.getSystemService(Context.ACTIVITY_SERVICE);
        boolean lowRam = am != null && Build.VERSION.SDK_INT >= 19 && am.isLowRamDevice();
        int cores = Runtime.getRuntime().availableProcessors();
        long totalRam = 0L;
        if (am != null) {
            ActivityManager.MemoryInfo info = new ActivityManager.MemoryInfo();
            am.getMemoryInfo(info);
            totalRam = info.totalMem;
        }
        return lowRam || cores <= 4 || (totalRam > 0 && totalRam < 3L * 1024L * 1024L * 1024L);
    }
}
