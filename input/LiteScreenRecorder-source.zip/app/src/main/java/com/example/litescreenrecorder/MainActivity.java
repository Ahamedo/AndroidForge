package com.example.litescreenrecorder;

import android.Manifest;
import android.app.Activity;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.PackageManager;
import android.media.projection.MediaProjectionManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.view.View;
import android.widget.Button;
import android.widget.Spinner;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

import androidx.core.content.ContextCompat;

/** Main settings / consent screen. Capture itself always runs inside ScreenRecordService. */
public class MainActivity extends Activity {
    private static final int REQUEST_CAPTURE = 4101;
    private static final int REQUEST_AUDIO = 4102;
    private static final int REQUEST_NOTIFICATIONS = 4103;
    private static final int REQUEST_STORAGE = 4104;
    private static final int REQUEST_OVERLAY = 4105;

    private RecordingPreferences preferences;
    private Spinner qualitySpinner;
    private Spinner fpsSpinner;
    private Spinner audioSpinner;
    private Switch overlaySwitch;
    private Button startButton;
    private Button pauseButton;
    private Button stopButton;
    private TextView statusText;
    private TextView lastSavedText;

    private boolean receiverRegistered;
    private boolean pendingStart;
    private boolean audioPermissionSkipped;
    private boolean storagePermissionSkipped;
    private boolean pendingOverlayEnable;
    private String currentState = RecordingPreferences.STATE_IDLE;

    private final BroadcastReceiver stateReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            if (intent == null || !ScreenRecordService.ACTION_STATE_CHANGED.equals(intent.getAction())) return;
            String state = intent.getStringExtra(ScreenRecordService.EXTRA_STATE);
            if (state != null) currentState = state;
            updateUiState();
            updateLastSavedText();
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        preferences = new RecordingPreferences(this);
        bindViews();
        restoreSettings();
        wireControls();

        if (getIntent() != null && getIntent().getBooleanExtra(ScreenRecordService.EXTRA_AUTO_START, false)) {
            pendingStart = true;
        }
    }

    private void bindViews() {
        qualitySpinner = findViewById(R.id.qualitySpinner);
        fpsSpinner = findViewById(R.id.fpsSpinner);
        audioSpinner = findViewById(R.id.audioSpinner);
        overlaySwitch = findViewById(R.id.overlaySwitch);
        startButton = findViewById(R.id.startButton);
        pauseButton = findViewById(R.id.pauseButton);
        stopButton = findViewById(R.id.stopButton);
        statusText = findViewById(R.id.statusText);
        lastSavedText = findViewById(R.id.lastSavedText);
    }

    private void restoreSettings() {
        String quality = preferences.getQuality();
        qualitySpinner.setSelection(RecordingPreferences.QUALITY_720.equals(quality) ? 1
                : RecordingPreferences.QUALITY_1080.equals(quality) ? 2 : 0);
        int fps = preferences.getFrameRate();
        fpsSpinner.setSelection(fps == 60 ? 1 : fps == 90 ? 2 : 0);
        audioSpinner.setSelection(RecordingPreferences.AUDIO_INTERNAL_AND_MIC.equals(preferences.getAudioMode()) ? 1 : 0);
        updateLastSavedText();
        updateUiState();
    }

    private void wireControls() {
        qualitySpinner.setOnItemSelectedListener(new SimpleItemSelectedListener(position -> {
            String[] values = {RecordingPreferences.QUALITY_480, RecordingPreferences.QUALITY_720,
                    RecordingPreferences.QUALITY_1080};
            preferences.setQuality(values[position]);
        }));
        fpsSpinner.setOnItemSelectedListener(new SimpleItemSelectedListener(position -> {
            int[] values = {30, 60, 90};
            preferences.setFrameRate(values[position]);
        }));
        audioSpinner.setOnItemSelectedListener(new SimpleItemSelectedListener(position -> {
            preferences.setAudioMode(position == 1 ? RecordingPreferences.AUDIO_INTERNAL_AND_MIC
                    : RecordingPreferences.AUDIO_INTERNAL_ONLY);
        }));

        overlaySwitch.setOnCheckedChangeListener((buttonView, checked) -> {
            if (checked && Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && !Settings.canDrawOverlays(this)) {
                pendingOverlayEnable = true;
                overlaySwitch.setChecked(false);
                Toast.makeText(this, R.string.overlay_permission_message, Toast.LENGTH_LONG).show();
                Intent intent = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                        Uri.parse("package:" + getPackageName()));
                startActivityForResult(intent, REQUEST_OVERLAY);
                return;
            }
            preferences.setOverlayEnabled(checked);
            syncOverlayService();
        });

        startButton.setOnClickListener(v -> beginStartFlow());
        pauseButton.setOnClickListener(v -> sendServiceCommand(ScreenRecordService.ACTION_PAUSE_TOGGLE));
        stopButton.setOnClickListener(v -> sendServiceCommand(ScreenRecordService.ACTION_STOP));
    }

    private void beginStartFlow() {
        if (!pendingStart) {
            pendingStart = true;
            audioPermissionSkipped = false;
            storagePermissionSkipped = false;
        }
        if (Build.VERSION.SDK_INT >= 33 &&
                ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, REQUEST_NOTIFICATIONS);
            return;
        }
        // Required in both audio modes: AudioPlaybackCapture also requires RECORD_AUDIO.
        if (!audioPermissionSkipped && ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO)
                != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO}, REQUEST_AUDIO);
            return;
        }
        if (!storagePermissionSkipped && Build.VERSION.SDK_INT <= 28 &&
                ContextCompat.checkSelfPermission(this, Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE}, REQUEST_STORAGE);
            return;
        }
        pendingStart = false;
        audioPermissionSkipped = false;
        storagePermissionSkipped = false;
        requestScreenCaptureConsent();
    }

    private void requestScreenCaptureConsent() {
        MediaProjectionManager manager = (MediaProjectionManager) getSystemService(Context.MEDIA_PROJECTION_SERVICE);
        if (manager == null) {
            Toast.makeText(this, "Screen capture is unavailable on this device.", Toast.LENGTH_LONG).show();
            return;
        }
        // A new consent Intent is created for every session; it is never cached or reused.
        startActivityForResult(manager.createScreenCaptureIntent(), REQUEST_CAPTURE);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQUEST_CAPTURE) {
            if (resultCode == RESULT_OK && data != null) {
                Intent service = new Intent(this, ScreenRecordService.class)
                        .setAction(ScreenRecordService.ACTION_START)
                        .putExtra(ScreenRecordService.EXTRA_RESULT_CODE, resultCode)
                        .putExtra(ScreenRecordService.EXTRA_RESULT_DATA, data);
                try {
                    ContextCompat.startForegroundService(this, service);
                } catch (RuntimeException e) {
                    Toast.makeText(this, "Android did not allow the recording service to start: " + e.getMessage(),
                            Toast.LENGTH_LONG).show();
                }
            } else {
                Toast.makeText(this, "Screen recording permission was not granted.", Toast.LENGTH_SHORT).show();
            }
        } else if (requestCode == REQUEST_OVERLAY) {
            boolean granted = Build.VERSION.SDK_INT < Build.VERSION_CODES.M || Settings.canDrawOverlays(this);
            pendingOverlayEnable = false;
            preferences.setOverlayEnabled(granted);
            overlaySwitch.setOnCheckedChangeListener(null);
            overlaySwitch.setChecked(granted);
            overlaySwitch.setOnCheckedChangeListener((buttonView, checked) -> onOverlaySwitchChanged(checked));
            syncOverlayService();
            if (!granted) Toast.makeText(this, "Overlay permission was not granted.", Toast.LENGTH_SHORT).show();
        }
    }

    private void onOverlaySwitchChanged(boolean checked) {
        if (checked && Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && !Settings.canDrawOverlays(this)) {
            pendingOverlayEnable = true;
            overlaySwitch.setOnCheckedChangeListener(null);
            overlaySwitch.setChecked(false);
            overlaySwitch.setOnCheckedChangeListener((buttonView, value) -> onOverlaySwitchChanged(value));
            startActivityForResult(new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                    Uri.parse("package:" + getPackageName())), REQUEST_OVERLAY);
            return;
        }
        preferences.setOverlayEnabled(checked);
        syncOverlayService();
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        boolean granted = grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED;
        if (requestCode == REQUEST_AUDIO && pendingStart) {
            if (!granted) {
                // Still allow video-only capture; internal playback and microphone audio remain disabled.
                audioPermissionSkipped = true;
                Toast.makeText(this, "Audio permission denied. The screen can still be recorded without audio.",
                        Toast.LENGTH_LONG).show();
            }
            beginStartFlow();
        } else if (requestCode == REQUEST_STORAGE && pendingStart) {
            if (!granted) {
                // The service falls back to the app-specific Movies directory on legacy Android.
                storagePermissionSkipped = true;
                Toast.makeText(this, "Storage permission denied. Saving to app-specific Movies storage.",
                        Toast.LENGTH_LONG).show();
            }
            beginStartFlow();
        } else if (requestCode == REQUEST_NOTIFICATIONS) {
            if (granted && pendingStart) beginStartFlow();
            else if (!granted) {
                pendingStart = false;
                Toast.makeText(this, "Notification permission is required to start recording.", Toast.LENGTH_LONG).show();
            }
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (!receiverRegistered) {
            IntentFilter filter = new IntentFilter(ScreenRecordService.ACTION_STATE_CHANGED);
            ContextCompat.registerReceiver(this, stateReceiver, filter, ContextCompat.RECEIVER_NOT_EXPORTED);
            receiverRegistered = true;
        }
        boolean overlayAllowed = Build.VERSION.SDK_INT < Build.VERSION_CODES.M || Settings.canDrawOverlays(this);
        boolean overlayEnabled = preferences.isOverlayEnabled() && overlayAllowed;
        if (!overlayAllowed && preferences.isOverlayEnabled()) preferences.setOverlayEnabled(false);
        overlaySwitch.setOnCheckedChangeListener(null);
        overlaySwitch.setChecked(overlayEnabled);
        overlaySwitch.setOnCheckedChangeListener((buttonView, checked) -> onOverlaySwitchChanged(checked));

        currentState = preferences.getServiceState();
        updateUiState();
        updateLastSavedText();
        // Starts/queries the service so an app process restarted after OS reclamation cannot show stale UI.
        sendServiceCommand(ScreenRecordService.ACTION_QUERY_STATE);

        if (pendingStart) beginStartFlow();
    }

    @Override
    protected void onPause() {
        super.onPause();
        if (receiverRegistered) {
            try { unregisterReceiver(stateReceiver); } catch (IllegalArgumentException ignored) { }
            receiverRegistered = false;
        }
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        if (intent != null && intent.getBooleanExtra(ScreenRecordService.EXTRA_AUTO_START, false)) beginStartFlow();
    }

    private void updateUiState() {
        if (statusText == null) return;
        if (RecordingPreferences.STATE_RECORDING.equals(currentState)) {
            statusText.setText(R.string.status_recording);
            startButton.setVisibility(View.GONE);
            pauseButton.setVisibility(View.VISIBLE);
            pauseButton.setEnabled(true);
            pauseButton.setText(R.string.pause_recording);
            stopButton.setVisibility(View.VISIBLE);
            stopButton.setEnabled(true);
        } else if (RecordingPreferences.STATE_PAUSED.equals(currentState)) {
            statusText.setText(R.string.status_paused);
            startButton.setVisibility(View.GONE);
            pauseButton.setVisibility(View.VISIBLE);
            pauseButton.setEnabled(true);
            pauseButton.setText(R.string.resume_recording);
            stopButton.setVisibility(View.VISIBLE);
            stopButton.setEnabled(true);
        } else {
            statusText.setText(R.string.status_idle);
            startButton.setVisibility(View.VISIBLE);
            startButton.setEnabled(true);
            pauseButton.setVisibility(View.GONE);
            pauseButton.setText(R.string.pause_recording);
            stopButton.setVisibility(View.GONE);
            stopButton.setEnabled(false);
        }
    }

    private void updateLastSavedText() {
        if (lastSavedText == null) return;
        String name = preferences.getLastRecordingName();
        String path = preferences.getLastRecordingPath();
        if (name == null || name.isEmpty()) {
            lastSavedText.setText("—");
        } else {
            lastSavedText.setText(path == null || path.isEmpty() ? name : name + "\n" + path);
        }
    }

    private void syncOverlayService() {
        sendServiceCommand(ScreenRecordService.ACTION_SYNC_OVERLAY);
    }

    private void sendServiceCommand(String action) {
        Intent intent = new Intent(this, ScreenRecordService.class).setAction(action);
        try {
            // QUERY/SYNC are ordinary started-service commands. Only a capture session uses FGS.
            startService(intent);
        } catch (RuntimeException e) {
            Toast.makeText(this, "Could not contact recording service: " + e.getMessage(), Toast.LENGTH_LONG).show();
        }
    }

    private interface SelectionAction { void onSelected(int position); }

    private static final class SimpleItemSelectedListener implements android.widget.AdapterView.OnItemSelectedListener {
        private final SelectionAction action;
        SimpleItemSelectedListener(SelectionAction action) { this.action = action; }
        @Override public void onItemSelected(android.widget.AdapterView<?> parent, View view, int position, long id) {
            action.onSelected(position);
        }
        @Override public void onNothingSelected(android.widget.AdapterView<?> parent) { }
    }
}
