package com.example.litescreenrecorder;

import android.Manifest;
import android.app.Activity;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.PackageManager;
import android.media.projection.MediaProjectionManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.Spinner;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

import androidx.core.content.ContextCompat;

import java.util.ArrayList;
import java.util.List;

/** Main settings and consent screen. Recording itself is owned by ScreenRecordService. */
public class MainActivity extends Activity {
    private static final int REQUEST_PERMISSIONS = 4101;
    private static final int REQUEST_PROJECTION = 4102;
    private static final int REQUEST_OVERLAY = 4103;
    public static final String EXTRA_AUTO_START = "auto_start_after_open";

    private RecordingPreferences preferences;
    private Spinner qualitySpinner;
    private Spinner fpsSpinner;
    private Spinner audioSpinner;
    private Switch overlaySwitch;
    private TextView statusText;
    private TextView lastRecordingText;
    private Button startButton;
    private Button pauseButton;
    private Button stopButton;
    private boolean buildingSpinners;
    private boolean changingOverlayProgrammatically;
    private boolean awaitingOverlayPermission;
    private boolean pendingPermissionFlow;
    private boolean receiverRegistered;

    private final BroadcastReceiver stateReceiver = new BroadcastReceiver() {
        @Override public void onReceive(Context context, Intent intent) {
            if (intent == null || !ScreenRecordService.ACTION_STATE_CHANGED.equals(intent.getAction())) return;
            updateUiFromLiveState(intent.getStringExtra(ScreenRecordService.EXTRA_STATE));
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        preferences = new RecordingPreferences(this);

        qualitySpinner = findViewById(R.id.qualitySpinner);
        fpsSpinner = findViewById(R.id.fpsSpinner);
        audioSpinner = findViewById(R.id.audioSpinner);
        overlaySwitch = findViewById(R.id.overlaySwitch);
        statusText = findViewById(R.id.statusText);
        lastRecordingText = findViewById(R.id.lastRecordingText);
        startButton = findViewById(R.id.startButton);
        pauseButton = findViewById(R.id.pauseButton);
        stopButton = findViewById(R.id.stopButton);

        setupSpinners();
        startButton.setOnClickListener(v -> beginPermissionAndProjectionFlow());
        pauseButton.setOnClickListener(v -> sendServiceAction(ScreenRecordService.ACTION_TOGGLE_PAUSE));
        stopButton.setOnClickListener(v -> sendServiceAction(ScreenRecordService.ACTION_STOP));
        overlaySwitch.setOnCheckedChangeListener((button, checked) -> {
            if (changingOverlayProgrammatically) return;
            if (checked) enableOverlay();
            else disableOverlay();
        });

        handleAutoStartIntent(getIntent());
    }

    private void setupSpinners() {
        buildingSpinners = true;
        ArrayAdapter<CharSequence> qualityAdapter = ArrayAdapter.createFromResource(
                this, R.array.quality_options, android.R.layout.simple_spinner_item);
        qualityAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        qualitySpinner.setAdapter(qualityAdapter);
        ArrayAdapter<CharSequence> fpsAdapter = ArrayAdapter.createFromResource(
                this, R.array.fps_options, android.R.layout.simple_spinner_item);
        fpsAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        fpsSpinner.setAdapter(fpsAdapter);
        ArrayAdapter<CharSequence> audioAdapter = ArrayAdapter.createFromResource(
                this, R.array.audio_options, android.R.layout.simple_spinner_item);
        audioAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        audioSpinner.setAdapter(audioAdapter);

        qualitySpinner.setSelection(RecordingPreferences.QUALITY_480.equals(preferences.getQuality()) ? 0
                : (RecordingPreferences.QUALITY_1080.equals(preferences.getQuality()) ? 2 : 1));
        fpsSpinner.setSelection(preferences.getFps() == 60 ? 1 : (preferences.getFps() == 90 ? 2 : 0));
        audioSpinner.setSelection(RecordingPreferences.AUDIO_INTERNAL_AND_MIC.equals(preferences.getAudioMode()) ? 1 : 0);

        qualitySpinner.setOnItemSelectedListener(new SimpleItemSelectedListener(position -> {
            if (!buildingSpinners) preferences.setQuality(position == 0
                    ? RecordingPreferences.QUALITY_480 : (position == 2
                    ? RecordingPreferences.QUALITY_1080 : RecordingPreferences.QUALITY_720));
        }));
        fpsSpinner.setOnItemSelectedListener(new SimpleItemSelectedListener(position -> {
            if (!buildingSpinners) preferences.setFps(position == 1 ? 60 : (position == 2 ? 90 : 30));
        }));
        audioSpinner.setOnItemSelectedListener(new SimpleItemSelectedListener(position -> {
            if (!buildingSpinners) preferences.setAudioMode(position == 1
                    ? RecordingPreferences.AUDIO_INTERNAL_AND_MIC
                    : RecordingPreferences.AUDIO_INTERNAL_ONLY);
        }));
        buildingSpinners = false;
    }

    @Override
    protected void onResume() {
        super.onResume();
        registerStateReceiver();
        syncOverlaySwitch();
        updateUiFromLiveState(null);
        if (awaitingOverlayPermission) {
            awaitingOverlayPermission = false;
            if (Settings.canDrawOverlays(this)) {
                preferences.setOverlayEnabled(true);
                startOverlayService();
            } else {
                preferences.setOverlayEnabled(false);
                toast(getString(R.string.overlay_not_available));
            }
            syncOverlaySwitch();
        }
    }

    @Override
    protected void onPause() {
        unregisterStateReceiver();
        super.onPause();
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        handleAutoStartIntent(intent);
    }

    private void handleAutoStartIntent(Intent intent) {
        if (intent != null && intent.getBooleanExtra(EXTRA_AUTO_START, false)) {
            intent.removeExtra(EXTRA_AUTO_START);
            getWindow().getDecorView().post(this::beginPermissionAndProjectionFlow);
        }
    }

    private void registerStateReceiver() {
        if (receiverRegistered) return;
        IntentFilter filter = new IntentFilter(ScreenRecordService.ACTION_STATE_CHANGED);
        ContextCompat.registerReceiver(this, stateReceiver, filter, ContextCompat.RECEIVER_NOT_EXPORTED);
        receiverRegistered = true;
    }

    private void unregisterStateReceiver() {
        if (!receiverRegistered) return;
        try { unregisterReceiver(stateReceiver); } catch (IllegalArgumentException ignored) { }
        receiverRegistered = false;
    }

    private void updateUiFromLiveState(String broadcastState) {
        String state = broadcastState;
        if (state == null) {
            state = preferences.getRecorderState();
            if (!ScreenRecordService.isSessionActive()
                    && !RecordingPreferences.STATE_IDLE.equals(state)) {
                // A process death can leave a stale persisted state; the service session is gone.
                state = RecordingPreferences.STATE_IDLE;
                preferences.setRecorderState(state);
            }
        }
        boolean recording = RecordingPreferences.STATE_RECORDING.equals(state);
        boolean paused = RecordingPreferences.STATE_PAUSED.equals(state);
        if (recording) {
            statusText.setText(R.string.status_recording);
            statusText.setTextColor(0xFFB3261E);
        } else if (paused) {
            statusText.setText(R.string.status_paused);
            statusText.setTextColor(0xFFB26A00);
        } else {
            statusText.setText(R.string.status_idle);
            statusText.setTextColor(0xFF1565C0);
        }
        startButton.setVisibility(recording || paused ? android.view.View.GONE : android.view.View.VISIBLE);
        pauseButton.setVisibility(recording || paused ? android.view.View.VISIBLE : android.view.View.GONE);
        stopButton.setVisibility(recording || paused ? android.view.View.VISIBLE : android.view.View.GONE);
        startButton.setEnabled(!recording && !paused);
        pauseButton.setEnabled(recording || paused);
        pauseButton.setText(paused ? R.string.resume_recording : R.string.pause_recording);
        stopButton.setEnabled(recording || paused);

        String label = preferences.getLastRecordingLabel();
        String path = preferences.getLastRecordingPath();
        if (label == null || label.trim().isEmpty()) {
            lastRecordingText.setText(R.string.not_saved_yet);
        } else {
            lastRecordingText.setText(path == null || path.isEmpty() ? label : label + "\n" + path);
        }
    }

    private void syncOverlaySwitch() {
        boolean allowed = Settings.canDrawOverlays(this);
        boolean enabled = allowed && preferences.isOverlayEnabled();
        changingOverlayProgrammatically = true;
        overlaySwitch.setChecked(enabled);
        changingOverlayProgrammatically = false;
        if (!allowed && preferences.isOverlayEnabled()) preferences.setOverlayEnabled(false);
    }

    private void enableOverlay() {
        if (!Settings.canDrawOverlays(this)) {
            preferences.setOverlayEnabled(false);
            changingOverlayProgrammatically = true;
            overlaySwitch.setChecked(false);
            changingOverlayProgrammatically = false;
            awaitingOverlayPermission = true;
            toast(getString(R.string.overlay_permission_message));
            Intent intent = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                    Uri.parse("package:" + getPackageName()));
            startActivityForResult(intent, REQUEST_OVERLAY);
            return;
        }
        preferences.setOverlayEnabled(true);
        startOverlayService();
    }

    private void disableOverlay() {
        preferences.setOverlayEnabled(false);
        sendServiceAction(ScreenRecordService.ACTION_OVERLAY_DISABLE);
    }

    private void startOverlayService() {
        Intent intent = new Intent(this, ScreenRecordService.class);
        intent.setAction(ScreenRecordService.ACTION_OVERLAY_ENABLE);
        startService(intent);
    }

    private void beginPermissionAndProjectionFlow() {
        if (!RecordingPreferences.STATE_IDLE.equals(preferences.getRecorderState())
                && ScreenRecordService.isSessionActive()) {
            toast("A recording session is already active.");
            return;
        }
        if (pendingPermissionFlow) return;
        List<String> missing = new ArrayList<>();
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO)
                != PackageManager.PERMISSION_GRANTED) {
            missing.add(Manifest.permission.RECORD_AUDIO);
        }
        if (Build.VERSION.SDK_INT <= 28
                && ContextCompat.checkSelfPermission(this, Manifest.permission.WRITE_EXTERNAL_STORAGE)
                != PackageManager.PERMISSION_GRANTED) {
            missing.add(Manifest.permission.WRITE_EXTERNAL_STORAGE);
        }
        if (Build.VERSION.SDK_INT >= 33
                && ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS)
                != PackageManager.PERMISSION_GRANTED) {
            missing.add(Manifest.permission.POST_NOTIFICATIONS);
        }
        if (!missing.isEmpty()) {
            pendingPermissionFlow = true;
            requestPermissions(missing.toArray(new String[0]), REQUEST_PERMISSIONS);
        } else {
            launchProjectionConsent();
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode != REQUEST_PERMISSIONS) return;
        pendingPermissionFlow = false;
        boolean audioGranted = ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO)
                == PackageManager.PERMISSION_GRANTED;
        boolean storageGranted = Build.VERSION.SDK_INT > 28
                || ContextCompat.checkSelfPermission(this, Manifest.permission.WRITE_EXTERNAL_STORAGE)
                == PackageManager.PERMISSION_GRANTED;
        // Notification permission is requested, but Android permits an FGS to run if denied.
        if (!audioGranted || !storageGranted) {
            toast(getString(R.string.permission_required));
            return;
        }
        launchProjectionConsent();
    }

    private void launchProjectionConsent() {
        MediaProjectionManager manager = (MediaProjectionManager)
                getSystemService(Context.MEDIA_PROJECTION_SERVICE);
        if (manager == null) {
            toast(getString(R.string.no_projection));
            return;
        }
        // Every recording gets its own fresh consent Intent; never cache or reuse it.
        startActivityForResult(manager.createScreenCaptureIntent(), REQUEST_PROJECTION);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQUEST_PROJECTION) {
            if (resultCode != RESULT_OK || data == null) {
                toast(getString(R.string.no_projection));
                return;
            }
            Intent service = new Intent(this, ScreenRecordService.class);
            service.setAction(ScreenRecordService.ACTION_START);
            service.putExtra(ScreenRecordService.EXTRA_RESULT_CODE, resultCode);
            service.putExtra(ScreenRecordService.EXTRA_PROJECTION_DATA, data);
            service.putExtra(ScreenRecordService.EXTRA_AUDIO_MODE, preferences.getAudioMode());
            if (Build.VERSION.SDK_INT >= 26) startForegroundService(service);
            else startService(service);
        } else if (requestCode == REQUEST_OVERLAY) {
            if (Settings.canDrawOverlays(this)) {
                preferences.setOverlayEnabled(true);
                startOverlayService();
            } else {
                preferences.setOverlayEnabled(false);
            }
            syncOverlaySwitch();
        }
    }

    private void sendServiceAction(String action) {
        Intent intent = new Intent(this, ScreenRecordService.class);
        intent.setAction(action);
        startService(intent);
    }

    private void toast(String text) {
        Toast.makeText(this, text, Toast.LENGTH_LONG).show();
    }

    /** Minimal listener so this screen does not need AppCompat or a UI framework. */
    private static final class SimpleItemSelectedListener
            implements android.widget.AdapterView.OnItemSelectedListener {
        interface Selection { void selected(int position); }
        private final Selection selection;
        SimpleItemSelectedListener(Selection selection) { this.selection = selection; }
        @Override public void onItemSelected(android.widget.AdapterView<?> parent,
                android.view.View view, int position, long id) { selection.selected(position); }
        @Override public void onNothingSelected(android.widget.AdapterView<?> parent) { }
    }
}
