# Android framework entry points are referenced from the manifest.
-keep public class com.example.litescreenrecorder.MainActivity { *; }
-keep public class com.example.litescreenrecorder.ScreenRecordService { *; }

# Keep enum/string preference names and service intent action strings stable.
-keepattributes *Annotation*
