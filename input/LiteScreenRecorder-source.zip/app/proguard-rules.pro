# Android framework components are discovered from the manifest.
# Keep useful line information in release crash reports.
-keepattributes SourceFile,LineNumberTable
-renamesourcefileattribute SourceFile
