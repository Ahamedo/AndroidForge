# No custom shrinking rules are required in V1.3.
