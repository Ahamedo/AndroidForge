package com.example.floatingrecorder;

import android.content.Context;
import android.media.AudioAttributes;
import android.media.AudioFormat;
import android.media.AudioPlaybackCaptureConfiguration;
import android.media.AudioRecord;
import android.media.MediaCodec;
import android.media.MediaCodecInfo;
import android.media.MediaCodecList;
import android.media.MediaFormat;
import android.media.MediaRecorder;
import android.media.MediaMuxer;
import android.media.projection.MediaProjection;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.view.Surface;
import android.hardware.display.DisplayManager;
import android.hardware.display.VirtualDisplay;

import java.io.IOException;
import java.nio.ByteBuffer;
import java.util.ArrayList;
import java.util.List;
import java.nio.ByteOrder;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicLong;

/** Encodes one continuous MP4 file for each recording session. */
public final class RecordingEngine {
    public interface FinishedListener { void onFinished(Result result); }

    public static final class Result {
        public final boolean success;
        public final android.net.Uri uri;
        public final String fileName;
        public final long sizeBytes;
        public final String message;
        public final String sessionId;
        Result(boolean success, android.net.Uri uri, String fileName, long sizeBytes,
               String message, String sessionId) {
            this.success = success; this.uri = uri; this.fileName = fileName;
            this.sizeBytes = sizeBytes; this.message = message; this.sessionId = sessionId;
        }
    }

    private static final String VIDEO_MIME = "video/avc";
    private static final String AUDIO_MIME = "audio/mp4a-latm";
    private static final int SAMPLE_RATE = 44_100;
    private static final int AUDIO_CHANNELS = 1;
    private static final int AUDIO_CHUNK_SAMPLES = 1024;
    private static final long CODEC_TIMEOUT_US = 10_000L;

    private final Context context;
    private final MediaProjection projection;
    private int width;
    private int height;
    private final int requestedFps;
    private final int requestedBitrate;
    private int activeBitrate;
    private final String requestedAudioMode;
    private final String sessionId;
    private final FinishedListener listener;
    private final DiagnosticsLogger logger;
    private final StorageManager storage;

    private final AtomicBoolean stopRequested = new AtomicBoolean(false);
    private final AtomicBoolean paused = new AtomicBoolean(false);
    private final AtomicBoolean finalized = new AtomicBoolean(false);
    private final Object pauseLock = new Object();
    private final List<long[]> pauseIntervalsNs = new ArrayList<>();
    private long pauseStartedNs;
    private final AtomicBoolean fatalVideoError = new AtomicBoolean(false);
    private final AtomicBoolean audioUnavailable = new AtomicBoolean(false);
    private final AtomicBoolean startupComplete = new AtomicBoolean(false);
    private final AtomicBoolean stopperStarted = new AtomicBoolean(false);
    private final AtomicLong encodedFrames = new AtomicLong(0L);
    private final AtomicLong droppedMuxerSamples = new AtomicLong(0L);
    private final AtomicLong audioSamplesQueued = new AtomicLong(0L);
    private final AtomicBoolean videoEosSeen = new AtomicBoolean(false);
    private final AtomicBoolean audioEosSeen = new AtomicBoolean(false);
    private final Object muxerLock = new Object();

    private MediaCodec videoCodec;
    private MediaCodec audioCodec;
    private Surface videoSurface;
    private VirtualDisplay virtualDisplay;
    private MediaMuxer muxer;
    private StorageManager.OutputTarget output;
    private volatile AudioRecord microphoneRecord;
    private volatile AudioRecord systemRecord;

    private Thread videoDrainThread;
    private Thread audioDrainThread;
    private Thread audioFeedThread;

    private boolean muxerStarted;
    private int videoTrack = -1;
    private int audioTrack = -1;
    private int activeFps;
    private long startedAtNs;
    private volatile String pendingStopReason;
    private volatile String failureMessage;

    private final MediaProjection.Callback projectionCallback = new MediaProjection.Callback() {
        @Override public void onStop() {
            logger.warn("Projection", sessionId, "MediaProjection revoked by the system/user");
            requestStop("projection_revoked");
        }
    };

    public RecordingEngine(Context context, MediaProjection projection, int width, int height,
                           int fps, int bitrate, String audioMode, String sessionId,
                           FinishedListener listener) {
        this.context = context.getApplicationContext();
        this.projection = projection;
        this.width = width;
        this.height = height;
        this.requestedFps = fps;
        this.requestedBitrate = bitrate;
        this.activeBitrate = bitrate;
        this.requestedAudioMode = audioMode;
        this.sessionId = sessionId;
        this.listener = listener;
        this.logger = DiagnosticsLogger.get(context);
        this.storage = new StorageManager(context);
    }

    public boolean start() {
        try {
            output = storage.createOutput(sessionId);
            muxer = output.createMuxer();
            prepareVideoCodec();
            prepareAudioCodecAndSources();

            // Android 14+ requires the callback to be registered before createVirtualDisplay().
            projection.registerCallback(projectionCallback, new Handler(Looper.getMainLooper()));
            virtualDisplay = projection.createVirtualDisplay(
                    "LiteScreenRecorder", width, height,
                    context.getResources().getDisplayMetrics().densityDpi,
                    DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
                    videoSurface, null, new Handler(Looper.getMainLooper()));
            if (virtualDisplay == null) throw new IOException("MediaProjection.createVirtualDisplay returned null");

            if (microphoneRecord != null || systemRecord != null) {
                try { if (microphoneRecord != null) microphoneRecord.startRecording(); }
                catch (RuntimeException error) { disableSource(true, error); }
                try { if (systemRecord != null) systemRecord.startRecording(); }
                catch (RuntimeException error) { disableSource(false, error); }
                if (!isAnyAudioSourceRecording()) disableAudioPipeline("No AudioRecord source entered RECORDING state", null);
            } else if (!RecorderPreferences.AUDIO_MUTE.equals(requestedAudioMode)) {
                disableAudioPipeline("Audio capture unavailable; recording will continue video-only", null);
            }

            startedAtNs = System.nanoTime();
            videoDrainThread = new Thread(this::drainVideo, "LiteRecorderVideoDrain");
            videoDrainThread.start();
            if (audioCodec != null && !audioUnavailable.get()) {
                audioDrainThread = new Thread(this::drainAudio, "LiteRecorderAudioDrain");
                audioFeedThread = new Thread(this::feedAudio, "LiteRecorderAudioFeed");
                audioDrainThread.start();
                audioFeedThread.start();
            }
            startupComplete.set(true);
            if (stopRequested.get() && !finalized.get()) startStopWorker(pendingStopReason == null ? "stop_during_startup" : pendingStopReason);
            logger.info("RecorderVideo", sessionId,
                    "Started; size=" + width + "x" + height + "; requestedFps=" + requestedFps +
                            "; activeFps=" + activeFps + "; bitrate=" + getVideoBitrate() +
                            "; audioRequested=" + requestedAudioMode + "; audioEnabled=" + (audioCodec != null));
            return true;
        } catch (OutOfMemoryError memoryError) {
            logger.error("RecorderPerformance", sessionId, "OutOfMemoryError during recording startup; aborting", memoryError);
            failureMessage = "Insufficient memory to start recording";
            failAndCleanup(memoryError);
            startupComplete.set(true);
            return false;
        } catch (Exception error) {
            logger.error("RecorderService", sessionId, "Recording startup failed", error);
            failureMessage = error.getMessage() == null ? error.getClass().getSimpleName() : error.getMessage();
            failAndCleanup(error);
            startupComplete.set(true);
            return false;
        }
    }

    private void prepareVideoCodec() throws Exception {
        int originalLongSide = Math.max(width, height);
        int[] longSideCandidates;
        if (originalLongSide > 720) longSideCandidates = new int[]{originalLongSide, 720, 480};
        else if (originalLongSide > 480) longSideCandidates = new int[]{originalLongSide, 480};
        else longSideCandidates = new int[]{originalLongSide};

        int[] fpsCandidates;
        if (requestedFps >= 60) fpsCandidates = new int[]{60, 30, 24, 15};
        else if (requestedFps >= 30) fpsCandidates = new int[]{30, 24, 15};
        else if (requestedFps >= 24) fpsCandidates = new int[]{24, 15};
        else fpsCandidates = new int[]{15};

        Exception lastError = null;
        for (int longSide : longSideCandidates) {
            int[] candidateSize = fitEvenSize(width, height, longSide);
            for (int candidateFps : fpsCandidates) {
                String codecName = findHardwareAvcEncoder(candidateSize[0], candidateSize[1], candidateFps);
                if (codecName == null) {
                    lastError = new IOException("No hardware AVC encoder reports support for " +
                            candidateSize[0] + "x" + candidateSize[1] + " at " + candidateFps + " FPS");
                    continue;
                }
                MediaCodec candidate = null;
                Surface candidateSurface = null;
                try {
                    candidate = MediaCodec.createByCodecName(codecName);
                    int candidateBitrate = Math.max(1_500_000, (int) (requestedBitrate *
                            ((double) candidateSize[0] * candidateSize[1]) / ((double) width * height)));
                    MediaFormat format = MediaFormat.createVideoFormat(VIDEO_MIME, candidateSize[0], candidateSize[1]);
                    format.setInteger(MediaFormat.KEY_COLOR_FORMAT, MediaCodecInfo.CodecCapabilities.COLOR_FormatSurface);
                    format.setInteger(MediaFormat.KEY_BIT_RATE, candidateBitrate);
                    format.setInteger(MediaFormat.KEY_FRAME_RATE, candidateFps);
                    format.setInteger(MediaFormat.KEY_I_FRAME_INTERVAL, 2);
                    candidate.configure(format, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE);
                    candidateSurface = candidate.createInputSurface();
                    candidate.start();
                    videoCodec = candidate;
                    videoSurface = candidateSurface;
                    width = candidateSize[0];
                    height = candidateSize[1];
                    activeBitrate = candidateBitrate;
                    activeFps = candidateFps;
                    logger.info("RecorderVideo", sessionId, "Selected hardware encoder=" + codecName +
                            "; size=" + width + "x" + height + "; fps=" + activeFps +
                            "; bitrate=" + activeBitrate);
                    return;
                } catch (Exception error) {
                    lastError = error;
                    if (candidateSurface != null) try { candidateSurface.release(); }
                    catch (RuntimeException releaseError) {
                        logger.warn("RecorderVideo", sessionId, "Input surface release after fallback failed: " + releaseError.getMessage());
                    }
                    if (candidate != null) releaseCodec(candidate, "video startup fallback");
                    logger.warn("RecorderVideo", sessionId, "Encoder rejected " + candidateSize[0] + "x" +
                            candidateSize[1] + " @ " + candidateFps + " FPS: " + error.getMessage());
                }
            }
        }
        throw new IOException("No supported hardware AVC configuration was found. Software encoding is disabled in Lite Resource mode.", lastError);
    }

    private int[] fitEvenSize(int sourceWidth, int sourceHeight, int maxLongSide) {
        double scale = Math.min(1.0d, maxLongSide / (double) Math.max(sourceWidth, sourceHeight));
        int w = Math.max(2, ((int) Math.floor(sourceWidth * scale)) & ~1);
        int h = Math.max(2, ((int) Math.floor(sourceHeight * scale)) & ~1);
        return new int[]{w, h};
    }

    private String findHardwareAvcEncoder(int width, int height, int fps) {
        try {
            MediaCodecList list = new MediaCodecList(MediaCodecList.REGULAR_CODECS);
            for (MediaCodecInfo info : list.getCodecInfos()) {
                if (!info.isEncoder()) continue;
                boolean supportsAvc = false;
                for (String type : info.getSupportedTypes()) {
                    if (VIDEO_MIME.equalsIgnoreCase(type)) { supportsAvc = true; break; }
                }
                if (!supportsAvc) continue;
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                    if (!info.isHardwareAccelerated()) continue;
                } else {
                    String name = info.getName().toLowerCase(java.util.Locale.US);
                    if (name.contains("google") || name.contains("android") || name.contains("software")) continue;
                }
                MediaCodecInfo.CodecCapabilities capabilities = info.getCapabilitiesForType(VIDEO_MIME);
                boolean surfaceSupported = false;
                for (int color : capabilities.colorFormats) {
                    if (color == MediaCodecInfo.CodecCapabilities.COLOR_FormatSurface) { surfaceSupported = true; break; }
                }
                if (!surfaceSupported || capabilities.getVideoCapabilities() == null) continue;
                if (capabilities.getVideoCapabilities().areSizeAndRateSupported(width, height, (double) fps)) {
                    return info.getName();
                }
            }
        } catch (RuntimeException error) {
            logger.error("RecorderVideo", sessionId, "Hardware encoder capability query failed", error);
        }
        return null;
    }

    private void prepareAudioCodecAndSources() {
        if (RecorderPreferences.AUDIO_MUTE.equals(requestedAudioMode)) return;
        try {
            if (RecorderPreferences.AUDIO_MIC.equals(requestedAudioMode)
                    || RecorderPreferences.AUDIO_BOTH.equals(requestedAudioMode)) {
                microphoneRecord = buildMicrophoneRecord();
            }
        } catch (Exception error) {
            logger.error("RecorderAudio", sessionId, "Microphone capture setup failed; continuing without it", error);
            microphoneRecord = null;
        }
        try {
            if (RecorderPreferences.AUDIO_SYSTEM.equals(requestedAudioMode)
                    || RecorderPreferences.AUDIO_BOTH.equals(requestedAudioMode)) {
                systemRecord = buildSystemRecord();
            }
        } catch (Exception error) {
            logger.error("RecorderAudio", sessionId, "Internal audio capture setup failed; continuing without it", error);
            systemRecord = null;
        }
        if (microphoneRecord == null && systemRecord == null) {
            audioUnavailable.set(true);
            return;
        }
        try {
            MediaFormat audioFormat = MediaFormat.createAudioFormat(AUDIO_MIME, SAMPLE_RATE, AUDIO_CHANNELS);
            audioFormat.setInteger(MediaFormat.KEY_AAC_PROFILE, 2);
            audioFormat.setInteger(MediaFormat.KEY_BIT_RATE, 96_000);
            audioFormat.setInteger(MediaFormat.KEY_MAX_INPUT_SIZE, AUDIO_CHUNK_SAMPLES * 2);
            audioCodec = MediaCodec.createEncoderByType(AUDIO_MIME);
            audioCodec.configure(audioFormat, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE);
            audioCodec.start();
        } catch (Exception error) {
            logger.error("RecorderAudio", sessionId, "AAC encoder unavailable; continuing video-only", error);
            releaseCodec(audioCodec, "audio encoder setup failure");
            audioCodec = null;
            releaseAudioRecords();
            audioUnavailable.set(true);
        }
    }

    private AudioRecord buildMicrophoneRecord() throws Exception {
        int minBytes = AudioRecord.getMinBufferSize(SAMPLE_RATE, AudioFormat.CHANNEL_IN_MONO,
                AudioFormat.ENCODING_PCM_16BIT);
        if (minBytes <= 0) throw new IOException("Invalid microphone minimum buffer size: " + minBytes);
        AudioFormat format = new AudioFormat.Builder().setSampleRate(SAMPLE_RATE)
                .setChannelMask(AudioFormat.CHANNEL_IN_MONO)
                .setEncoding(AudioFormat.ENCODING_PCM_16BIT).build();
        AudioRecord record = new AudioRecord.Builder().setAudioSource(MediaRecorder.AudioSource.MIC)
                .setAudioFormat(format).setBufferSizeInBytes(Math.max(minBytes * 2, 8192)).build();
        if (record.getState() != AudioRecord.STATE_INITIALIZED) {
            record.release();
            throw new IOException("Microphone AudioRecord did not initialize");
        }
        return record;
    }

    private AudioRecord buildSystemRecord() throws Exception {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.Q) throw new IOException("Internal audio requires Android 10 or later");
        int minBytes = AudioRecord.getMinBufferSize(SAMPLE_RATE, AudioFormat.CHANNEL_IN_MONO,
                AudioFormat.ENCODING_PCM_16BIT);
        if (minBytes <= 0) throw new IOException("Invalid playback minimum buffer size: " + minBytes);
        AudioPlaybackCaptureConfiguration capture = new AudioPlaybackCaptureConfiguration.Builder(projection)
                .addMatchingUsage(AudioAttributes.USAGE_MEDIA)
                .addMatchingUsage(AudioAttributes.USAGE_GAME)
                .build();
        AudioFormat format = new AudioFormat.Builder().setSampleRate(SAMPLE_RATE)
                .setChannelMask(AudioFormat.CHANNEL_IN_MONO)
                .setEncoding(AudioFormat.ENCODING_PCM_16BIT).build();
        AudioRecord record = new AudioRecord.Builder().setAudioFormat(format)
                .setBufferSizeInBytes(Math.max(minBytes * 2, 8192))
                .setAudioPlaybackCaptureConfig(capture).build();
        if (record.getState() != AudioRecord.STATE_INITIALIZED) {
            record.release();
            throw new IOException("Playback AudioRecord did not initialize");
        }
        return record;
    }

    private void drainVideo() {
        MediaCodec codec = videoCodec;
        if (codec == null) return;
        MediaCodec.BufferInfo info = new MediaCodec.BufferInfo();
        long stopWaitStart = 0L;
        try {
            while (true) {
                int index = codec.dequeueOutputBuffer(info, CODEC_TIMEOUT_US);
                if (index == MediaCodec.INFO_TRY_AGAIN_LATER) {
                    if (stopRequested.get()) {
                        if (stopWaitStart == 0L) stopWaitStart = android.os.SystemClock.elapsedRealtime();
                        if (android.os.SystemClock.elapsedRealtime() - stopWaitStart > 4000L) {
                            logger.warn("RecorderVideo", sessionId, "Video encoder EOS timeout; leaving drain loop");
                            break;
                        }
                    }
                    continue;
                }
                if (index == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) {
                    addVideoTrack(codec.getOutputFormat());
                    continue;
                }
                if (index >= 0) {
                    ByteBuffer buffer = codec.getOutputBuffer(index);
                    try {
                        if (buffer != null && info.size > 0
                                && (info.flags & MediaCodec.BUFFER_FLAG_CODEC_CONFIG) == 0) {
                            long adjustedPtsUs = adjustVideoPresentationTimeUs(info.presentationTimeUs);
                            if (adjustedPtsUs >= 0L) {
                                MediaCodec.BufferInfo adjusted = new MediaCodec.BufferInfo();
                                adjusted.set(info.offset, info.size, adjustedPtsUs, info.flags);
                                if (writeSample(videoTrack, buffer, adjusted)) encodedFrames.incrementAndGet();
                                else droppedMuxerSamples.incrementAndGet();
                            } else {
                                droppedMuxerSamples.incrementAndGet();
                            }
                        }
                    } finally { codec.releaseOutputBuffer(index, false); }
                    if ((info.flags & MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0) {
                        videoEosSeen.set(true);
                        break;
                    }
                }
            }
        } catch (Exception error) {
            if (!finalized.get()) requestVideoFailure("Video encoder drain failed", error);
        }
    }

    private void drainAudio() {
        MediaCodec codec = audioCodec;
        if (codec == null) return;
        MediaCodec.BufferInfo info = new MediaCodec.BufferInfo();
        long stopWaitStart = 0L;
        try {
            while (true) {
                int index = codec.dequeueOutputBuffer(info, CODEC_TIMEOUT_US);
                if (index == MediaCodec.INFO_TRY_AGAIN_LATER) {
                    if (stopRequested.get() || audioUnavailable.get()) {
                        if (stopWaitStart == 0L) stopWaitStart = android.os.SystemClock.elapsedRealtime();
                        if (android.os.SystemClock.elapsedRealtime() - stopWaitStart > 4000L) break;
                    }
                    continue;
                }
                if (index == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) {
                    addAudioTrack(codec.getOutputFormat());
                    continue;
                }
                if (index >= 0) {
                    ByteBuffer buffer = codec.getOutputBuffer(index);
                    try {
                        if (buffer != null && info.size > 0
                                && (info.flags & MediaCodec.BUFFER_FLAG_CODEC_CONFIG) == 0) {
                            if (!writeSample(audioTrack, buffer, info)) droppedMuxerSamples.incrementAndGet();
                        }
                    } finally { codec.releaseOutputBuffer(index, false); }
                    if ((info.flags & MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0) {
                        audioEosSeen.set(true);
                        break;
                    }
                }
            }
        } catch (Exception error) {
            if (!finalized.get()) disableAudioPipeline("Audio encoder drain failed; video remains active", error);
        }
    }

    private void feedAudio() {
        short[] micSamples = new short[AUDIO_CHUNK_SAMPLES];
        short[] systemSamples = new short[AUDIO_CHUNK_SAMPLES];
        short[] mixedSamples = new short[AUDIO_CHUNK_SAMPLES];
        try {
            while (!stopRequested.get() && !audioUnavailable.get()) {
                int micCount = microphoneRecord == null ? 0 : readSamples(microphoneRecord, micSamples, true);
                int systemCount = systemRecord == null ? 0 : readSamples(systemRecord, systemSamples, false);
                if (micCount < 0 && systemCount < 0) {
                    disableAudioPipeline("All audio sources stopped; continuing video-only", null);
                    break;
                }
                int frames = Math.max(Math.max(micCount, 0), Math.max(systemCount, 0));
                if (paused.get()) continue; // Consume and discard audio while paused; the saved timeline stays continuous.
                if (frames == 0) {
                    // Guard against a device/route returning empty reads repeatedly.
                    Thread.sleep(2L);
                    continue;
                }
                if (RecorderPreferences.AUDIO_BOTH.equals(requestedAudioMode)
                        && microphoneRecord != null && systemRecord != null) {
                    for (int i = 0; i < frames; i++) {
                        int mic = i < micCount ? micSamples[i] : 0;
                        int system = i < systemCount ? systemSamples[i] : 0;
                        mixedSamples[i] = (short) Math.max(Short.MIN_VALUE,
                                Math.min(Short.MAX_VALUE, (system * 0.70f) + (mic * 0.30f)));
                    }
                } else if (systemCount > 0) {
                    System.arraycopy(systemSamples, 0, mixedSamples, 0, frames);
                } else {
                    System.arraycopy(micSamples, 0, mixedSamples, 0, frames);
                }
                if (!queuePcm(mixedSamples, frames)) break;
            }
        } catch (Exception error) {
            disableAudioPipeline("Audio capture failed; continuing video-only", error);
        } finally {
            queueAudioEos();
        }
    }

    private int readSamples(AudioRecord record, short[] target, boolean microphone) {
        if (record == null) return 0;
        int count = record.read(target, 0, target.length, AudioRecord.READ_BLOCKING);
        if (count >= 0) return count;
        String source = microphone ? "microphone" : "internal";
        logger.warn("RecorderAudio", sessionId, source + " AudioRecord.read returned " + count);
        if (microphone) disableSource(true, new IOException("AudioRecord.read returned " + count));
        else disableSource(false, new IOException("AudioRecord.read returned " + count));
        return -1;
    }

    private boolean queuePcm(short[] samples, int sampleCount) throws Exception {
        MediaCodec codec = audioCodec;
        if (codec == null) return false;
        long deadline = android.os.SystemClock.elapsedRealtime() + 1000L;
        while (!stopRequested.get() && !audioUnavailable.get()) {
            int inputIndex = codec.dequeueInputBuffer(CODEC_TIMEOUT_US);
            if (inputIndex >= 0) {
                ByteBuffer input = codec.getInputBuffer(inputIndex);
                if (input == null) {
                    codec.queueInputBuffer(inputIndex, 0, 0, audioSamplesQueued.get() * 1_000_000L / SAMPLE_RATE, 0);
                    return false;
                }
                input.clear();
                input.order(ByteOrder.LITTLE_ENDIAN);
                int count = Math.min(sampleCount, input.remaining() / 2);
                for (int i = 0; i < count; i++) input.putShort(samples[i]);
                long ptsUs = audioSamplesQueued.get() * 1_000_000L / SAMPLE_RATE;
                codec.queueInputBuffer(inputIndex, 0, count * 2, ptsUs, 0);
                audioSamplesQueued.addAndGet(count);
                return true;
            }
            if (android.os.SystemClock.elapsedRealtime() > deadline) {
                logger.warn("RecorderAudio", sessionId, "AAC input buffer wait exceeded 1 second; dropping one audio chunk");
                return true;
            }
        }
        return false;
    }

    private void queueAudioEos() {
        MediaCodec codec = audioCodec;
        if (codec == null) return;
        try {
            long deadline = android.os.SystemClock.elapsedRealtime() + 1500L;
            while (android.os.SystemClock.elapsedRealtime() < deadline) {
                int index = codec.dequeueInputBuffer(CODEC_TIMEOUT_US);
                if (index >= 0) {
                    codec.queueInputBuffer(index, 0, 0,
                            audioSamplesQueued.get() * 1_000_000L / SAMPLE_RATE,
                            MediaCodec.BUFFER_FLAG_END_OF_STREAM);
                    return;
                }
            }
            logger.warn("RecorderAudio", sessionId, "Could not queue AAC EOS before timeout");
        } catch (Exception error) {
            logger.error("RecorderAudio", sessionId, "Queueing AAC EOS failed", error);
        }
    }

    private void addVideoTrack(MediaFormat format) {
        synchronized (muxerLock) {
            if (videoTrack != -1 || muxer == null) return;
            videoTrack = muxer.addTrack(format);
            maybeStartMuxerLocked();
        }
    }

    private void addAudioTrack(MediaFormat format) {
        synchronized (muxerLock) {
            if (audioTrack != -1 || muxer == null || audioUnavailable.get()) return;
            audioTrack = muxer.addTrack(format);
            maybeStartMuxerLocked();
        }
    }

    private void maybeStartMuxerLocked() {
        if (muxerStarted || videoTrack == -1) return;
        boolean audioReady = audioCodec == null || audioUnavailable.get() || audioTrack != -1;
        if (audioReady) {
            muxer.start();
            muxerStarted = true;
            muxerLock.notifyAll();
            logger.info("RecorderStorage", sessionId, "MediaMuxer started; videoTrack=" + videoTrack + "; audioTrack=" + audioTrack);
        }
    }

    private boolean writeSample(int track, ByteBuffer source, MediaCodec.BufferInfo info) {
        if (track < 0 || source == null) return false;
        synchronized (muxerLock) {
            long waitStart = android.os.SystemClock.elapsedRealtime();
            while (!muxerStarted && !finalized.get() && !fatalVideoError.get()) {
                try { muxerLock.wait(100L); }
                catch (InterruptedException interrupted) { Thread.currentThread().interrupt(); return false; }
                if (android.os.SystemClock.elapsedRealtime() - waitStart > 5000L) {
                    logger.warn("RecorderStorage", sessionId, "Timed out waiting for muxer start");
                    return false;
                }
            }
            if (!muxerStarted || muxer == null) return false;
            ByteBuffer sample = source.duplicate();
            sample.position(info.offset);
            sample.limit(info.offset + info.size);
            MediaCodec.BufferInfo adjusted = new MediaCodec.BufferInfo();
            adjusted.set(0, info.size, info.presentationTimeUs, info.flags);
            muxer.writeSampleData(track, sample.slice(), adjusted);
            return true;
        }
    }

    /** Pause capture without closing the MP4 muxer or releasing the projection. */
    public boolean pauseRecording() {
        if (stopRequested.get() || finalized.get() || virtualDisplay == null) return false;
        synchronized (pauseLock) {
            if (paused.get()) return false;
            pauseStartedNs = System.nanoTime();
            paused.set(true);
            try {
                virtualDisplay.setSurface(null);
                logger.info("RecorderService", sessionId, "Recording paused");
                return true;
            } catch (RuntimeException error) {
                paused.set(false);
                pauseStartedNs = 0L;
                logger.error("RecorderService", sessionId, "Could not pause virtual display", error);
                return false;
            }
        }
    }

    /** Resume capture and remove the paused interval from video presentation timestamps. */
    public boolean resumeRecording() {
        if (stopRequested.get() || finalized.get() || virtualDisplay == null) return false;
        synchronized (pauseLock) {
            if (!paused.get()) return false;
            long resumedAt = System.nanoTime();
            long[] addedInterval = null;
            try {
                if (pauseStartedNs > 0L && resumedAt > pauseStartedNs) {
                    addedInterval = new long[]{pauseStartedNs, resumedAt};
                    pauseIntervalsNs.add(addedInterval);
                }
                virtualDisplay.setSurface(videoSurface);
                pauseStartedNs = 0L;
                paused.set(false);
                logger.info("RecorderService", sessionId, "Recording resumed");
                return true;
            } catch (RuntimeException error) {
                if (addedInterval != null) pauseIntervalsNs.remove(addedInterval);
                logger.error("RecorderService", sessionId, "Could not resume virtual display", error);
                return false;
            }
        }
    }

    public boolean isPaused() { return paused.get(); }

    private long adjustVideoPresentationTimeUs(long presentationTimeUs) {
        long ptsNs = presentationTimeUs * 1000L;
        long removedNs = 0L;
        synchronized (pauseLock) {
            for (long[] interval : pauseIntervalsNs) {
                if (ptsNs >= interval[1]) removedNs += interval[1] - interval[0];
                else if (ptsNs >= interval[0]) return -1L;
            }
            if (paused.get() && pauseStartedNs > 0L && ptsNs >= pauseStartedNs) return -1L;
        }
        long adjusted = presentationTimeUs - (removedNs / 1000L);
        return Math.max(0L, adjusted);
    }

    private long getPausedDurationNs() {
        synchronized (pauseLock) {
            long total = 0L;
            for (long[] interval : pauseIntervalsNs) total += interval[1] - interval[0];
            if (paused.get() && pauseStartedNs > 0L) total += Math.max(0L, System.nanoTime() - pauseStartedNs);
            return total;
        }
    }

    public void requestStop(String reason) {
        if (!stopRequested.compareAndSet(false, true)) return;
        pendingStopReason = reason == null ? "unspecified" : reason;
        logger.info("RecorderService", sessionId, "Stop requested; reason=" + pendingStopReason);
        // A projection callback can arrive while start() is still creating codecs/VirtualDisplay.
        // Defer teardown until startup has either completed or failed, avoiding concurrent release.
        if (startupComplete.get() && !finalized.get()) startStopWorker(pendingStopReason);
    }

    private void startStopWorker(String reason) {
        if (finalized.get() || !stopperStarted.compareAndSet(false, true)) return;
        Thread stopper = new Thread(() -> stopInternal(reason), "LiteRecorderStop");
        stopper.start();
    }

    private void stopInternal(String reason) {
        boolean safeDrain = true;
        try {
            stopAudioRecords();
            if (videoCodec != null) {
                try { videoCodec.signalEndOfInputStream(); }
                catch (Exception error) { logger.error("RecorderVideo", sessionId, "Could not signal video EOS", error); safeDrain = false; }
            }
            safeDrain &= joinWorker(audioFeedThread, 2500L, "audio feed");
            safeDrain &= joinWorker(videoDrainThread, 5000L, "video drain");
            safeDrain &= joinWorker(audioDrainThread, 5000L, "audio drain");
            safeDrain &= videoEosSeen.get();
            if (audioCodec != null && !audioUnavailable.get() && audioTrack != -1) {
                safeDrain &= audioEosSeen.get();
            }

            try { if (virtualDisplay != null) virtualDisplay.release(); }
            catch (RuntimeException error) { logger.error("RecorderProjection", sessionId, "VirtualDisplay release failed", error); }
            virtualDisplay = null;
            try { projection.unregisterCallback(projectionCallback); }
            catch (RuntimeException error) { logger.warn("RecorderProjection", sessionId, "Callback unregister failed: " + error.getMessage()); }
            try { projection.stop(); }
            catch (RuntimeException error) { logger.warn("RecorderProjection", sessionId, "Projection stop failed: " + error.getMessage()); }

            releaseAudioRecords();
            releaseCodec(videoCodec, "video stop"); videoCodec = null;
            releaseCodec(audioCodec, "audio stop"); audioCodec = null;
            if (videoSurface != null) {
                try { videoSurface.release(); }
                catch (RuntimeException error) { logger.warn("RecorderVideo", sessionId, "Surface release failed: " + error.getMessage()); }
                videoSurface = null;
            }

            boolean muxerClosed = closeMuxer();
            closeOutputDescriptor();
            if (safeDrain && muxerClosed && muxerStarted && !fatalVideoError.get() && output != null) {
                try {
                    android.net.Uri uri = storage.publish(output, sessionId);
                    long size = storage.verifySize(output);
                    if (size <= 0L) throw new IOException("Published MP4 size could not be verified");
                    finish(new Result(true, uri, output.fileName, size, "Saved", sessionId));
                } catch (Exception error) {
                    storage.retainFailedTarget(output, sessionId, error);
                    finish(new Result(false, output.uri, output.fileName, storage.verifySize(output),
                            "Muxing finished but publication or file verification failed: " + error.getMessage(), sessionId));
                }
            } else {
                IOException error = new IOException("MP4 finalization did not complete cleanly; reason=" + reason);
                if (output != null) storage.retainFailedTarget(output, sessionId, error);
                finish(new Result(false, output == null ? null : output.uri,
                        output == null ? "" : output.fileName,
                        output == null ? 0L : storage.verifySize(output),
                        failureMessage == null ? error.getMessage() : failureMessage, sessionId));
            }
        } catch (Exception error) {
            logger.error("RecorderService", sessionId, "Stop/finalization failed", error);
            closeOutputDescriptor();
            if (output != null) storage.retainFailedTarget(output, sessionId, error);
            finish(new Result(false, output == null ? null : output.uri,
                    output == null ? "" : output.fileName,
                    output == null ? 0L : storage.verifySize(output),
                    error.getMessage(), sessionId));
        }
    }

    private boolean joinWorker(Thread thread, long timeoutMs, String label) {
        if (thread == null) return true;
        try {
            thread.join(timeoutMs);
            if (thread.isAlive()) {
                logger.error("RecorderPerformance", sessionId,
                        label + " thread did not terminate within " + timeoutMs + " ms", null);
                thread.interrupt();
                thread.join(1000L);
            }
            if (thread.isAlive()) {
                logger.error("RecorderPerformance", sessionId,
                        label + " thread remains alive; output will not be marked as successfully saved", null);
                return false;
            }
            return true;
        } catch (InterruptedException interrupted) {
            Thread.currentThread().interrupt();
            logger.warn("RecorderService", sessionId, "Interrupted while joining " + label + " thread");
            return false;
        }
    }

    private boolean closeMuxer() {
        boolean success = true;
        synchronized (muxerLock) {
            if (muxer != null && muxerStarted) {
                try { muxer.stop(); }
                catch (RuntimeException error) { success = false; logger.error("RecorderStorage", sessionId, "MediaMuxer.stop failed", error); }
            }
            if (muxer != null) {
                try { muxer.release(); }
                catch (RuntimeException error) { success = false; logger.error("RecorderStorage", sessionId, "MediaMuxer.release failed", error); }
                muxer = null;
            }
            muxerLock.notifyAll();
        }
        return success;
    }

    private void closeOutputDescriptor() {
        if (output != null && output.descriptor != null) {
            try { output.descriptor.close(); }
            catch (IOException error) { logger.warn("RecorderStorage", sessionId, "Output descriptor close failed: " + error.getMessage()); }
        }
    }

    private void failAndCleanup(Throwable error) {
        try { stopAudioRecords(); } catch (RuntimeException cleanupError) { logger.warn("RecorderAudio", sessionId, "Audio cleanup after startup error failed: " + cleanupError.getMessage()); }
        try { if (virtualDisplay != null) virtualDisplay.release(); }
        catch (RuntimeException cleanupError) { logger.warn("RecorderProjection", sessionId, "VirtualDisplay cleanup failed: " + cleanupError.getMessage()); }
        virtualDisplay = null;
        try { projection.unregisterCallback(projectionCallback); }
        catch (RuntimeException cleanupError) { logger.warn("RecorderProjection", sessionId, "Callback cleanup failed: " + cleanupError.getMessage()); }
        try { projection.stop(); }
        catch (RuntimeException cleanupError) { logger.warn("RecorderProjection", sessionId, "Projection cleanup failed: " + cleanupError.getMessage()); }
        releaseAudioRecords();
        releaseCodec(videoCodec, "startup failure"); videoCodec = null;
        releaseCodec(audioCodec, "startup failure"); audioCodec = null;
        if (videoSurface != null) { try { videoSurface.release(); } catch (RuntimeException ignored) { logger.warn("RecorderVideo", sessionId, "Input surface cleanup failed"); } videoSurface = null; }
        if (muxer != null) { try { muxer.release(); } catch (RuntimeException cleanupError) { logger.warn("RecorderStorage", sessionId, "Muxer cleanup failed: " + cleanupError.getMessage()); } muxer = null; }
        closeOutputDescriptor();
        if (output != null) storage.retainFailedTarget(output, sessionId, error);
        finish(new Result(false, output == null ? null : output.uri,
                output == null ? "" : output.fileName,
                output == null ? 0L : storage.verifySize(output),
                failureMessage == null ? "Recording startup failed" : failureMessage, sessionId));
    }

    private void finish(Result result) {
        if (!finalized.compareAndSet(false, true)) return;
        synchronized (muxerLock) { muxerLock.notifyAll(); }
        listener.onFinished(result);
    }

    private void requestVideoFailure(String message, Exception error) {
        failureMessage = message + (error == null ? "" : ": " + error.getMessage());
        fatalVideoError.set(true);
        logger.error("RecorderVideo", sessionId, message, error);
        synchronized (muxerLock) { muxerLock.notifyAll(); }
        requestStop("video_encoder_failure");
    }

    private void disableAudioPipeline(String reason, Throwable error) {
        if (!audioUnavailable.compareAndSet(false, true)) return;
        if (error == null) logger.warn("RecorderAudio", sessionId, reason);
        else logger.error("RecorderAudio", sessionId, reason, error);
        stopAudioRecords();
        synchronized (muxerLock) { maybeStartMuxerLocked(); muxerLock.notifyAll(); }
    }

    private void disableSource(boolean microphone, Throwable error) {
        if (microphone) {
            if (microphoneRecord != null) {
                try { microphoneRecord.stop(); } catch (RuntimeException stopError) { logger.warn("RecorderAudio", sessionId, "Microphone stop after source failure: " + stopError.getMessage()); }
                try { microphoneRecord.release(); } catch (RuntimeException releaseError) { logger.warn("RecorderAudio", sessionId, "Microphone release after source failure: " + releaseError.getMessage()); }
                microphoneRecord = null;
            }
        } else {
            if (systemRecord != null) {
                try { systemRecord.stop(); } catch (RuntimeException stopError) { logger.warn("RecorderAudio", sessionId, "Internal audio stop after source failure: " + stopError.getMessage()); }
                try { systemRecord.release(); } catch (RuntimeException releaseError) { logger.warn("RecorderAudio", sessionId, "Internal audio release after source failure: " + releaseError.getMessage()); }
                systemRecord = null;
            }
        }
        logger.error("RecorderAudio", sessionId, microphone ? "Microphone source disabled" : "Internal audio source disabled", error);
        if (microphoneRecord == null && systemRecord == null) disableAudioPipeline("No audio sources remain; video continues", error);
    }

    private boolean isAnyAudioSourceRecording() {
        return (microphoneRecord != null && microphoneRecord.getRecordingState() == AudioRecord.RECORDSTATE_RECORDING)
                || (systemRecord != null && systemRecord.getRecordingState() == AudioRecord.RECORDSTATE_RECORDING);
    }

    private void stopAudioRecords() {
        if (microphoneRecord != null) {
            try { if (microphoneRecord.getRecordingState() == AudioRecord.RECORDSTATE_RECORDING) microphoneRecord.stop(); }
            catch (RuntimeException error) { logger.warn("RecorderAudio", sessionId, "Microphone stop failed: " + error.getMessage()); }
        }
        if (systemRecord != null) {
            try { if (systemRecord.getRecordingState() == AudioRecord.RECORDSTATE_RECORDING) systemRecord.stop(); }
            catch (RuntimeException error) { logger.warn("RecorderAudio", sessionId, "Internal audio stop failed: " + error.getMessage()); }
        }
    }

    private void releaseAudioRecords() {
        if (microphoneRecord != null) {
            try { microphoneRecord.release(); }
            catch (RuntimeException error) { logger.warn("RecorderAudio", sessionId, "Microphone release failed: " + error.getMessage()); }
            microphoneRecord = null;
        }
        if (systemRecord != null) {
            try { systemRecord.release(); }
            catch (RuntimeException error) { logger.warn("RecorderAudio", sessionId, "Internal audio release failed: " + error.getMessage()); }
            systemRecord = null;
        }
    }

    private void releaseCodec(MediaCodec codec, String reason) {
        if (codec == null) return;
        try { codec.stop(); }
        catch (RuntimeException error) { logger.warn("RecorderVideo", sessionId, "Codec stop " + reason + ": " + error.getMessage()); }
        try { codec.release(); }
        catch (RuntimeException error) { logger.warn("RecorderVideo", sessionId, "Codec release " + reason + ": " + error.getMessage()); }
    }

    public boolean isStopRequested() { return stopRequested.get(); }
    public long getEncodedFrames() { return encodedFrames.get(); }
    public long getDroppedMuxerSamples() { return droppedMuxerSamples.get(); }
    public int getActiveFps() { return activeFps; }
    public long getAudioSamplesQueued() { return audioSamplesQueued.get(); }
    public int getVideoBitrate() { return activeBitrate; }
    public int getWidth() { return width; }
    public int getHeight() { return height; }
    public long getElapsedMs() {
        return startedAtNs == 0L ? 0L : Math.max(0L,
                (System.nanoTime() - startedAtNs - getPausedDurationNs()) / 1_000_000L);
    }
    public long getPausedDurationMs() { return getPausedDurationNs() / 1_000_000L; }
}
