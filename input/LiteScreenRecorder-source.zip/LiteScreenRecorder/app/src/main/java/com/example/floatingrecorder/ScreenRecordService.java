package com.example.floatingrecorder;

import android.Manifest;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.ServiceInfo;
import android.media.projection.MediaProjection;
import android.media.projection.MediaProjectionManager;
import android.os.Build;
import android.os.Handler;
import android.os.HandlerThread;
import android.os.IBinder;
import android.widget.Toast;

import java.util.UUID;
import java.util.concurrent.atomic.AtomicBoolean;

public final class ScreenRecordService extends Service {
    public static final String ACTION_START = "com.example.floatingrecorder.action.START";
    public static final String ACTION_STOP = "com.example.floatingrecorder.action.STOP";
    public static final String ACTION_PAUSE = "com.example.floatingrecorder.action.PAUSE";
    public static final String ACTION_RESUME = "com.example.floatingrecorder.action.RESUME";
    public static final String ACTION_STATE_CHANGED = "com.example.floatingrecorder.action.STATE_CHANGED";
    public static final String EXTRA_RESULT_CODE = "projection_result_code";
    public static final String EXTRA_PROJECTION_DATA = "projection_result_data";
    public static final String EXTRA_STATE = "recording_state";

    private static final int NOTIFICATION_ID = 5101;
    private static final String CHANNEL_ID = "lite_recording";
    private static volatile boolean recording;
    private static volatile boolean paused;
    private static volatile boolean preparing;
    private static volatile boolean stopping;

    private final AtomicBoolean startInProgress = new AtomicBoolean(false);
    private final AtomicBoolean stopRequestedDuringPreparation = new AtomicBoolean(false);
    private final Handler mainHandler = new Handler(android.os.Looper.getMainLooper());
    private HandlerThread workerThread;
    private Handler workerHandler;
    private RecordingEngine engine;
    private MediaProjection projection;
    private String currentSessionId;
    private int currentFps;
    private String currentResolution;

    public static boolean isRecording() { return recording; }
    public static boolean isPaused() { return paused; }
    public static boolean isPreparing() { return preparing; }

    @Override public void onCreate() {
        super.onCreate();
        createNotificationChannel();
        workerThread = new HandlerThread("LiteRecorderServiceWorker", android.os.Process.THREAD_PRIORITY_BACKGROUND);
        workerThread.start();
        workerHandler = new Handler(workerThread.getLooper());
        DiagnosticsLogger.get(this).info("RecorderService", "-", "Foreground service created");
    }

    @Override public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent == null) return START_NOT_STICKY;
        String action = intent.getAction();
        if (ACTION_STOP.equals(action)) {
            stopping = true;
            requestStop("notification_or_activity");
            if (engine != null || preparing || recording) updateNotification("جارٍ إنهاء التسجيل وحفظ الملف…");
            if (engine == null && !preparing && !recording) {
                stopForeground(true);
                stopSelf(startId);
            }
            return START_NOT_STICKY;
        }
        if (ACTION_PAUSE.equals(action)) {
            RecordingEngine current = engine;
            if (recording && !paused && current != null && current.pauseRecording()) {
                paused = true;
                updateNotification("Paused");
                sendState("PAUSED");
            }
            return START_NOT_STICKY;
        }
        if (ACTION_RESUME.equals(action)) {
            RecordingEngine current = engine;
            if (recording && paused && current != null && current.resumeRecording()) {
                paused = false;
                updateNotification("Recording");
                sendState("RECORDING");
            }
            return START_NOT_STICKY;
        }
        if (ACTION_START.equals(action)) {
            if (recording || preparing || !startInProgress.compareAndSet(false, true)) return START_NOT_STICKY;
            int resultCode = intent.getIntExtra(EXTRA_RESULT_CODE, -1);
            Intent projectionData = getProjectionIntent(intent);
            String audioMode = RecorderPreferences.audioMode(this);
            if (resultCode != android.app.Activity.RESULT_OK || projectionData == null) {
                startInProgress.set(false);
                abort("MediaProjection permission data is missing or invalid", null);
                return START_NOT_STICKY;
            }
            if (!RecorderPreferences.AUDIO_MUTE.equals(audioMode)
                    && checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
                startInProgress.set(false);
                abort("Audio permission is not granted", null);
                return START_NOT_STICKY;
            }
            if (Build.VERSION.SDK_INT < Build.VERSION_CODES.Q
                    && (RecorderPreferences.AUDIO_SYSTEM.equals(audioMode)
                    || RecorderPreferences.AUDIO_BOTH.equals(audioMode))) {
                DiagnosticsLogger.get(this).warn("RecorderAudio", "-",
                        "Internal playback capture is unavailable below Android 10; microphone-only fallback will be used where enabled");
                if (RecorderPreferences.AUDIO_SYSTEM.equals(audioMode)) audioMode = RecorderPreferences.AUDIO_MUTE;
                else audioMode = RecorderPreferences.AUDIO_MIC;
            }
            try {
                int foregroundType = ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION;
                if (RecorderPreferences.AUDIO_MIC.equals(audioMode) || RecorderPreferences.AUDIO_BOTH.equals(audioMode)) {
                    foregroundType |= ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE;
                }
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                    startForeground(NOTIFICATION_ID, buildNotification("Preparing screen capture…"), foregroundType);
                } else {
                    startForeground(NOTIFICATION_ID, buildNotification("Preparing screen capture…"));
                }
            } catch (Exception error) {
                startInProgress.set(false);
                abort("Could not start foreground recording service", error);
                return START_NOT_STICKY;
            }
            preparing = true;
            paused = false;
            stopping = false;
            sendState("PREPARING");
            final int safeResultCode = resultCode;
            final Intent safeProjectionData = projectionData;
            final String safeAudioMode = audioMode;
            workerHandler.post(() -> prepareRecording(safeResultCode, safeProjectionData, safeAudioMode));
        }
        return START_NOT_STICKY;
    }

    private void prepareRecording(int resultCode, Intent data, String audioMode) {
        try {
            currentSessionId = UUID.randomUUID().toString();
            currentResolution = RecorderPreferences.resolution(this);
            currentFps = Math.max(15, Math.min(60, RecorderPreferences.fps(this)));
            int[] display = readDisplaySize();
            int[] outputSize = calculateSize(currentResolution, display[0], display[1]);
            int effectiveBitrate = calculateBitrate(currentResolution, RecorderPreferences.bitrateMbps(this), currentFps);
            DiagnosticsLogger.get(this).setSessionContext(currentSessionId, currentResolution, currentFps,
                    effectiveBitrate, audioMode);

            MediaProjectionManager manager = (MediaProjectionManager) getSystemService(MEDIA_PROJECTION_SERVICE);
            projection = manager.getMediaProjection(resultCode, data);
            if (projection == null) throw new IllegalStateException("MediaProjection returned null");

            engine = new RecordingEngine(this, projection, outputSize[0], outputSize[1], currentFps,
                    effectiveBitrate, audioMode, currentSessionId,
                    result -> mainHandler.post(() -> handleFinished(result)));
            boolean started = engine.start();
            if (!started) return; // Engine reports the error through its completion callback.
            startInProgress.set(false);
            if (stopRequestedDuringPreparation.get() || engine.isStopRequested()) {
                engine.requestStop("stop_requested_during_preparation");
                return;
            }

            preparing = false;
            recording = true;
            paused = false;
            mainHandler.post(() -> {
                updateNotification("Recording");
                sendState("RECORDING");
            });
            DiagnosticsLogger.get(this).info("RecorderService", currentSessionId,
                    "Recording active; settings=" + engine.getWidth() + "x" + engine.getHeight() + "/" + engine.getActiveFps() +
                            "fps/" + effectiveBitrate + "bps; availableStorage=" + new StorageManager(this).availableBytes());
        } catch (Exception error) {
            DiagnosticsLogger.get(this).error("RecorderService", currentSessionId, "Service preparation failed", error);
            mainHandler.post(() -> abort("Could not prepare the recording session: " + error.getMessage(), error));
        }
    }

    private int[] readDisplaySize() {
        android.util.DisplayMetrics metrics = new android.util.DisplayMetrics();
        android.view.WindowManager manager = (android.view.WindowManager) getSystemService(WINDOW_SERVICE);
        if (manager != null) {
            @SuppressWarnings("deprecation") android.view.Display display = manager.getDefaultDisplay();
            if (display != null) display.getRealMetrics(metrics);
        }
        if (metrics.widthPixels <= 0 || metrics.heightPixels <= 0) {
            metrics = getResources().getDisplayMetrics();
        }
        return new int[]{Math.max(2, metrics.widthPixels), Math.max(2, metrics.heightPixels)};
    }

    private int[] calculateSize(String resolution, int screenWidth, int screenHeight) {
        int limit;
        if (RecorderPreferences.RES_480.equals(resolution)) limit = 480;
        else if (RecorderPreferences.RES_1080.equals(resolution)) limit = 1080;
        else limit = 720;
        double scale = Math.min(1.0d, limit / (double) Math.max(screenWidth, screenHeight));
        int width = even((int) Math.floor(screenWidth * scale));
        int height = even((int) Math.floor(screenHeight * scale));
        return new int[]{Math.max(2, width), Math.max(2, height)};
    }

    private int even(int value) { return value % 2 == 0 ? value : value - 1; }

    private int calculateBitrate(String resolution, int requestedMbps, int fps) {
        int cap = RecorderPreferences.RES_480.equals(resolution) ? 4
                : RecorderPreferences.RES_720.equals(resolution) ? 8 : 12;
        int selected = Math.max(2, Math.min(cap, requestedMbps));
        if (fps >= 60) selected = Math.min(cap, (int) Math.ceil(selected * 1.2d));
        return selected * 1_000_000;
    }

    private void requestStop(String reason) {
        if (preparing && startInProgress.get()) {
            stopRequestedDuringPreparation.set(true);
            DiagnosticsLogger.get(this).info("RecorderService", currentSessionId,
                    "Stop queued while engine startup is in progress; reason=" + reason);
            return;
        }
        RecordingEngine current = engine;
        if (current != null) current.requestStop(reason);
    }

    private void handleFinished(RecordingEngine.Result result) {
        recording = false;
        paused = false;
        preparing = false;
        stopping = false;
        startInProgress.set(false);
        if (result.success && result.uri != null) {
            RecorderPreferences.setLastRecording(this, result.uri.toString(), result.fileName, result.sizeBytes);
            updateNotification("Saved • " + result.fileName);
            Toast.makeText(this, "Saved: " + result.fileName, Toast.LENGTH_LONG).show();
            DiagnosticsLogger.get(this).info("RecorderStorage", result.sessionId,
                    "Recording completed; name=" + result.fileName + "; bytes=" + result.sizeBytes + "; uri=" + result.uri);
            sendState("SAVED");
        } else {
            updateNotification("Recording not finalized; diagnostics saved");
            Toast.makeText(this, "Recording could not be finalized. Review Diagnostics.", Toast.LENGTH_LONG).show();
            DiagnosticsLogger.get(this).warn("RecorderStorage", result.sessionId,
                    "Recording not published; message=" + result.message + "; bytes=" + result.sizeBytes);
            sendState("ERROR");
        }
        engine = null;
        projection = null;
        DiagnosticsLogger.get(this).clearSessionContext();
        mainHandler.postDelayed(() -> {
            stopForeground(true);
            stopSelf();
        }, 1500L);
    }

    private void abort(String message, Throwable error) {
        preparing = false;
        recording = false;
        paused = false;
        stopping = false;
        startInProgress.set(false);
        if (engine != null) {
            engine.requestStop("service_abort");
            return;
        }
        DiagnosticsLogger.get(this).error("RecorderService", currentSessionId, message, error);
        DiagnosticsLogger.get(this).clearSessionContext();
        try { Toast.makeText(getApplicationContext(), message, Toast.LENGTH_LONG).show(); }
        catch (RuntimeException toastError) { DiagnosticsLogger.get(this).warn("RecorderService", currentSessionId, "Could not display error toast: " + toastError.getMessage()); }
        try { stopForeground(true); }
        catch (RuntimeException foregroundError) { DiagnosticsLogger.get(this).warn("RecorderService", currentSessionId, "stopForeground failed: " + foregroundError.getMessage()); }
        sendState("ERROR");
        stopSelf();
    }

    private void sendState(String state) {
        Intent stateIntent = new Intent(ACTION_STATE_CHANGED);
        stateIntent.setPackage(getPackageName());
        stateIntent.putExtra(EXTRA_STATE, state);
        sendBroadcast(stateIntent);
    }

    private void updateNotification(String text) {
        NotificationManager manager = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
        if (manager != null) manager.notify(NOTIFICATION_ID, buildNotification(text));
    }

    private Notification buildNotification(String text) {
        Intent openIntent = new Intent(this, MainActivity.class).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP);
        PendingIntent openPending = PendingIntent.getActivity(this, 5103, openIntent,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        Notification.Builder builder = Build.VERSION.SDK_INT >= Build.VERSION_CODES.O
                ? new Notification.Builder(this, CHANNEL_ID) : new Notification.Builder(this);
        builder.setSmallIcon(android.R.drawable.presence_video_online)
                .setContentTitle("Lite Screen Recorder")
                .setContentText(text)
                .setContentIntent(openPending)
                .setOngoing(recording || preparing || stopping || (text != null && text.startsWith("Preparing")))
                .setOnlyAlertOnce(true)
                .setCategory(Notification.CATEGORY_SERVICE);

        if (recording && !paused) {
            long elapsed = engine == null ? 0L : engine.getElapsedMs();
            builder.setWhen(System.currentTimeMillis() - elapsed).setUsesChronometer(true);
        } else {
            builder.setUsesChronometer(false);
            if (recording && paused && engine != null) {
                builder.setContentText("متوقف مؤقتًا • " + formatDuration(engine.getElapsedMs()));
            }
        }

        if (recording && !stopping) {
            String action = paused ? ACTION_RESUME : ACTION_PAUSE;
            String label = paused ? "استئناف" : "إيقاف مؤقت";
            int icon = paused ? android.R.drawable.ic_media_play : android.R.drawable.ic_media_pause;
            Intent controlIntent = new Intent(this, ScreenRecordService.class).setAction(action);
            PendingIntent controlPending = PendingIntent.getService(this, 5104,
                    controlIntent, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
            builder.addAction(new Notification.Action.Builder(icon, label, controlPending).build());
        }

        if ((recording || preparing) && !stopping) {
            Intent stopIntent = new Intent(this, ScreenRecordService.class).setAction(ACTION_STOP);
            PendingIntent stopPending = PendingIntent.getService(this, 5102, stopIntent,
                    PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
            builder.addAction(new Notification.Action.Builder(
                    android.R.drawable.ic_menu_close_clear_cancel, "إنهاء وحفظ", stopPending).build());
        }
        return builder.build();
    }

    private String formatDuration(long millis) {
        long seconds = Math.max(0L, millis / 1000L);
        return String.format(java.util.Locale.US, "%02d:%02d:%02d",
                seconds / 3600L, (seconds / 60L) % 60L, seconds % 60L);
    }

    private void createNotificationChannel() {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) return;
        NotificationChannel channel = new NotificationChannel(CHANNEL_ID,
                "Screen recording", NotificationManager.IMPORTANCE_LOW);
        channel.setDescription("Status and stop control for screen recording");
        channel.setShowBadge(false);
        channel.setSound(null, null);
        NotificationManager manager = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
        if (manager != null) manager.createNotificationChannel(channel);
    }

    @SuppressWarnings("deprecation")
    private Intent getProjectionIntent(Intent intent) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            return intent.getParcelableExtra(EXTRA_PROJECTION_DATA, Intent.class);
        }
        return intent.getParcelableExtra(EXTRA_PROJECTION_DATA);
    }

    @Override public void onDestroy() {
        if (engine != null && (recording || preparing)) engine.requestStop("service_destroyed");
        if (workerThread != null) workerThread.quitSafely();
        DiagnosticsLogger.get(this).info("RecorderService", currentSessionId, "Foreground service destroyed");
        super.onDestroy();
    }

    @Override public IBinder onBind(Intent intent) { return null; }

}
