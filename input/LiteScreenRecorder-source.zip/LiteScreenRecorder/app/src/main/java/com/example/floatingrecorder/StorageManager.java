package com.example.floatingrecorder;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.media.MediaMuxer;
import android.net.Uri;
import android.os.Build;
import android.os.Environment;
import android.os.ParcelFileDescriptor;
import android.provider.MediaStore;

import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicReference;

/** Owns a single recording output target. Segment/session recovery is scheduled for V1.5. */
public final class StorageManager {
    public static final class OutputTarget {
        public final Uri uri;
        public final File file;
        public final ParcelFileDescriptor descriptor;
        public final String fileName;
        private OutputTarget(Uri uri, File file, ParcelFileDescriptor descriptor, String fileName) {
            this.uri = uri; this.file = file; this.descriptor = descriptor; this.fileName = fileName;
        }
        public MediaMuxer createMuxer() throws IOException {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                if (descriptor == null) throw new IOException("MediaStore file descriptor is missing");
                return new MediaMuxer(descriptor.getFileDescriptor(), MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4);
            }
            if (file == null) throw new IOException("Legacy output file is missing");
            return new MediaMuxer(file.getAbsolutePath(), MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4);
        }
    }

    private final Context context;
    private final DiagnosticsLogger logger;

    public StorageManager(Context context) {
        this.context = context.getApplicationContext();
        this.logger = DiagnosticsLogger.get(context);
    }

    public OutputTarget createOutput(String sessionId) throws IOException {
        String timestamp = new SimpleDateFormat("yyyy-MM-dd_HH-mm-ss", Locale.US).format(new Date());
        String fileName = "Recording_" + timestamp + "_" + sessionId.substring(0, Math.min(6, sessionId.length())) + ".mp4";
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            ContentValues values = new ContentValues();
            values.put(MediaStore.Video.Media.DISPLAY_NAME, fileName);
            values.put(MediaStore.Video.Media.MIME_TYPE, "video/mp4");
            values.put(MediaStore.Video.Media.RELATIVE_PATH, Environment.DIRECTORY_MOVIES + "/LiteScreenRecorder/");
            values.put(MediaStore.Video.Media.IS_PENDING, 1);
            Uri uri = context.getContentResolver().insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, values);
            if (uri == null) throw new IOException("MediaStore insert returned null");
            try {
                ParcelFileDescriptor pfd = context.getContentResolver().openFileDescriptor(uri, "rw");
                if (pfd == null) throw new IOException("MediaStore returned a null file descriptor");
                logger.info("Storage", sessionId, "Created pending MediaStore target: " + uri);
                return new OutputTarget(uri, null, pfd, fileName);
            } catch (IOException | RuntimeException error) {
                try { context.getContentResolver().delete(uri, null, null); }
                catch (RuntimeException cleanupError) {
                    logger.error("Storage", "-", "Could not remove MediaStore row after output-open failure", cleanupError);
                }
                if (error instanceof IOException) throw (IOException) error;
                throw new IOException("Could not open MediaStore output", error);
            }
        }

        File movies = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_MOVIES);
        File folder = new File(movies, "LiteScreenRecorder");
        if (!folder.exists() && !folder.mkdirs()) throw new IOException("Could not create Movies/LiteScreenRecorder");
        File target = new File(folder, fileName);
        if (!target.createNewFile()) throw new IOException("Output file already exists");
        logger.info("Storage", sessionId, "Created legacy output: " + target.getAbsolutePath());
        return new OutputTarget(null, target, null, fileName);
    }

    public long verifySize(OutputTarget target) {
        if (target.file != null) return target.file.length();
        if (target.uri == null) return -1L;
        try (Cursor cursor = context.getContentResolver().query(target.uri,
                new String[]{MediaStore.Video.Media.SIZE}, null, null, null)) {
            if (cursor != null && cursor.moveToFirst()) return cursor.getLong(0);
        } catch (RuntimeException error) {
            logger.warn("Storage", "-", "Could not query output size: " + error.getClass().getSimpleName());
        }
        return -1L;
    }

    public Uri publish(OutputTarget target, String sessionId) throws IOException {
        long size = verifySize(target);
        if (size <= 0L) throw new IOException("Output file has no verified data");
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            ContentValues values = new ContentValues();
            values.put(MediaStore.Video.Media.IS_PENDING, 0);
            int changed = context.getContentResolver().update(target.uri, values, null, null);
            if (changed <= 0) throw new IOException("MediaStore could not publish completed output");
            logger.info("Storage", sessionId, "Published file; bytes=" + size + "; uri=" + target.uri);
            return target.uri;
        }
        CountDownLatch latch = new CountDownLatch(1);
        AtomicReference<Uri> scannedUri = new AtomicReference<>();
        android.media.MediaScannerConnection.scanFile(context,
                new String[]{target.file.getAbsolutePath()}, new String[]{"video/mp4"},
                (path, contentUri) -> { scannedUri.set(contentUri); latch.countDown(); });
        try {
            if (!latch.await(5L, TimeUnit.SECONDS) || scannedUri.get() == null) {
                throw new IOException("Media scanner did not return a content URI within 5 seconds");
            }
        } catch (InterruptedException interrupted) {
            Thread.currentThread().interrupt();
            throw new IOException("Interrupted while publishing legacy recording", interrupted);
        }
        logger.info("Storage", sessionId, "Legacy file indexed; bytes=" + size + "; path=" + target.file.getAbsolutePath() + "; uri=" + scannedUri.get());
        return scannedUri.get();
    }

    /** Failed pending outputs are kept for the V1.5 recovery scanner; they are not silently deleted. */
    public void retainFailedTarget(OutputTarget target, String sessionId, Throwable reason) {
        long size = verifySize(target);
        logger.error("Storage", sessionId,
                "Output was not published and has been retained for recovery review. bytes=" + size +
                        "; uri=" + target.uri + "; file=" + (target.file == null ? "-" : target.file.getAbsolutePath()), reason);
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.Q && target.file != null && target.file.exists()) {
            File renamed = new File(target.file.getParentFile(), "INCOMPLETE_" + target.file.getName());
            if (!target.file.renameTo(renamed)) logger.warn("Storage", sessionId, "Could not rename incomplete output");
        }
    }

    public long availableBytes() {
        try {
            File base = Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q
                    ? context.getExternalFilesDir(null) : Environment.getExternalStorageDirectory();
            if (base == null) return -1L;
            android.os.StatFs stat = new android.os.StatFs(base.getAbsolutePath());
            return stat.getAvailableBytes();
        } catch (RuntimeException error) {
            logger.warn("Storage", "-", "Could not read available storage: " + error.getClass().getSimpleName());
            return -1L;
        }
    }
}
