package com.example.floatingrecorder;

import android.Manifest;
import android.app.Activity;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.PackageManager;
import android.media.projection.MediaProjectionManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.DocumentsContract;
import android.view.Gravity;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import java.text.DecimalFormat;
import java.util.ArrayList;

/** Small native UI: recording settings, start, and last-file access. Runtime controls live in the notification. */
public final class MainActivity extends Activity {
    private static final int REQUEST_CAPTURE = 7001;
    private static final int REQUEST_PERMISSIONS = 7002;
    private static final int REQUEST_FOLDER = 7003;

    private final Handler handler = new Handler(Looper.getMainLooper());
    private TextView statusText;
    private TextView folderText;
    private TextView lastFileText;
    private Button startButton;
    private Spinner resolutionSpinner;
    private Spinner fpsSpinner;
    private Spinner bitrateSpinner;
    private Spinner audioSpinner;
    private boolean pendingStartAfterPermissions;
    private boolean receiverRegistered;

    private final BroadcastReceiver stateReceiver = new BroadcastReceiver() {
        @Override public void onReceive(Context context, Intent intent) {
            refreshStatus();
            refreshLastRecording();
        }
    };

    private final Runnable statusRefresh = new Runnable() {
        @Override public void run() {
            refreshStatus();
            if (!isFinishing() && (ScreenRecordService.isRecording() || ScreenRecordService.isPreparing())) {
                handler.postDelayed(this, 1000L);
            }
        }
    };

    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(0xFFF4F6FA);
        getWindow().setNavigationBarColor(0xFFF4F6FA);
        getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR);
        setContentView(buildUi());
        restorePreferences();
        refreshStatus();
        refreshLastRecording();
        refreshFolderText();
    }

    private View buildUi() {
        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        scroll.setBackgroundColor(0xFFF4F6FA);

        LinearLayout content = new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        content.setPadding(dp(18), dp(20), dp(18), dp(28));
        content.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        scroll.addView(content);

        TextView title = text("Lite Screen Recorder", 25, true, 0xFF111827);
        content.addView(title, fullParams(0));
        TextView subtitle = text("مسجل شاشة بسيط وخفيف", 14, false, 0xFF64748B);
        subtitle.setPadding(0, dp(4), 0, dp(16));
        content.addView(subtitle, fullParams(0));

        LinearLayout statusCard = card();
        statusText = text("جاهز للتسجيل", 17, true, 0xFF0F172A);
        statusText.setPadding(dp(14), dp(15), dp(14), dp(15));
        statusCard.addView(statusText, fullParams(0));
        content.addView(statusCard, fullParams(dp(10)));

        content.addView(section("جودة الفيديو"), fullParams(dp(14)));
        resolutionSpinner = spinner(new String[]{"480p", "720p", "1080p"});
        addLabeledSpinner(content, "الدقة", resolutionSpinner);
        fpsSpinner = spinner(new String[]{"15 FPS", "24 FPS", "30 FPS", "60 FPS"});
        addLabeledSpinner(content, "معدل الإطارات", fpsSpinner);
        bitrateSpinner = spinner(new String[]{"2 Mbps", "4 Mbps", "6 Mbps", "8 Mbps", "12 Mbps"});
        addLabeledSpinner(content, "معدل البت", bitrateSpinner);

        content.addView(section("الصوت"), fullParams(dp(12)));
        audioSpinner = spinner(new String[]{"صوت الجهاز الداخلي", "الجهاز + الميكروفون", "الميكروفون فقط", "بدون صوت"});
        addLabeledSpinner(content, "مصدر الصوت", audioSpinner);
        TextView audioNote = text("التقاط صوت الجهاز يتطلب Android 10 أو أحدث، وقد تمنعه بعض التطبيقات.", 12, false, 0xFF64748B);
        audioNote.setPadding(dp(4), dp(5), dp(4), dp(4));
        content.addView(audioNote, fullParams(0));

        content.addView(section("مكان الحفظ"), fullParams(dp(12)));
        folderText = text("المجلد الافتراضي: Movies/LiteScreenRecorder", 13, false, 0xFF475569);
        folderText.setPadding(dp(12), dp(10), dp(12), dp(10));
        content.addView(folderText, fullParams(0));
        LinearLayout folderButtons = new LinearLayout(this);
        folderButtons.setOrientation(LinearLayout.HORIZONTAL);
        Button chooseFolder = button("اختيار مجلد");
        chooseFolder.setOnClickListener(v -> chooseFolder());
        Button defaultFolder = button("الافتراضي");
        defaultFolder.setOnClickListener(v -> resetFolder());
        folderButtons.addView(chooseFolder, new LinearLayout.LayoutParams(0, dp(48), 1f));
        folderButtons.addView(defaultFolder, new LinearLayout.LayoutParams(0, dp(48), 1f));
        content.addView(folderButtons, fullParams(dp(5)));

        startButton = button("بدء تسجيل الشاشة");
        startButton.setTextSize(17);
        startButton.setOnClickListener(v -> onStartClicked());
        content.addView(startButton, fullParams(dp(18)));

        TextView notificationHint = text("بعد بدء التسجيل، استخدم الإشعار للإيقاف المؤقت أو الاستئناف أو إنهاء التسجيل وحفظه.", 12, false, 0xFF64748B);
        notificationHint.setPadding(dp(8), dp(8), dp(8), dp(4));
        content.addView(notificationHint, fullParams(0));

        content.addView(section("آخر تسجيل"), fullParams(dp(14)));
        LinearLayout fileCard = card();
        lastFileText = text("لا يوجد تسجيل محفوظ بعد", 14, false, 0xFF334155);
        lastFileText.setPadding(dp(12), dp(12), dp(12), dp(12));
        fileCard.addView(lastFileText, fullParams(0));
        LinearLayout fileButtons = new LinearLayout(this);
        fileButtons.setOrientation(LinearLayout.HORIZONTAL);
        Button openButton = button("فتح الفيديو");
        openButton.setOnClickListener(v -> openLastRecording());
        Button shareButton = button("مشاركة");
        shareButton.setOnClickListener(v -> shareLastRecording());
        fileButtons.addView(openButton, new LinearLayout.LayoutParams(0, dp(48), 1f));
        fileButtons.addView(shareButton, new LinearLayout.LayoutParams(0, dp(48), 1f));
        fileCard.addView(fileButtons, fullParams(dp(6)));
        content.addView(fileCard, fullParams(0));

        return scroll;
    }

    private void restorePreferences() {
        setSpinnerValue(resolutionSpinner, RecorderPreferences.resolution(this));
        setSpinnerValue(fpsSpinner, RecorderPreferences.fps(this) + " FPS");
        setSpinnerValue(bitrateSpinner, RecorderPreferences.bitrateMbps(this) + " Mbps");
        setSpinnerValue(audioSpinner, audioLabel(RecorderPreferences.audioMode(this)));
        android.widget.AdapterView.OnItemSelectedListener listener = new android.widget.AdapterView.OnItemSelectedListener() {
            @Override public void onItemSelected(android.widget.AdapterView<?> parent, View view, int position, long id) {
                savePreferences();
            }
            @Override public void onNothingSelected(android.widget.AdapterView<?> parent) { }
        };
        resolutionSpinner.setOnItemSelectedListener(listener);
        fpsSpinner.setOnItemSelectedListener(listener);
        bitrateSpinner.setOnItemSelectedListener(listener);
        audioSpinner.setOnItemSelectedListener(listener);
    }

    private void savePreferences() {
        if (resolutionSpinner == null || fpsSpinner == null || bitrateSpinner == null || audioSpinner == null) return;
        RecorderPreferences.setResolution(this, (String) resolutionSpinner.getSelectedItem());
        RecorderPreferences.setFps(this, parseNumber((String) fpsSpinner.getSelectedItem(), 30));
        RecorderPreferences.setBitrateMbps(this, parseNumber((String) bitrateSpinner.getSelectedItem(), 4));
        RecorderPreferences.setAudioMode(this, audioModeForLabel((String) audioSpinner.getSelectedItem()));
    }

    private void onStartClicked() {
        if (ScreenRecordService.isRecording() || ScreenRecordService.isPreparing()) {
            Toast.makeText(this, "استخدم إشعار التسجيل للتحكم الحالي", Toast.LENGTH_SHORT).show();
            return;
        }
        savePreferences();
        requestStartPermissions();
    }

    private void requestStartPermissions() {
        ArrayList<String> needed = new ArrayList<>();
        String audio = RecorderPreferences.audioMode(this);
        boolean needsAudioPermission = !RecorderPreferences.AUDIO_MUTE.equals(audio);
        if (needsAudioPermission && Build.VERSION.SDK_INT >= Build.VERSION_CODES.M
                && checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            needed.add(Manifest.permission.RECORD_AUDIO);
        }
        if (Build.VERSION.SDK_INT <= Build.VERSION_CODES.P
                && RecorderPreferences.folderTreeUri(this) == null
                && checkSelfPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
            needed.add(Manifest.permission.WRITE_EXTERNAL_STORAGE);
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU
                && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            needed.add(Manifest.permission.POST_NOTIFICATIONS);
        }
        if (!needed.isEmpty()) {
            pendingStartAfterPermissions = true;
            requestPermissions(needed.toArray(new String[0]), REQUEST_PERMISSIONS);
        } else {
            launchProjectionConsent();
        }
    }

    private void launchProjectionConsent() {
        try {
            MediaProjectionManager manager = (MediaProjectionManager) getSystemService(MEDIA_PROJECTION_SERVICE);
            startActivityForResult(manager.createScreenCaptureIntent(), REQUEST_CAPTURE);
        } catch (RuntimeException error) {
            DiagnosticsLogger.get(this).error("MainActivity", "-", "Could not launch screen capture consent", error);
            Toast.makeText(this, "تعذر فتح إذن تسجيل الشاشة", Toast.LENGTH_LONG).show();
        }
    }

    private void chooseFolder() {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) {
            Toast.makeText(this, "اختيار مجلد مخصص يتطلب Android 8 أو أحدث", Toast.LENGTH_LONG).show();
            return;
        }
        Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT_TREE);
        intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION
                | Intent.FLAG_GRANT_WRITE_URI_PERMISSION
                | Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);
        try { startActivityForResult(intent, REQUEST_FOLDER); }
        catch (RuntimeException error) { Toast.makeText(this, "تعذر فتح اختيار المجلد", Toast.LENGTH_LONG).show(); }
    }

    private void resetFolder() {
        String old = RecorderPreferences.folderTreeUri(this);
        if (old != null) {
            try { getContentResolver().releasePersistableUriPermission(Uri.parse(old),
                    Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_WRITE_URI_PERMISSION); }
            catch (RuntimeException ignored) { }
        }
        RecorderPreferences.setFolderTreeUri(this, null);
        refreshFolderText();
        Toast.makeText(this, "تمت استعادة مجلد الحفظ الافتراضي", Toast.LENGTH_SHORT).show();
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQUEST_CAPTURE) {
            if (resultCode != RESULT_OK || data == null) {
                Toast.makeText(this, "تم إلغاء إذن تسجيل الشاشة", Toast.LENGTH_SHORT).show();
                return;
            }
            Intent serviceIntent = new Intent(this, ScreenRecordService.class)
                    .setAction(ScreenRecordService.ACTION_START)
                    .putExtra(ScreenRecordService.EXTRA_RESULT_CODE, resultCode)
                    .putExtra(ScreenRecordService.EXTRA_PROJECTION_DATA, data);
            try {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) startForegroundService(serviceIntent);
                else startService(serviceIntent);
            } catch (RuntimeException error) {
                DiagnosticsLogger.get(this).error("MainActivity", "-", "Could not start recording service", error);
                Toast.makeText(this, "تعذر بدء خدمة التسجيل", Toast.LENGTH_LONG).show();
            }
        } else if (requestCode == REQUEST_FOLDER && resultCode == RESULT_OK && data != null && data.getData() != null) {
            Uri treeUri = data.getData();
            try {
                int flags = data.getFlags() & (Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_WRITE_URI_PERMISSION);
                getContentResolver().takePersistableUriPermission(treeUri, flags);
                RecorderPreferences.setFolderTreeUri(this, treeUri.toString());
                refreshFolderText();
                Toast.makeText(this, "تم تعيين مجلد الحفظ", Toast.LENGTH_SHORT).show();
            } catch (RuntimeException error) {
                Toast.makeText(this, "تعذر حفظ صلاحية المجلد المختار", Toast.LENGTH_LONG).show();
            }
        }
    }

    @Override public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == REQUEST_PERMISSIONS && pendingStartAfterPermissions) {
            pendingStartAfterPermissions = false;
            boolean allGranted = grantResults.length > 0;
            for (int result : grantResults) allGranted &= result == PackageManager.PERMISSION_GRANTED;
            if (allGranted) launchProjectionConsent();
            else Toast.makeText(this, "يجب منح الصلاحيات اللازمة لبدء التسجيل والتحكم من الإشعار", Toast.LENGTH_LONG).show();
        }
    }

    private void refreshStatus() {
        if (statusText == null) return;
        boolean recording = ScreenRecordService.isRecording();
        boolean preparing = ScreenRecordService.isPreparing();
        boolean paused = ScreenRecordService.isPaused();
        if (paused) statusText.setText("التسجيل متوقف مؤقتًا\nيمكنك استئنافه من الإشعار.");
        else if (recording) statusText.setText("● التسجيل جارٍ\nالتحكم متاح من الإشعار.");
        else if (preparing) statusText.setText("جارٍ تجهيز تسجيل الشاشة…");
        else statusText.setText("جاهز للتسجيل");
        startButton.setEnabled(!recording && !preparing);
        startButton.setText(recording || preparing ? "افتح الإشعار للتحكم" : "بدء تسجيل الشاشة");
    }

    private void refreshFolderText() {
        if (folderText == null) return;
        String tree = RecorderPreferences.folderTreeUri(this);
        if (tree == null) {
            folderText.setText("المجلد الافتراضي: Movies/LiteScreenRecorder");
            return;
        }
        String label = "مجلد مخصص محدد";
        try {
            Uri uri = Uri.parse(tree);
            String documentId = DocumentsContract.getTreeDocumentId(uri);
            String path = documentId == null ? "" : documentId.replace(':', '/');
            if (!path.trim().isEmpty()) label = "مجلد الحفظ: " + path;
        } catch (RuntimeException ignored) { }
        folderText.setText(label);
    }

    private void refreshLastRecording() {
        if (lastFileText == null) return;
        String name = RecorderPreferences.lastName(this);
        String uri = RecorderPreferences.lastUri(this);
        if (name == null || uri == null) lastFileText.setText("لا يوجد تسجيل محفوظ بعد");
        else lastFileText.setText(name + "\n" + formatBytes(RecorderPreferences.lastSize(this)) + " • MP4");
    }

    private void openLastRecording() {
        String value = RecorderPreferences.lastUri(this);
        if (value == null) return;
        try {
            Intent intent = new Intent(Intent.ACTION_VIEW).setDataAndType(Uri.parse(value), "video/mp4")
                    .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
            startActivity(intent);
        } catch (RuntimeException error) {
            Toast.makeText(this, "تعذر فتح الفيديو أو لا يوجد مشغل مناسب", Toast.LENGTH_LONG).show();
        }
    }

    private void shareLastRecording() {
        String value = RecorderPreferences.lastUri(this);
        if (value == null) return;
        try {
            Intent send = new Intent(Intent.ACTION_SEND).setType("video/mp4")
                    .putExtra(Intent.EXTRA_STREAM, Uri.parse(value))
                    .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
            startActivity(Intent.createChooser(send, "مشاركة التسجيل"));
        } catch (RuntimeException error) {
            Toast.makeText(this, "تعذر مشاركة التسجيل", Toast.LENGTH_LONG).show();
        }
    }

    @Override protected void onResume() {
        super.onResume();
        refreshStatus();
        refreshLastRecording();
        refreshFolderText();
        IntentFilter filter = new IntentFilter(ScreenRecordService.ACTION_STATE_CHANGED);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) registerReceiver(stateReceiver, filter, Context.RECEIVER_NOT_EXPORTED);
        else registerReceiver(stateReceiver, filter);
        receiverRegistered = true;
        handler.removeCallbacks(statusRefresh);
        if (ScreenRecordService.isRecording() || ScreenRecordService.isPreparing()) handler.post(statusRefresh);
    }

    @Override protected void onPause() {
        handler.removeCallbacks(statusRefresh);
        if (receiverRegistered) {
            try { unregisterReceiver(stateReceiver); }
            catch (IllegalArgumentException ignored) { }
            receiverRegistered = false;
        }
        super.onPause();
    }

    private Spinner spinner(String[] items) {
        Spinner spinner = new Spinner(this);
        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, items);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner.setAdapter(adapter);
        return spinner;
    }

    private void addLabeledSpinner(LinearLayout parent, String label, Spinner spinner) {
        TextView caption = text(label, 13, true, 0xFF475569);
        caption.setPadding(dp(4), dp(5), dp(4), dp(1));
        parent.addView(caption, fullParams(0));
        parent.addView(spinner, fullParams(dp(44)));
    }

    private LinearLayout card() {
        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.VERTICAL);
        layout.setPadding(dp(10), dp(8), dp(10), dp(8));
        layout.setBackground(roundRect(0xFFFFFFFF, 16));
        return layout;
    }

    private LinearLayout section(String value) {
        LinearLayout panel = new LinearLayout(this);
        panel.setOrientation(LinearLayout.HORIZONTAL);
        TextView label = text(value, 17, true, 0xFF0F172A);
        label.setPadding(dp(2), dp(8), dp(2), dp(2));
        panel.addView(label);
        return panel;
    }

    private TextView text(String value, int size, boolean bold, int color) {
        TextView view = new TextView(this);
        view.setText(value);
        view.setTextSize(size);
        view.setTextColor(color);
        if (bold) view.setTypeface(android.graphics.Typeface.DEFAULT, android.graphics.Typeface.BOLD);
        view.setGravity(Gravity.RIGHT | Gravity.CENTER_VERTICAL);
        view.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        return view;
    }

    private Button button(String label) {
        Button button = new Button(this);
        button.setText(label);
        button.setAllCaps(false);
        button.setTextColor(0xFFFFFFFF);
        button.setBackground(roundRect(0xFF2563EB, 14));
        button.setPadding(dp(8), 0, dp(8), 0);
        return button;
    }

    private android.graphics.drawable.GradientDrawable roundRect(int color, int radiusDp) {
        android.graphics.drawable.GradientDrawable drawable = new android.graphics.drawable.GradientDrawable();
        drawable.setColor(color);
        drawable.setCornerRadius(dp(radiusDp));
        return drawable;
    }

    private LinearLayout.LayoutParams fullParams(int topMargin) {
        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        params.topMargin = topMargin;
        return params;
    }

    private int dp(int value) { return (int) (value * getResources().getDisplayMetrics().density + 0.5f); }

    private void setSpinnerValue(Spinner spinner, String value) {
        if (spinner == null) return;
        for (int i = 0; i < spinner.getCount(); i++) {
            if (value.equals(spinner.getItemAtPosition(i).toString())) { spinner.setSelection(i, false); return; }
        }
    }

    private int parseNumber(String value, int fallback) {
        try { return Integer.parseInt(value.replaceAll("[^0-9]", "")); }
        catch (RuntimeException error) { return fallback; }
    }

    private String audioLabel(String value) {
        if (RecorderPreferences.AUDIO_MIC.equals(value)) return "الميكروفون فقط";
        if (RecorderPreferences.AUDIO_BOTH.equals(value)) return "الجهاز + الميكروفون";
        if (RecorderPreferences.AUDIO_SYSTEM.equals(value)) return "صوت الجهاز الداخلي";
        return "بدون صوت";
    }

    private String audioModeForLabel(String value) {
        if ("الميكروفون فقط".equals(value)) return RecorderPreferences.AUDIO_MIC;
        if ("الجهاز + الميكروفون".equals(value)) return RecorderPreferences.AUDIO_BOTH;
        if ("صوت الجهاز الداخلي".equals(value)) return RecorderPreferences.AUDIO_SYSTEM;
        return RecorderPreferences.AUDIO_MUTE;
    }

    private String formatBytes(long bytes) {
        if (bytes < 0) return "غير متاح";
        if (bytes < 1024) return bytes + " B";
        double value = bytes;
        String[] units = {"B", "KB", "MB", "GB", "TB"};
        int unit = 0;
        while (value >= 1024 && unit < units.length - 1) { value /= 1024; unit++; }
        return new DecimalFormat("0.0").format(value) + " " + units[unit];
    }
}
