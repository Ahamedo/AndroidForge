package com.example.floatingrecorder;

import android.Manifest;
import android.app.Activity;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.PackageManager;
import android.media.projection.MediaProjectionManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.view.Gravity;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import java.io.OutputStream;
import java.text.DecimalFormat;

public final class MainActivity extends Activity {
    private static final int REQUEST_CAPTURE = 7001;
    private static final int REQUEST_PERMISSIONS = 7002;
    private static final int REQUEST_EXPORT_LOGS = 7003;

    private final Handler handler = new Handler(Looper.getMainLooper());
    private TextView statusText;
    private TextView permissionText;
    private TextView lastFileText;
    private TextView storageText;
    private Button startStopButton;
    private Spinner resolutionSpinner;
    private Spinner fpsSpinner;
    private Spinner bitrateSpinner;
    private Spinner audioSpinner;
    private Spinner bubbleSizeSpinner;
    private Spinner bubbleColorSpinner;
    private Spinner shakeSensitivitySpinner;
    private CheckBox lowResourceCheck;
    private CheckBox shakeCheck;
    private boolean pendingStartAfterPermissions;
    private boolean receiverRegistered;

    private final BroadcastReceiver stateReceiver = new BroadcastReceiver() {
        @Override public void onReceive(Context context, Intent intent) {
            refreshStatus();
            refreshLastRecording();
        }
    };

    private final Runnable statusRefresh = new Runnable() {
        @Override public void run() {
            if (!isFinishing()) {
                refreshStatus();
                handler.postDelayed(this, 1000L);
            }
        }
    };

    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(0xFFF4F6FA);
        getWindow().setNavigationBarColor(0xFFF4F6FA);
        getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR);
        setContentView(buildUi());
        restorePreferences();
        refreshStatus();
        refreshLastRecording();
        requestNotificationPermissionIfNeeded();
        DiagnosticsLogger.get(this).info("MainActivity", "-", "Activity created");
    }

    private View buildUi() {
        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        scroll.setBackgroundColor(0xFFF4F6FA);
        LinearLayout content = new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        content.setPadding(dp(18), dp(18), dp(18), dp(28));
        content.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        scroll.addView(content);

        TextView title = text("Lite Screen Recorder", 26, true, 0xFF111827);
        content.addView(title, fullParams(0));
        TextView subtitle = text("مسجل شاشة خفيف — إصدار التشخيص 1.3", 14, false, 0xFF64748B);
        subtitle.setPadding(0, dp(5), 0, dp(15));
        content.addView(subtitle, fullParams(0));

        LinearLayout statusCard = card();
        statusText = text("Ready", 18, true, 0xFF0F172A);
        statusText.setPadding(dp(14), dp(14), dp(14), dp(14));
        statusCard.addView(statusText, fullParams(0));
        content.addView(statusCard, fullParams(dp(10)));

        content.addView(section("إعدادات الفيديو"), fullParams(dp(10)));
        resolutionSpinner = spinner(new String[]{"480p", "720p", "1080p"});
        addLabeledSpinner(content, "الدقة", resolutionSpinner);
        fpsSpinner = spinner(new String[]{"30 FPS", "60 FPS", "90 FPS"});
        addLabeledSpinner(content, "معدل الإطارات المطلوب", fpsSpinner);
        bitrateSpinner = spinner(new String[]{"2 Mbps", "4 Mbps", "6 Mbps", "8 Mbps", "12 Mbps"});
        addLabeledSpinner(content, "معدل البت", bitrateSpinner);

        lowResourceCheck = new CheckBox(this);
        lowResourceCheck.setText("وضع الموارد المنخفضة (480p / 30 FPS / 2 Mbps / بدون صوت)");
        lowResourceCheck.setTextColor(0xFF334155);
        lowResourceCheck.setOnCheckedChangeListener((button, checked) -> {
            if (checked) {
                setSpinnerValue(resolutionSpinner, "480p");
                setSpinnerValue(fpsSpinner, "30 FPS");
                setSpinnerValue(bitrateSpinner, "2 Mbps");
                setSpinnerValue(audioSpinner, "صامت");
                savePreferences();
            }
        });
        content.addView(lowResourceCheck, fullParams(dp(6)));

        content.addView(section("الصوت"), fullParams(dp(10)));
        audioSpinner = spinner(new String[]{"صامت", "صوت النظام الداخلي", "النظام + الميكروفون", "الميكروفون فقط"});
        addLabeledSpinner(content, "مصدر الصوت", audioSpinner);
        TextView audioNote = text("صوت التطبيقات يعتمد على سماح التطبيق المصدر بالتقاط Playback Audio، ولا يمكن ضمان تسجيل التطبيقات التي تمنعه. الصوت الداخلي يتطلب Android 10 أو أحدث.", 12, false, 0xFF64748B);
        audioNote.setPadding(dp(12), dp(8), dp(12), dp(8));
        content.addView(audioNote, fullParams(dp(4)));

        content.addView(section("الكرة العائمة"), fullParams(dp(10)));
        bubbleSizeSpinner = spinner(new String[]{"48 dp", "56 dp", "64 dp", "80 dp", "96 dp"});
        addLabeledSpinner(content, "حجم الكرة", bubbleSizeSpinner);
        bubbleColorSpinner = spinner(new String[]{"أحمر", "أزرق", "أخضر", "بنفسجي"});
        addLabeledSpinner(content, "لون الكرة", bubbleColorSpinner);
        shakeCheck = new CheckBox(this);
        shakeCheck.setText("السماح بالإيقاف عند هز الجهاز (يستهلك قدراً إضافياً من الحساس)");
        shakeCheck.setTextColor(0xFF334155);
        content.addView(shakeCheck, fullParams(dp(4)));
        shakeSensitivitySpinner = spinner(new String[]{"منخفضة", "متوسطة", "مرتفعة"});
        addLabeledSpinner(content, "حساسية الإيقاف بالهز", shakeSensitivitySpinner);

        content.addView(section("الصلاحيات والتخزين"), fullParams(dp(10)));
        permissionText = text("جارٍ فحص الصلاحيات…", 13, false, 0xFF334155);
        permissionText.setPadding(dp(12), dp(10), dp(12), dp(10));
        content.addView(permissionText, fullParams(0));
        Button overlayButton = button("إعداد إذن الكرة العائمة");
        overlayButton.setOnClickListener(v -> openOverlaySettings());
        content.addView(overlayButton, fullParams(dp(6)));
        storageText = text("المساحة المتاحة: —", 13, false, 0xFF64748B);
        content.addView(storageText, fullParams(dp(4)));

        startStopButton = button("بدء التسجيل");
        startStopButton.setTextSize(17);
        startStopButton.setOnClickListener(v -> onStartStopClicked());
        content.addView(startStopButton, fullParams(dp(16)));

        content.addView(section("آخر تسجيل"), fullParams(dp(14)));
        LinearLayout fileCard = card();
        lastFileText = text("لا يوجد تسجيل محفوظ بعد", 14, false, 0xFF334155);
        lastFileText.setPadding(dp(12), dp(12), dp(12), dp(12));
        fileCard.addView(lastFileText, fullParams(0));
        LinearLayout fileButtons = new LinearLayout(this);
        fileButtons.setOrientation(LinearLayout.HORIZONTAL);
        Button openButton = button("فتح");
        openButton.setOnClickListener(v -> openLastRecording());
        Button shareButton = button("مشاركة");
        shareButton.setOnClickListener(v -> shareLastRecording());
        fileButtons.addView(openButton, new LinearLayout.LayoutParams(0, dp(48), 1f));
        fileButtons.addView(shareButton, new LinearLayout.LayoutParams(0, dp(48), 1f));
        fileCard.addView(fileButtons, fullParams(dp(6)));
        content.addView(fileCard, fullParams(0));

        content.addView(section("Diagnostics"), fullParams(dp(14)));
        TextView diagnosticInfo = text("يُسجل التطبيق قياسات RAM وCPU والحرارة والمساحة كل 30 ثانية أثناء التسجيل. تُحفظ السجلات محلياً مع تدوير محدود للحجم.", 12, false, 0xFF64748B);
        diagnosticInfo.setPadding(dp(12), dp(8), dp(12), dp(8));
        content.addView(diagnosticInfo, fullParams(0));
        Button exportButton = button("Export Logs — تصدير تقرير TXT");
        exportButton.setOnClickListener(v -> exportLogs());
        content.addView(exportButton, fullParams(dp(6)));

        return scroll;
    }

    private void restorePreferences() {
        setSpinnerValue(resolutionSpinner, RecorderPreferences.resolution(this));
        setSpinnerValue(fpsSpinner, RecorderPreferences.fps(this) + " FPS");
        setSpinnerValue(bitrateSpinner, RecorderPreferences.bitrateMbps(this) + " Mbps");
        setSpinnerValue(audioSpinner, audioLabel(RecorderPreferences.audioMode(this)));
        setSpinnerValue(bubbleSizeSpinner, RecorderPreferences.bubbleSize(this) + " dp");
        setSpinnerValue(bubbleColorSpinner, bubbleColorLabel(RecorderPreferences.bubbleColor(this)));
        setSpinnerValue(shakeSensitivitySpinner, shakeSensitivityLabel(RecorderPreferences.shakeSensitivity(this)));
        shakeCheck.setChecked(RecorderPreferences.shakeEnabled(this));
        lowResourceCheck.setChecked(RecorderPreferences.RES_480.equals(RecorderPreferences.resolution(this))
                && RecorderPreferences.fps(this) == 30 && RecorderPreferences.bitrateMbps(this) <= 2
                && RecorderPreferences.AUDIO_MUTE.equals(RecorderPreferences.audioMode(this)));
        resolutionSpinner.setOnItemSelectedListener(simpleListener(this::savePreferences));
        fpsSpinner.setOnItemSelectedListener(simpleListener(this::savePreferences));
        bitrateSpinner.setOnItemSelectedListener(simpleListener(this::savePreferences));
        audioSpinner.setOnItemSelectedListener(simpleListener(this::savePreferences));
        bubbleSizeSpinner.setOnItemSelectedListener(simpleListener(this::savePreferences));
        bubbleColorSpinner.setOnItemSelectedListener(simpleListener(this::savePreferences));
        shakeSensitivitySpinner.setOnItemSelectedListener(simpleListener(this::savePreferences));
        shakeCheck.setOnCheckedChangeListener((button, checked) -> RecorderPreferences.setShakeEnabled(this, checked));
    }

    private android.widget.AdapterView.OnItemSelectedListener simpleListener(Runnable action) {
        return new android.widget.AdapterView.OnItemSelectedListener() {
            @Override public void onItemSelected(android.widget.AdapterView<?> parent, View view, int position, long id) { action.run(); }
            @Override public void onNothingSelected(android.widget.AdapterView<?> parent) { }
        };
    }

    private void savePreferences() {
        if (resolutionSpinner == null || fpsSpinner == null || bitrateSpinner == null || audioSpinner == null) return;
        RecorderPreferences.setResolution(this, (String) resolutionSpinner.getSelectedItem());
        RecorderPreferences.setFps(this, parseNumber((String) fpsSpinner.getSelectedItem(), 30));
        RecorderPreferences.setBitrateMbps(this, parseNumber((String) bitrateSpinner.getSelectedItem(), 4));
        RecorderPreferences.setAudioMode(this, audioModeForLabel((String) audioSpinner.getSelectedItem()));
        RecorderPreferences.setBubbleSize(this, parseNumber((String) bubbleSizeSpinner.getSelectedItem(), 56));
        RecorderPreferences.setBubbleColor(this, bubbleColorForLabel((String) bubbleColorSpinner.getSelectedItem()));
        if (shakeCheck != null) RecorderPreferences.setShakeEnabled(this, shakeCheck.isChecked());
        if (shakeSensitivitySpinner != null) {
            RecorderPreferences.setShakeSensitivity(this, shakeSensitivityForLabel((String) shakeSensitivitySpinner.getSelectedItem()));
        }
    }

    private void onStartStopClicked() {
        if (ScreenRecordService.isRecording()) {
            new ScreenRecordService.ContextBridge(this).stop();
            return;
        }
        if (ScreenRecordService.isPreparing()) {
            Toast.makeText(this, "يتم تجهيز التسجيل بالفعل", Toast.LENGTH_SHORT).show();
            return;
        }
        savePreferences();
        if (!Settings.canDrawOverlays(this)) {
            Toast.makeText(this, "اسمح بالظهور فوق التطبيقات أولاً", Toast.LENGTH_LONG).show();
            openOverlaySettings();
            return;
        }
        requestStartPermissions();
    }

    private void requestStartPermissions() {
        java.util.ArrayList<String> needed = new java.util.ArrayList<>();
        String audio = RecorderPreferences.audioMode(this);
        if (!RecorderPreferences.AUDIO_MUTE.equals(audio)
                && Build.VERSION.SDK_INT >= Build.VERSION_CODES.M
                && checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            needed.add(Manifest.permission.RECORD_AUDIO);
        }
        if (Build.VERSION.SDK_INT <= Build.VERSION_CODES.P
                && checkSelfPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
            needed.add(Manifest.permission.WRITE_EXTERNAL_STORAGE);
        }
        if (!needed.isEmpty()) {
            pendingStartAfterPermissions = true;
            requestPermissions(needed.toArray(new String[0]), REQUEST_PERMISSIONS);
        } else {
            launchProjectionConsent();
        }
    }

    private void launchProjectionConsent() {
        try {
            MediaProjectionManager manager = (MediaProjectionManager) getSystemService(MEDIA_PROJECTION_SERVICE);
            startActivityForResult(manager.createScreenCaptureIntent(), REQUEST_CAPTURE);
        } catch (RuntimeException error) {
            DiagnosticsLogger.get(this).error("MainActivity", "-", "Could not launch MediaProjection consent", error);
            Toast.makeText(this, "تعذر فتح إذن تسجيل الشاشة", Toast.LENGTH_LONG).show();
        }
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQUEST_CAPTURE) {
            if (resultCode != RESULT_OK || data == null) {
                Toast.makeText(this, "تم إلغاء إذن تسجيل الشاشة", Toast.LENGTH_SHORT).show();
                return;
            }
            // Hide the overlay before requesting capture so its pixels cannot enter the first frames.
            try { startService(new Intent(this, FloatingControlService.class).setAction(FloatingControlService.ACTION_HIDE)); }
            catch (RuntimeException overlayError) { DiagnosticsLogger.get(this).warn("Overlay", "-", "Pre-capture overlay hide request failed: " + overlayError.getMessage()); }
            Intent serviceIntent = new Intent(this, ScreenRecordService.class)
                    .setAction(ScreenRecordService.ACTION_START)
                    .putExtra(ScreenRecordService.EXTRA_RESULT_CODE, resultCode)
                    .putExtra(ScreenRecordService.EXTRA_PROJECTION_DATA, data);
            try {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) startForegroundService(serviceIntent);
                else startService(serviceIntent);
            } catch (RuntimeException error) {
                DiagnosticsLogger.get(this).error("MainActivity", "-", "Could not start recording service", error);
                Toast.makeText(this, "تعذر بدء خدمة التسجيل", Toast.LENGTH_LONG).show();
            }
        } else if (requestCode == REQUEST_EXPORT_LOGS && resultCode == RESULT_OK && data != null && data.getData() != null) {
            saveLogExport(data.getData());
        }
    }

    @Override public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == REQUEST_PERMISSIONS && pendingStartAfterPermissions) {
            pendingStartAfterPermissions = false;
            boolean allGranted = grantResults.length > 0;
            for (int result : grantResults) allGranted &= result == PackageManager.PERMISSION_GRANTED;
            if (allGranted) launchProjectionConsent();
            else Toast.makeText(this, "لم تُمنح جميع الصلاحيات المطلوبة", Toast.LENGTH_LONG).show();
        }
    }

    private void requestNotificationPermissionIfNeeded() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU
                && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, 8001);
        }
    }

    private void openOverlaySettings() {
        try {
            Intent intent = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:" + getPackageName()));
            startActivity(intent);
        } catch (RuntimeException error) {
            DiagnosticsLogger.get(this).error("MainActivity", "-", "Could not open overlay settings", error);
            Toast.makeText(this, "تعذر فتح إعدادات الكرة العائمة", Toast.LENGTH_LONG).show();
        }
    }

    private void refreshStatus() {
        if (statusText == null) return;
        boolean recording = ScreenRecordService.isRecording();
        boolean preparing = ScreenRecordService.isPreparing();
        if (recording) statusText.setText("● RECORDING — التسجيل جارٍ\nيمكنك الإيقاف من الإشعار أو زر الإيقاف.");
        else if (preparing) statusText.setText("PREPARING — جارٍ تجهيز MediaProjection والمرمّز…");
        else statusText.setText("READY — جاهز للتسجيل");
        startStopButton.setText(recording ? "إيقاف وحفظ التسجيل" : preparing ? "جارٍ التجهيز…" : "بدء التسجيل");
        startStopButton.setEnabled(!preparing);
        boolean overlay = Settings.canDrawOverlays(this);
        boolean audioPermission = RecorderPreferences.AUDIO_MUTE.equals(RecorderPreferences.audioMode(this))
                || Build.VERSION.SDK_INT < Build.VERSION_CODES.M
                || checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED;
        permissionText.setText("الكرة العائمة: " + (overlay ? "مسموح" : "غير مسموح")
                + "\nإذن الصوت: " + (audioPermission ? "مسموح/غير مطلوب" : "غير ممنوح"));
    }

    private void refreshStorage() {
        if (storageText == null) return;
        long available = new StorageManager(this).availableBytes();
        storageText.setText("المساحة المتاحة: " + formatBytes(available)
                + "\nمجلد الحفظ: Movies/LiteScreenRecorder");
    }

    private void refreshLastRecording() {
        if (lastFileText == null) return;
        String name = RecorderPreferences.lastName(this);
        String uri = RecorderPreferences.lastUri(this);
        if (name == null || uri == null) lastFileText.setText("لا يوجد تسجيل محفوظ بعد");
        else lastFileText.setText(name + "\n" + formatBytes(RecorderPreferences.lastSize(this)) + " • MP4");
    }

    private void openLastRecording() {
        String value = RecorderPreferences.lastUri(this);
        if (value == null) return;
        try {
            Intent intent = new Intent(Intent.ACTION_VIEW).setDataAndType(Uri.parse(value), "video/mp4")
                    .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
            startActivity(intent);
        } catch (RuntimeException error) {
            DiagnosticsLogger.get(this).error("MainActivity", "-", "Could not open last recording", error);
            Toast.makeText(this, "تعذر فتح الفيديو أو لا يوجد مشغل مناسب", Toast.LENGTH_LONG).show();
        }
    }

    private void shareLastRecording() {
        String value = RecorderPreferences.lastUri(this);
        if (value == null) return;
        try {
            Intent send = new Intent(Intent.ACTION_SEND).setType("video/mp4")
                    .putExtra(Intent.EXTRA_STREAM, Uri.parse(value))
                    .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
            startActivity(Intent.createChooser(send, "مشاركة التسجيل"));
        } catch (RuntimeException error) {
            DiagnosticsLogger.get(this).error("MainActivity", "-", "Could not share last recording", error);
            Toast.makeText(this, "تعذر مشاركة التسجيل", Toast.LENGTH_LONG).show();
        }
    }

    private void exportLogs() {
        Intent intent = new Intent(Intent.ACTION_CREATE_DOCUMENT)
                .addCategory(Intent.CATEGORY_OPENABLE)
                .setType("text/plain")
                .putExtra(Intent.EXTRA_TITLE, "LiteScreenRecorder_Diagnostics.txt");
        try { startActivityForResult(intent, REQUEST_EXPORT_LOGS); }
        catch (RuntimeException error) {
            DiagnosticsLogger.get(this).error("Diagnostics", "-", "Could not open save dialog for logs", error);
            Toast.makeText(this, "تعذر فتح نافذة حفظ التقرير", Toast.LENGTH_LONG).show();
        }
    }

    private void saveLogExport(Uri destination) {
        try (OutputStream output = getContentResolver().openOutputStream(destination, "w")) {
            if (output == null) throw new java.io.IOException("Could not open destination");
            DiagnosticsLogger.get(this).exportTo(output);
            Toast.makeText(this, "تم تصدير تقرير التشخيص", Toast.LENGTH_LONG).show();
        } catch (Exception error) {
            DiagnosticsLogger.get(this).error("Diagnostics", "-", "Log export failed", error);
            Toast.makeText(this, "فشل تصدير التقرير", Toast.LENGTH_LONG).show();
        }
    }

    @Override protected void onResume() {
        super.onResume();
        savePreferences();
        refreshStatus();
        refreshLastRecording();
        refreshStorage();
        handler.removeCallbacks(statusRefresh);
        handler.post(statusRefresh);
        if (!ScreenRecordService.isRecording() && !ScreenRecordService.isPreparing() && Settings.canDrawOverlays(this)) {
            startService(new Intent(this, FloatingControlService.class).setAction(FloatingControlService.ACTION_SHOW));
        }
        IntentFilter filter = new IntentFilter(ScreenRecordService.ACTION_STATE_CHANGED);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) registerReceiver(stateReceiver, filter, Context.RECEIVER_NOT_EXPORTED);
        else registerReceiver(stateReceiver, filter);
        receiverRegistered = true;
    }

    @Override protected void onPause() {
        handler.removeCallbacks(statusRefresh);
        if (receiverRegistered) {
            try { unregisterReceiver(stateReceiver); }
            catch (IllegalArgumentException error) { DiagnosticsLogger.get(this).warn("MainActivity", "-", "State receiver was already unregistered"); }
            receiverRegistered = false;
        }
        super.onPause();
    }

    private Spinner spinner(String[] items) {
        Spinner spinner = new Spinner(this);
        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, items);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner.setAdapter(adapter);
        return spinner;
    }

    private void addLabeledSpinner(LinearLayout parent, String label, Spinner spinner) {
        TextView caption = text(label, 13, true, 0xFF475569);
        caption.setPadding(dp(4), dp(5), dp(4), dp(1));
        parent.addView(caption, fullParams(0));
        parent.addView(spinner, fullParams(dp(44)));
    }

    private LinearLayout card() {
        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.VERTICAL);
        layout.setPadding(dp(10), dp(7), dp(10), dp(7));
        layout.setBackground(roundRect(0xFFFFFFFF, 16));
        return layout;
    }

    private LinearLayout section(String value) {
        LinearLayout panel = new LinearLayout(this);
        panel.setOrientation(LinearLayout.HORIZONTAL);
        TextView label = text(value, 17, true, 0xFF0F172A);
        label.setPadding(dp(2), dp(8), dp(2), dp(2));
        panel.addView(label);
        return panel;
    }

    private TextView text(String value, int size, boolean bold, int color) {
        TextView view = new TextView(this);
        view.setText(value);
        view.setTextSize(size);
        view.setTextColor(color);
        if (bold) view.setTypeface(android.graphics.Typeface.DEFAULT, android.graphics.Typeface.BOLD);
        view.setGravity(Gravity.RIGHT | Gravity.CENTER_VERTICAL);
        view.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        return view;
    }

    private Button button(String label) {
        Button button = new Button(this);
        button.setText(label);
        button.setAllCaps(false);
        button.setTextColor(0xFFFFFFFF);
        button.setBackground(roundRect(0xFF2563EB, 14));
        button.setPadding(dp(8), 0, dp(8), 0);
        return button;
    }

    private android.graphics.drawable.GradientDrawable roundRect(int color, int radiusDp) {
        android.graphics.drawable.GradientDrawable drawable = new android.graphics.drawable.GradientDrawable();
        drawable.setColor(color);
        drawable.setCornerRadius(dp(radiusDp));
        return drawable;
    }

    private LinearLayout.LayoutParams fullParams(int topMargin) {
        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        params.topMargin = topMargin;
        return params;
    }

    private int dp(int value) { return (int) (value * getResources().getDisplayMetrics().density + 0.5f); }

    private void setSpinnerValue(Spinner spinner, String value) {
        if (spinner == null) return;
        for (int i = 0; i < spinner.getCount(); i++) {
            if (value.equals(spinner.getItemAtPosition(i).toString())) { spinner.setSelection(i, false); return; }
        }
    }

    private int parseNumber(String value, int fallback) {
        try { return Integer.parseInt(value.replaceAll("[^0-9]", "")); }
        catch (RuntimeException error) { return fallback; }
    }

    private String audioLabel(String value) {
        if (RecorderPreferences.AUDIO_MIC.equals(value)) return "الميكروفون فقط";
        if (RecorderPreferences.AUDIO_BOTH.equals(value)) return "النظام + الميكروفون";
        if (RecorderPreferences.AUDIO_SYSTEM.equals(value)) return "صوت النظام الداخلي";
        return "صامت";
    }

    private String audioModeForLabel(String value) {
        if ("الميكروفون فقط".equals(value)) return RecorderPreferences.AUDIO_MIC;
        if ("النظام + الميكروفون".equals(value)) return RecorderPreferences.AUDIO_BOTH;
        if ("صوت النظام الداخلي".equals(value)) return RecorderPreferences.AUDIO_SYSTEM;
        return RecorderPreferences.AUDIO_MUTE;
    }

    private String bubbleColorLabel(String value) {
        if ("blue".equals(value)) return "أزرق";
        if ("green".equals(value)) return "أخضر";
        if ("purple".equals(value)) return "بنفسجي";
        return "أحمر";
    }

    private String bubbleColorForLabel(String value) {
        if ("أزرق".equals(value)) return "blue";
        if ("أخضر".equals(value)) return "green";
        if ("بنفسجي".equals(value)) return "purple";
        return "red";
    }

    private String shakeSensitivityLabel(String value) {
        if ("low".equals(value)) return "منخفضة";
        if ("high".equals(value)) return "مرتفعة";
        return "متوسطة";
    }

    private String shakeSensitivityForLabel(String value) {
        if ("منخفضة".equals(value)) return "low";
        if ("مرتفعة".equals(value)) return "high";
        return "medium";
    }

    private String formatBytes(long bytes) {
        if (bytes < 0) return "غير متاح";
        if (bytes < 1024) return bytes + " B";
        double value = bytes;
        String[] units = {"B", "KB", "MB", "GB", "TB"};
        int unit = 0;
        while (value >= 1024 && unit < units.length - 1) { value /= 1024; unit++; }
        return new DecimalFormat("0.0").format(value) + " " + units[unit];
    }
}
