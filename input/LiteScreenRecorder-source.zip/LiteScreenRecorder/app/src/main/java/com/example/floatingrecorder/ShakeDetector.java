package com.example.floatingrecorder;

import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.os.SystemClock;

/** Optional accelerometer stop shortcut. Normal sensor rate keeps background wakeups modest. */
public final class ShakeDetector implements SensorEventListener {
    private final SensorManager sensorManager;
    private final Runnable callback;
    private final Sensor sensor;
    private final float threshold;
    private float lastMagnitude = SensorManager.GRAVITY_EARTH;
    private boolean initialized;
    private long lastShakeAt;

    public ShakeDetector(SensorManager sensorManager, Runnable callback, float threshold) {
        this.sensorManager = sensorManager;
        this.callback = callback;
        this.threshold = Math.max(8.0f, Math.min(24.0f, threshold));
        this.sensor = sensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER);
    }

    public boolean start() {
        if (sensor == null) return false;
        return sensorManager.registerListener(this, sensor, SensorManager.SENSOR_DELAY_NORMAL);
    }

    public void stop() { sensorManager.unregisterListener(this); }

    @Override public void onSensorChanged(SensorEvent event) {
        if (event.sensor.getType() != Sensor.TYPE_ACCELEROMETER) return;
        float x = event.values[0], y = event.values[1], z = event.values[2];
        float magnitude = (float) Math.sqrt(x * x + y * y + z * z);
        if (!initialized) {
            lastMagnitude = magnitude;
            initialized = true;
            return;
        }
        float delta = Math.abs(magnitude - lastMagnitude);
        lastMagnitude = magnitude;
        long now = SystemClock.elapsedRealtime();
        if (delta >= threshold && now - lastShakeAt >= 1800L) {
            lastShakeAt = now;
            callback.run();
        }
    }

    @Override public void onAccuracyChanged(Sensor sensor, int accuracy) { }
}
