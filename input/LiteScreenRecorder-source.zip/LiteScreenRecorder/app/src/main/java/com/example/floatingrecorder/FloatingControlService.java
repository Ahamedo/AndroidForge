package com.example.floatingrecorder;

import android.app.Service;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.graphics.drawable.GradientDrawable;
import android.os.Build;
import android.os.IBinder;
import android.provider.Settings;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.TextView;

public final class FloatingControlService extends Service {
    public static final String ACTION_SHOW = "com.example.floatingrecorder.overlay.SHOW";
    public static final String ACTION_HIDE = "com.example.floatingrecorder.overlay.HIDE";

    private WindowManager windowManager;
    private TextView bubble;
    private WindowManager.LayoutParams layoutParams;

    @Override public void onCreate() {
        super.onCreate();
        windowManager = (WindowManager) getSystemService(WINDOW_SERVICE);
    }

    @Override public int onStartCommand(Intent intent, int flags, int startId) {
        String action = intent == null ? ACTION_SHOW : intent.getAction();
        if (ACTION_HIDE.equals(action)) hideBubble();
        else showBubble();
        return START_NOT_STICKY;
    }

    private void showBubble() {
        if (bubble != null || !Settings.canDrawOverlays(this)) return;
        int size = dp(Math.max(48, Math.min(96, RecorderPreferences.bubbleSize(this))));
        int type = Build.VERSION.SDK_INT >= Build.VERSION_CODES.O
                ? WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
                : WindowManager.LayoutParams.TYPE_PHONE;
        // Deliberately no FLAG_SECURE: the bubble is hidden during capture instead of creating
        // a secure black rectangle in the captured display.
        layoutParams = new WindowManager.LayoutParams(size, size, type,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE | WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
                PixelFormat.TRANSLUCENT);
        layoutParams.gravity = Gravity.TOP | Gravity.START;
        layoutParams.x = dp(12);
        layoutParams.y = dp(180);
        bubble = new TextView(this);
        bubble.setText("●");
        bubble.setTextColor(Color.WHITE);
        bubble.setTextSize(21f);
        bubble.setGravity(Gravity.CENTER);
        bubble.setAlpha(RecorderPreferences.bubbleOpacity(this));
        bubble.setBackground(background());
        bubble.setContentDescription("Lite Screen Recorder");
        attachTouchHandler();
        try {
            windowManager.addView(bubble, layoutParams);
        } catch (RuntimeException error) {
            DiagnosticsLogger.get(this).error("Overlay", "-", "Could not add floating bubble", error);
            bubble = null;
            layoutParams = null;
        }
    }

    private void attachTouchHandler() {
        final float[] down = new float[2];
        final int[] origin = new int[2];
        final boolean[] moved = new boolean[1];
        bubble.setOnTouchListener((view, event) -> {
            switch (event.getActionMasked()) {
                case MotionEvent.ACTION_DOWN:
                    down[0] = event.getRawX(); down[1] = event.getRawY();
                    origin[0] = layoutParams.x; origin[1] = layoutParams.y; moved[0] = false;
                    return true;
                case MotionEvent.ACTION_MOVE:
                    float dx = event.getRawX() - down[0], dy = event.getRawY() - down[1];
                    if (Math.abs(dx) > dp(5) || Math.abs(dy) > dp(5)) moved[0] = true;
                    layoutParams.x = origin[0] + Math.round(dx);
                    layoutParams.y = origin[1] + Math.round(dy);
                    clamp();
                    try { windowManager.updateViewLayout(bubble, layoutParams); }
                    catch (RuntimeException error) { DiagnosticsLogger.get(this).warn("Overlay", "-", "Bubble position update failed: " + error.getMessage()); }
                    return true;
                case MotionEvent.ACTION_UP:
                    if (!moved[0]) openMainActivity();
                    return true;
                default: return true;
            }
        });
    }

    private void clamp() {
        android.util.DisplayMetrics metrics = getResources().getDisplayMetrics();
        int size = layoutParams.width;
        layoutParams.x = Math.max(0, Math.min(layoutParams.x, metrics.widthPixels - size));
        layoutParams.y = Math.max(0, Math.min(layoutParams.y, metrics.heightPixels - size));
    }

    private GradientDrawable background() {
        int color;
        switch (RecorderPreferences.bubbleColor(this)) {
            case "blue": color = Color.rgb(37, 99, 235); break;
            case "green": color = Color.rgb(22, 163, 74); break;
            case "purple": color = Color.rgb(124, 58, 237); break;
            default: color = Color.rgb(220, 38, 55); break;
        }
        GradientDrawable drawable = new GradientDrawable();
        drawable.setShape(GradientDrawable.OVAL);
        drawable.setColor(color);
        drawable.setStroke(dp(2), Color.WHITE);
        return drawable;
    }

    private void openMainActivity() {
        Intent intent = new Intent(this, MainActivity.class);
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_SINGLE_TOP);
        try { startActivity(intent); }
        catch (RuntimeException error) { DiagnosticsLogger.get(this).error("Overlay", "-", "Could not open main activity", error); }
    }

    private void hideBubble() {
        if (bubble != null) {
            try { windowManager.removeView(bubble); }
            catch (RuntimeException error) { DiagnosticsLogger.get(this).warn("Overlay", "-", "Bubble removal failed: " + error.getMessage()); }
            bubble = null;
            layoutParams = null;
        }
        stopSelf();
    }

    private int dp(int value) { return (int) (value * getResources().getDisplayMetrics().density + 0.5f); }

    @Override public void onDestroy() {
        hideBubble();
        super.onDestroy();
    }

    @Override public IBinder onBind(Intent intent) { return null; }
}
