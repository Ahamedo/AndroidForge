package com.example.floatingrecorder;

import android.content.Context;
import android.os.Build;
import android.os.Debug;
import android.os.StatFs;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

/** Small, bounded, append-only diagnostic log. Never logs captured screen/audio content. */
public final class DiagnosticsLogger {
    public static final String TAG = "LiteScreenRecorder";
    private static final long MAX_FILE_BYTES = 1024L * 1024L;
    private static final int BACKUP_COUNT = 3;
    private static volatile DiagnosticsLogger instance;

    private final Context appContext;
    private final File directory;
    private final File currentFile;
    private final Object lock = new Object();
    private volatile String activeSessionContext = "not-recording";

    private DiagnosticsLogger(Context context) {
        this.appContext = context.getApplicationContext();
        this.directory = new File(appContext.getFilesDir(), "diagnostics");
        this.currentFile = new File(directory, "lite-recorder.log");
        if (!directory.exists() && !directory.mkdirs()) {
            android.util.Log.e(TAG, "Could not create diagnostics directory: " + directory);
        }
    }

    public static DiagnosticsLogger get(Context context) {
        if (instance == null) {
            synchronized (DiagnosticsLogger.class) {
                if (instance == null) instance = new DiagnosticsLogger(context);
            }
        }
        return instance;
    }

    public void info(String component, String sessionId, String message) {
        append("INFO", component, sessionId, message);
    }

    public void warn(String component, String sessionId, String message) {
        append("WARN", component, sessionId, message);
    }

    public void error(String component, String sessionId, String message, Throwable error) {
        String errorId = java.util.UUID.randomUUID().toString().substring(0, 8).toUpperCase(Locale.US);
        StringBuilder body = new StringBuilder("ErrorID=").append(errorId)
                .append("\nSegment=0 (segmented recording is scheduled for V1.5)")
                .append("\nMessage=").append(message == null ? "Unknown error" : message);
        body.append("\nDevice=").append(Build.MANUFACTURER).append(' ').append(Build.MODEL)
                .append("; Android=").append(Build.VERSION.RELEASE)
                .append("; SDK=").append(Build.VERSION.SDK_INT);
        body.append("\nMemory: javaUsed=").append(javaHeapUsedBytes())
                .append(" javaMax=").append(Runtime.getRuntime().maxMemory())
                .append(" nativeAllocated=").append(Debug.getNativeHeapAllocatedSize());
        body.append("\nStorageAvailableBytes=").append(availableStorageBytes());
        body.append("\nRecordingSettings=").append(activeSessionContext);
        body.append("\nProcessPssKb=").append(Debug.getPss());
        if (error != null) {
            StringWriter sw = new StringWriter();
            error.printStackTrace(new PrintWriter(sw));
            body.append("\nException=").append(error.getClass().getName())
                    .append("\nMessage=").append(error.getMessage())
                    .append("\nStackTrace:\n").append(sw);
        }
        append("ERROR", component, sessionId, body.toString());
    }

    public void setSessionContext(String sessionId, String resolution, int fps, int bitrate, String audioMode) {
        activeSessionContext = "session=" + (sessionId == null ? "-" : sessionId)
                + "; resolution=" + resolution + "; requestedFps=" + fps
                + "; bitrate=" + bitrate + "; audioMode=" + audioMode;
    }

    public void clearSessionContext() { activeSessionContext = "not-recording"; }

    public void append(String level, String component, String sessionId, String message) {
        String timestamp = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSSZ", Locale.US)
                .format(new Date());
        String safeComponent = component == null ? "General" : component;
        String safeSession = sessionId == null ? "-" : sessionId;
        String line = timestamp + " [" + level + "] [" + safeComponent + "] [session="
                + safeSession + "] " + (message == null ? "" : message) + "\n";
        synchronized (lock) {
            try {
                rotateIfNeeded(line.length() * 2L);
                try (FileOutputStream output = new FileOutputStream(currentFile, true)) {
                    output.write(line.getBytes(java.nio.charset.StandardCharsets.UTF_8));
                    output.flush();
                }
            } catch (IOException exception) {
                android.util.Log.e(TAG, "Unable to append diagnostic log", exception);
            }
        }
        if ("ERROR".equals(level)) android.util.Log.e(TAG, "[" + safeComponent + "] " + message);
        else if ("WARN".equals(level)) android.util.Log.w(TAG, "[" + safeComponent + "] " + message);
        else android.util.Log.i(TAG, "[" + safeComponent + "] " + message);
    }

    private void rotateIfNeeded(long incomingBytes) throws IOException {
        if (!currentFile.exists() || currentFile.length() + incomingBytes <= MAX_FILE_BYTES) return;
        File oldest = backupFile(BACKUP_COUNT);
        if (oldest.exists() && !oldest.delete()) {
            throw new IOException("Could not remove oldest log backup");
        }
        for (int index = BACKUP_COUNT - 1; index >= 1; index--) {
            File source = backupFile(index);
            if (source.exists() && !source.renameTo(backupFile(index + 1))) {
                throw new IOException("Could not rotate log " + source.getName());
            }
        }
        if (!currentFile.renameTo(backupFile(1))) {
            throw new IOException("Could not rotate active log");
        }
    }

    private File backupFile(int index) {
        return new File(directory, "lite-recorder.log." + index);
    }

    public void exportTo(OutputStream destination) throws IOException {
        synchronized (lock) {
            try (BufferedOutputStream out = new BufferedOutputStream(destination)) {
                out.write(("Lite Screen Recorder Diagnostics\n" +
                        "Generated: " + new Date() + "\n" +
                        "Device: " + Build.MANUFACTURER + " " + Build.MODEL + "\n" +
                        "Android: " + Build.VERSION.RELEASE + " (SDK " + Build.VERSION.SDK_INT + ")\n\n")
                        .getBytes(java.nio.charset.StandardCharsets.UTF_8));
                for (int index = BACKUP_COUNT; index >= 1; index--) copyIfExists(backupFile(index), out);
                copyIfExists(currentFile, out);
                out.flush();
            }
        }
    }

    private void copyIfExists(File source, OutputStream destination) throws IOException {
        if (!source.exists()) return;
        try (BufferedInputStream input = new BufferedInputStream(new FileInputStream(source))) {
            byte[] buffer = new byte[8192];
            int count;
            while ((count = input.read(buffer)) != -1) destination.write(buffer, 0, count);
        }
    }

    public String diagnosticsDirectoryPath() {
        return directory.getAbsolutePath();
    }

    public static long javaHeapUsedBytes() {
        Runtime runtime = Runtime.getRuntime();
        return runtime.totalMemory() - runtime.freeMemory();
    }

    public static long availableStorageBytes() {
        try {
            File base = android.os.Environment.getExternalStorageDirectory();
            StatFs stat = new StatFs(base.getAbsolutePath());
            return stat.getAvailableBytes();
        } catch (RuntimeException error) {
            return -1L;
        }
    }
}
