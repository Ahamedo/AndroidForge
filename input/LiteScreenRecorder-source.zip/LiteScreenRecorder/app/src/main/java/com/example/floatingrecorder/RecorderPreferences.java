package com.example.floatingrecorder;

import android.content.Context;
import android.content.SharedPreferences;

public final class RecorderPreferences {
    private static final String PREFS = "recorder_preferences";
    private static final String KEY_RESOLUTION = "resolution";
    private static final String KEY_FPS = "fps";
    private static final String KEY_BITRATE = "bitrate_mbps";
    private static final String KEY_AUDIO = "audio_mode";
    private static final String KEY_BUBBLE_SIZE = "bubble_size";
    private static final String KEY_BUBBLE_OPACITY = "bubble_opacity";
    private static final String KEY_BUBBLE_COLOR = "bubble_color";
    private static final String KEY_SHAKE = "shake_enabled";
    private static final String KEY_SHAKE_SENSITIVITY = "shake_sensitivity";
    private static final String KEY_LAST_URI = "last_uri";
    private static final String KEY_LAST_NAME = "last_name";

    public static final String RES_480 = "480p";
    public static final String RES_720 = "720p";
    public static final String RES_1080 = "1080p";
    public static final String AUDIO_MUTE = "mute";
    public static final String AUDIO_MIC = "microphone";
    public static final String AUDIO_SYSTEM = "system";
    public static final String AUDIO_BOTH = "system_microphone";

    private RecorderPreferences() { }

    private static SharedPreferences prefs(Context context) {
        return context.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
    }

    public static String resolution(Context c) { return prefs(c).getString(KEY_RESOLUTION, RES_1080); }
    public static void setResolution(Context c, String v) { prefs(c).edit().putString(KEY_RESOLUTION, v).apply(); }
    public static int fps(Context c) { return prefs(c).getInt(KEY_FPS, 30); }
    public static void setFps(Context c, int v) { prefs(c).edit().putInt(KEY_FPS, v).apply(); }
    public static int bitrateMbps(Context c) { return prefs(c).getInt(KEY_BITRATE, 8); }
    public static void setBitrateMbps(Context c, int v) { prefs(c).edit().putInt(KEY_BITRATE, v).apply(); }
    public static String audioMode(Context c) { return prefs(c).getString(KEY_AUDIO, AUDIO_SYSTEM); }
    public static void setAudioMode(Context c, String v) { prefs(c).edit().putString(KEY_AUDIO, v).apply(); }
    public static int bubbleSize(Context c) { return prefs(c).getInt(KEY_BUBBLE_SIZE, 64); }
    public static void setBubbleSize(Context c, int v) { prefs(c).edit().putInt(KEY_BUBBLE_SIZE, v).apply(); }
    public static float bubbleOpacity(Context c) { return prefs(c).getFloat(KEY_BUBBLE_OPACITY, 0.92f); }
    public static void setBubbleOpacity(Context c, float v) { prefs(c).edit().putFloat(KEY_BUBBLE_OPACITY, v).apply(); }
    public static String bubbleColor(Context c) { return prefs(c).getString(KEY_BUBBLE_COLOR, "red"); }
    public static void setBubbleColor(Context c, String v) { prefs(c).edit().putString(KEY_BUBBLE_COLOR, v).apply(); }
    public static boolean shakeEnabled(Context c) { return prefs(c).getBoolean(KEY_SHAKE, true); }
    public static void setShakeEnabled(Context c, boolean v) { prefs(c).edit().putBoolean(KEY_SHAKE, v).apply(); }
    public static String shakeSensitivity(Context c) { return prefs(c).getString(KEY_SHAKE_SENSITIVITY, "medium"); }
    public static void setShakeSensitivity(Context c, String v) { prefs(c).edit().putString(KEY_SHAKE_SENSITIVITY, v).apply(); }

    public static void setLastRecording(Context c, String uri, String name, long sizeBytes) {
        prefs(c).edit().putString(KEY_LAST_URI, uri).putString(KEY_LAST_NAME, name)
                .putLong("last_size", sizeBytes).apply();
    }
    public static String lastUri(Context c) { return prefs(c).getString(KEY_LAST_URI, null); }
    public static String lastName(Context c) { return prefs(c).getString(KEY_LAST_NAME, null); }
    public static long lastSize(Context c) { return prefs(c).getLong("last_size", 0L); }
}
