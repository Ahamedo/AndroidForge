package com.example.floatingrecorder;

import android.content.Context;
import android.content.SharedPreferences;

/** Only user-facing recording preferences are stored here. */
public final class RecorderPreferences {
    private static final String PREFS = "recorder_preferences";
    private static final String KEY_RESOLUTION = "resolution";
    private static final String KEY_FPS = "fps";
    private static final String KEY_BITRATE = "bitrate_mbps";
    private static final String KEY_AUDIO = "audio_mode";
    private static final String KEY_LAST_URI = "last_uri";
    private static final String KEY_LAST_NAME = "last_name";
    private static final String KEY_LAST_SIZE = "last_size";
    private static final String KEY_FOLDER_TREE_URI = "folder_tree_uri";

    public static final String RES_480 = "480p";
    public static final String RES_720 = "720p";
    public static final String RES_1080 = "1080p";
    public static final String AUDIO_MUTE = "mute";
    public static final String AUDIO_MIC = "microphone";
    public static final String AUDIO_SYSTEM = "system";
    public static final String AUDIO_BOTH = "system_microphone";

    private RecorderPreferences() { }

    private static SharedPreferences prefs(Context context) {
        return context.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
    }

    public static String resolution(Context c) { return prefs(c).getString(KEY_RESOLUTION, RES_720); }
    public static void setResolution(Context c, String v) { prefs(c).edit().putString(KEY_RESOLUTION, v).apply(); }
    public static int fps(Context c) { return prefs(c).getInt(KEY_FPS, 30); }
    public static void setFps(Context c, int v) { prefs(c).edit().putInt(KEY_FPS, v).apply(); }
    public static int bitrateMbps(Context c) { return prefs(c).getInt(KEY_BITRATE, 4); }
    public static void setBitrateMbps(Context c, int v) { prefs(c).edit().putInt(KEY_BITRATE, v).apply(); }
    public static String audioMode(Context c) { return prefs(c).getString(KEY_AUDIO, AUDIO_SYSTEM); }
    public static void setAudioMode(Context c, String v) { prefs(c).edit().putString(KEY_AUDIO, v).apply(); }

    public static void setFolderTreeUri(Context c, String uri) {
        prefs(c).edit().putString(KEY_FOLDER_TREE_URI, uri).apply();
    }
    public static String folderTreeUri(Context c) { return prefs(c).getString(KEY_FOLDER_TREE_URI, null); }

    public static void setLastRecording(Context c, String uri, String name, long sizeBytes) {
        prefs(c).edit().putString(KEY_LAST_URI, uri).putString(KEY_LAST_NAME, name)
                .putLong(KEY_LAST_SIZE, sizeBytes).apply();
    }
    public static String lastUri(Context c) { return prefs(c).getString(KEY_LAST_URI, null); }
    public static String lastName(Context c) { return prefs(c).getString(KEY_LAST_NAME, null); }
    public static long lastSize(Context c) { return prefs(c).getLong(KEY_LAST_SIZE, 0L); }
}
