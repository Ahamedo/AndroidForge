package com.example.floatingrecorder;

import android.content.Context;
import android.os.Build;
import android.os.Handler;
import android.os.HandlerThread;
import android.os.PowerManager;
import android.os.Process;

import java.util.Locale;
import java.util.UUID;
import java.util.concurrent.atomic.AtomicBoolean;

/** Samples inexpensive process/device metrics at a fixed, low frequency. */
public final class PerformanceMonitor {
    private static final long SAMPLE_INTERVAL_MS = 30_000L;

    private final Context context;
    private final DiagnosticsLogger logger;
    private final String sessionId;
    private final RecordingEngine engine;
    private final int requestedFps;
    private final String resolution;
    private final AtomicBoolean running = new AtomicBoolean(false);
    private HandlerThread thread;
    private Handler handler;
    private long previousCpuMs;
    private long previousWallMs;
    private long previousFrames;

    private final Runnable sampleRunnable = new Runnable() {
        @Override public void run() {
            if (!running.get()) return;
            try { sample(); }
            catch (RuntimeException error) { logger.error("Performance", sessionId, "Performance sample failed", error); }
            if (running.get() && handler != null) handler.postDelayed(this, SAMPLE_INTERVAL_MS);
        }
    };

    public PerformanceMonitor(Context context, String sessionId, RecordingEngine engine,
                              int requestedFps, String resolution) {
        this.context = context.getApplicationContext();
        this.logger = DiagnosticsLogger.get(context);
        this.sessionId = sessionId;
        this.engine = engine;
        this.requestedFps = requestedFps;
        this.resolution = resolution;
    }

    public void start() {
        if (!running.compareAndSet(false, true)) return;
        thread = new HandlerThread("LiteRecorderDiagnostics", Process.THREAD_PRIORITY_BACKGROUND);
        thread.start();
        handler = new Handler(thread.getLooper());
        previousCpuMs = Process.getElapsedCpuTime();
        previousWallMs = android.os.SystemClock.elapsedRealtime();
        previousFrames = engine.getEncodedFrames();
        handler.postDelayed(sampleRunnable, SAMPLE_INTERVAL_MS);
        logger.info("Performance", sessionId, "Monitor started; intervalMs=" + SAMPLE_INTERVAL_MS);
    }

    private void sample() {
        long nowWall = android.os.SystemClock.elapsedRealtime();
        long nowCpu = Process.getElapsedCpuTime();
        long wallDelta = Math.max(1L, nowWall - previousWallMs);
        long cpuDelta = Math.max(0L, nowCpu - previousCpuMs);
        double cpuPercent = (cpuDelta * 100.0d) / wallDelta;

        long frames = engine.getEncodedFrames();
        long frameDelta = Math.max(0L, frames - previousFrames);
        double actualFps = frameDelta * 1000.0d / wallDelta;

        long javaUsed = DiagnosticsLogger.javaHeapUsedBytes();
        long javaMax = Runtime.getRuntime().maxMemory();
        long nativeAllocated = android.os.Debug.getNativeHeapAllocatedSize();
        long processPssKb = android.os.Debug.getPss();
        int processorCount = Math.max(1, Runtime.getRuntime().availableProcessors());
        double deviceCpuPercent = cpuPercent / processorCount;
        long storage = DiagnosticsLogger.availableStorageBytes();
        int thermal = readThermalStatus();

        String line = String.format(Locale.US,
                "uptimeMs=%d recordingDurationMs=%d javaHeapUsed=%d javaHeapMax=%d nativeHeapAllocated=%d processPssKb=%d " +
                "processCpuPercentOfOneCore=%.1f processCpuPercentOfDevice=%.1f cpuTimeDeltaMs=%d processorCount=%d requestedFps=%d actualEncodedFps=%.2f " +
                "encodedFramesWritten=%d frameDelta=%d samplesNotWrittenToMuxer=%d audioSamplesQueued=%d videoBitrate=%d " +
                "resolution=%s audioMode=%s audioQueue=codec-managed videoQueue=surface-managed " +
                "surfaceInputDroppedFrames=not-reliably-exposed storageAvailable=%d thermalStatus=%d",
                nowWall, engine.getElapsedMs(), javaUsed, javaMax, nativeAllocated, processPssKb, cpuPercent, deviceCpuPercent, cpuDelta, processorCount,
                requestedFps, actualFps, frames, frameDelta, engine.getDroppedMuxerSamples(), engine.getAudioSamplesQueued(), engine.getVideoBitrate(),
                resolution, RecorderPreferences.audioMode(context), storage, thermal);
        logger.info("Performance", sessionId, line);

        previousWallMs = nowWall;
        previousCpuMs = nowCpu;
        previousFrames = frames;
    }

    private int readThermalStatus() {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.Q) return -1;
        try {
            PowerManager powerManager = (PowerManager) context.getSystemService(Context.POWER_SERVICE);
            return powerManager == null ? -1 : powerManager.getCurrentThermalStatus();
        } catch (RuntimeException error) {
            logger.warn("Performance", sessionId, "Thermal status unavailable: " + error.getClass().getSimpleName());
            return -1;
        }
    }

    public void stop() {
        if (!running.compareAndSet(true, false)) return;
        if (handler != null) handler.removeCallbacksAndMessages(null);
        if (thread != null) thread.quitSafely();
        logger.info("Performance", sessionId, "Monitor stopped");
        handler = null;
        thread = null;
    }
}
