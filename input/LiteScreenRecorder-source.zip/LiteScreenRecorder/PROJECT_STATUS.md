# Project Status — 2.0.0

## Direction
A compact Android screen recorder with no floating bubble. Recording controls are provided by the foreground-service notification.

## Configuration
- Android Gradle Plugin 8.2.2
- Gradle 8.2.1
- JDK 17
- Java 11
- compileSdk 34 / targetSdk 34 / minSdk 24
- No third-party Runtime libraries

## Delivered source changes
- Removed FloatingControlService.java and ShakeDetector.java.
- Removed PerformanceMonitor.java and its periodic service sampling.
- Removed SYSTEM_ALERT_WINDOW and the floating-control service declaration from AndroidManifest.xml.
- Rebuilt MainActivity as a concise settings/start/last-recording screen.
- Added notification Pause / Resume / Stop actions.
- Added a custom output-folder preference and SAF folder selection for Android 8.0+.
- Added 15, 24, 30 and 60 FPS choices.

## Validation
| Check | Result |
|---|---|
| Overlay permission / class reference scan | Passed: no remaining source/manifest references |
| XML parsing | Passed with Python XML parser |
| Java syntax scan | No Java parser diagnostics; Android type checking remains unavailable without android.jar |
| Android Gradle build | Not run: no Android SDK or Gradle installed here |
| APK size | Not measured: no APK built |
| Screen recording on device | Not run |
| Internal audio / microphone tests | Not run |
| Pause/resume audio-video sync | Not run; requires real-device validation |
| Long-session / background stability | Not run |

## Important
This archive is a source release for AndroidForge, not a verified APK. It must pass an AndroidForge build and be tested on the target phone before being treated as a working release. No zero-crash guarantee is claimed.
