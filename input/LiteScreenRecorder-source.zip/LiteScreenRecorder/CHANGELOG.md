# Changelog

## 2.0.0 — Minimal notification-controlled recorder

### Removed
- Floating bubble service and its source file.
- Overlay permission and all overlay permission checks.
- Shake-to-stop detector and related preferences.
- Performance polling service and its periodic CPU/RAM/thermal sampling.
- Bubble size/color/opacity and low-resource preset controls.
- Diagnostic export controls from the main screen.

### Added / Changed
- Replaced the previous diagnostic-heavy screen with a small settings screen.
- Added notification actions for Pause, Resume, and Stop & Save.
- Added pause/resume support in the recording engine by detaching and reattaching the VirtualDisplay surface; video timestamps are adjusted to exclude paused intervals and audio samples are discarded while paused.
- Added selectable audio mode: internal playback, internal + microphone, microphone, or mute.
- Added 15/24/30/60 FPS selection and adjusted encoder fallback candidates.
- Added user-selected output folder support through Storage Access Framework on Android 8.0+.
- Kept the default Movies/LiteScreenRecorder destination when no custom folder is selected.
- Retained native MediaProjection / MediaCodec / MediaMuxer capture and MP4 output.
- Version bumped to 2.0.0 (versionCode 20).

### Not included in this release
- Automatic MP4 segmentation and recovery of an interrupted session.
- A successful Android build or real-device validation report.

### Validation status
- Source text and project metadata reviewed.
- Manifest XML and ZIP integrity are checked before delivery.
- No Android SDK or Gradle installation is available in this environment, so Android compilation and device tests have not been run.
