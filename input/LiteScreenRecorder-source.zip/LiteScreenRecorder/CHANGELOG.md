# Changelog

## V1.3.0 — Performance Diagnosis

### Added
- Java application source structure.
- Bounded diagnostic log with 1 MiB active file and up to three rotated backups.
- Session context on error reports: requested resolution, FPS, bitrate and audio mode.
- Periodic performance samples every 30 seconds: process PSS, Java heap, native heap, process CPU time, CPU percentages, encoded frame rate, audio samples, storage and thermal status where supported.
- TXT diagnostics export through Android's document picker.
- Hardware AVC encoder capability inspection and configuration fallback across lower resolution/FPS choices.
- Storage output abstraction for MediaStore (Android 10+) and legacy Movies path (Android 7–9).
- Failed output retention instead of unconditional deletion.

### Fixed / Hardened
- Audio setup failures degrade to video-only capture when the video path remains healthy.
- The floating bubble is hidden before capture and no longer uses FLAG_SECURE.
- UI status refresh is limited to once per second; recent-recording/storage refresh is not polled every tick.
- Video EOS waiting has a finite timeout; a missing EOS prevents the app from reporting a successful save.
- Worker termination is checked after bounded joins; an alive worker prevents successful publication.
- Stop requests received during engine startup are deferred until setup completes or fails, avoiding concurrent teardown of codecs and VirtualDisplay.
- Audio sample count uses an atomic counter for cross-thread diagnostics.

### Not included yet
- Segmented Recording / manifest / recovery: planned for V1.5.
- Pause / Resume and complete floating control menu.
- Thermal-driven encoder reconfiguration between segments.
- Audio dual-source concurrency/timestamp synchronization.
- Automated instrumentation and real-device performance tests.

## 1.3.1 — AndroidForge compile fixes

- Fixed `Debug.getPss()` type handling (`long`).
- Fixed the recorder startup diagnostic to read bitrate through `getVideoBitrate()`.
- Replaced the unavailable framework drawable `ic_media_stop` with `ic_menu_close_clear_cancel`.
- Removed the obsolete `package` attribute from the source manifest; Gradle `namespace` remains authoritative.
- Bumped app version to 1.3.1 (versionCode 14).

Build status: source-level fixes applied against the three compiler errors in AndroidForge logs. A new AndroidForge build is still required; no successful APK build is claimed.
