# Lite Screen Recorder — V1.3 (Performance Diagnosis)

مسجل شاشة Android مبني بلغة Java باستخدام واجهات Android SDK القياسية. هذا الأرشيف هو مصدر الإصدار التشخيصي 1.3، وليس APK جاهزاً ولا إعلاناً بأن التطبيق أصبح Production Ready. يحافظ المشروع على `applicationId` السابق `com.example.floatingrecorder` وملف SharedPreferences السابق `recorder_preferences` للمساعدة في التحديث فوق النسخة الحالية دون تغيير هوية التطبيق أو فقد إعداداته المحفوظة.

## بيئة البناء المستهدفة

| الإعداد | القيمة |
|---|---|
| Language | Java |
| Android Gradle Plugin | 8.2.2 |
| Gradle distribution | 8.2.1 |
| JDK على CI | 17 |
| Java source/target | 11 |
| compileSdk | 34 |
| targetSdk | 34 |
| minSdk | 24 (Android 7.0) |
| Runtime dependencies | لا توجد مكتبات خارجية |

ملف `gradle/wrapper/gradle-wrapper.properties` يحدد Gradle 8.2.1. لم تتوفر في بيئة إعداد الأرشيف نسخة `gradle-wrapper.jar` أو سكربتا `gradlew` و`gradlew.bat`؛ لذلك يجب أن يستخدم AndroidForge تثبيت Gradle الخاص به أو يوفّر Wrapper. لا تعتبر هذه النسخة قد بُنيت حتى يظهر نجاح مهمة `:app:assembleDebug` في AndroidForge.

## ما يتضمنه الإصدار 1.3

- تحويل ملفات التطبيق الأساسية من Kotlin إلى Java مع الحفاظ على `applicationId` الحالي ومفاتيح الإعدادات المحفوظة.
- تسجيل شاشة باستخدام `MediaProjection` ومرمّز AVC عتادي عبر `MediaCodec` وملف MP4 عبر `MediaMuxer`.
- فحص قدرات المرمّز قبل اختياره، مع خفض الدقة أو FPS تدريجياً عند عدم دعم الإعداد المطلوب. لا يُستخدم Software Encoder كخيار تلقائي على الأجهزة الضعيفة.
- التقاط الصوت الداخلي عبر `AudioPlaybackCapture` على Android 10+ حيث تسمح التطبيقات المصدر بذلك، والميكروفون اختيارياً. فشل مسار الصوت لا ينبغي أن يمنع استمرار الفيديو.
- خدمة Foreground وإشعار دائم يحتوي على Stop & Save.
- إخفاء الكرة العائمة أثناء الالتقاط بدلاً من تطبيق `FLAG_SECURE` على نافذتها؛ يظل التحكم أثناء التسجيل متاحاً من الإشعار.
- حفظ التسجيل المكتمل في `Movies/LiteScreenRecorder` باستخدام MediaStore على Android 10+، ومسار Movies مع MediaScanner على الإصدارات الأقدم.
- التحقق من وجود بيانات الملف قبل نشره، وعدم حذف الملف غير المكتمل تلقائياً عند فشل الإنهاء.
- تسجيل تشخيصي محدود مع تدوير للملفات، وتصدير السجل بصيغة TXT من الواجهة.
- قياسات دورية كل 30 ثانية: PSS، Java Heap، Native Heap، وقت CPU المستهلك، CPU كنسبة من نواة واحدة ومن إجمالي الأنوية، معدل الإطارات المحسوب من الإطارات المشفّرة، عدد عينات الصوت الممررة للمرمّز، إعدادات التسجيل، المساحة المتاحة، وحالة الحرارة عند دعم النظام.

## التشغيل الأول

1. افتح المشروع في AndroidForge من مجلد `LiteScreenRecorder` الذي يحتوي على `settings.gradle`.
2. اختر JDK 17 وGradle 8.2.1 وAndroid SDK Platform 34 إن كانت إعدادات البناء تسمح بتحديدها.
3. نفّذ مهمة Debug: `:app:assembleDebug`.
4. نزّل APK الناتج من AndroidForge وثبّته على الهاتف.
5. امنح إذن الظهور فوق التطبيقات، وإذن الإشعارات عند طلبه، وإذن الميكروفون عند اختيار وضع صوت يحتاج إلى `RECORD_AUDIO`.
6. قبل كل جلسة، وافق على نافذة Android الرسمية الخاصة بتسجيل الشاشة.
7. ابدأ أول اختبار بإعداد الموارد المنخفضة: 480p / 30 FPS / 2 Mbps / بدون صوت.
8. أوقف التسجيل من إشعار الخدمة، ثم تحقق من وجود ملف MP4 في مجلد Movies/LiteScreenRecorder وتشغيله.

## تصدير التشخيص

من قسم Diagnostics داخل التطبيق اضغط **Export Logs — تصدير تقرير TXT**، واختر مكان حفظ الملف، ثم أرسل التقرير الناتج بعد التجربة. لا يحتوي التطبيق على تسجيل لمحتوى الشاشة أو الصوت داخل سجلات التشخيص.

## حدود معروفة في V1.3

- التسجيل الحالي ملف MP4 واحد لكل جلسة؛ Segmented Recording وSession Manifest واستعادة الجلسات هي هدف V1.5 وليست منفذة هنا.
- لا توجد آلية تضمن استعادة MP4 إذا ماتت العملية أثناء الكتابة. قد يبقى ملف مؤقت أو Pending غير قابل للنشر تلقائياً.
- لا توجد حالياً Pause/Resume. التحكم المتاح أثناء الجلسة هو Stop & Save من الإشعار.
- الكرة العائمة مخفية أثناء الالتقاط لتجنب ظهورها في الفيديو؛ لم يُنفذ بعد عرض كرة ديناميكية بحالات Recording/Paused/Saving.
- وضع Internal Audio يعتمد على سياسة التطبيق المصدر؛ قد لا يُلتقط الصوت من تطبيقات تمنع Playback Capture أو تستخدم DRM. يتطلب Android 10 أو أحدث.
- في وضع النظام + الميكروفون تتم قراءة مصدري الصوت بالتتابع في هذا الإصدار؛ التزامن وموازنة الصوت وتحسين مسار الالتقاط ضمن V1.4.
- لا تزال اختبارات الحرارة والذاكرة على أجهزة فعلية مطلوبة. لا توجد نتيجة اختبار 30 دقيقة أو ساعة مرفقة بهذا الإصدار.
- أرقام الإطارات المعروضة هي متوسط الإطارات التي خرجت من مسار الترميز خلال فترة القياس، وليست ضماناً لعدد إطارات الشاشة المعروضة. لا تُتاح عدادات dropped frames الموثوقة دائماً مع Surface input.
- حالة الحرارة تُقرأ من Thermal API على Android 10+ فقط؛ القيمة -1 تعني أن القراءة غير متاحة.
- قد لا يعرض MediaStore الملفات غير المكتملة التي بقيت Pending حتى تنفيذ أداة Recovery في إصدار لاحق.

## حالة التحقق

- فحص ملفات XML: **نجح** في التحليل البنيوي.
- فحص صياغة Java عبر `javac`: **لم تظهر أخطاء صياغة**؛ تعذر فحص الأنواع وواجهات Android لغياب android.jar.
- فحص بناء Android الفعلي: **لم يُنفذ في هذه البيئة** لعدم توفر Android SDK / android.jar وGradle وJDK 17.
- اختبارات الهاتف الفعلية: **لم تُنفذ**.
- لا يوجد APK في ZIP؛ AndroidForge هو مكان تنفيذ البناء وفق سير العمل المطلوب.

## بنية المشروع

```text
LiteScreenRecorder/
├── settings.gradle
├── build.gradle
├── gradle.properties
├── gradle/wrapper/gradle-wrapper.properties
├── README.md
├── CHANGELOG.md
├── PROJECT_STATUS.md
├── REPORT_V1.3_AR.md
├── TEST_RESULTS_V1.3_AR.md
└── app/
    ├── build.gradle
    ├── proguard-rules.pro
    └── src/main/
        ├── AndroidManifest.xml
        ├── java/com/example/floatingrecorder/
        └── res/values/styles.xml
```
