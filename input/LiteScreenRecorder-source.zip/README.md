# Lite Screen Recorder — standalone Android source project

A small Java screen recorder intended for low-RAM Android devices. This archive contains **only the Lite Screen Recorder application project**. It does not contain, create, patch, or modify AndroidForge, any AndroidForge repository, or any GitHub Actions workflow.

## Project compatibility

| Setting | Value |
|---|---|
| Android Gradle Plugin | 8.2.2 |
| Gradle runtime | 8.2 or newer (8.2.1 is a suitable wrapper distribution) |
| CI Java runtime | JDK 17 |
| Compile SDK | 34 |
| Target SDK | 34 |
| Minimum SDK | 24 (Android 7.0) |
| Java source / target | 11 |
| Application ID | `com.example.litescreenrecorder` |
| Main media encoder | Android `MediaCodec`, AVC/H.264 surface input |
| Audio encoder | Android `MediaCodec`, AAC-LC |
| MP4 container | Android `MediaMuxer` |

The Gradle project files are at the archive root. The ZIP is meant to be extracted directly as an Android project source tree, so the extracted root contains `settings.gradle`, `build.gradle`, `gradle.properties`, and `app/`.

> **Build verification note:** the source is structured for AGP 8.2.2 / JDK 17 / compile SDK 34, but this authoring environment does not contain an Android SDK platform or a Gradle installation. A cloud build has not been run here. Use the first AndroidForge debug build as the compile gate, and inspect the build log if the runner differs from the compatibility matrix above.

## Included files

```text
LiteScreenRecorder/
├── build.gradle
├── settings.gradle
├── gradle.properties
├── README.md
└── app/
    ├── build.gradle
    ├── proguard-rules.pro
    └── src/main/
        ├── AndroidManifest.xml
        ├── java/com/example/litescreenrecorder/
        │   ├── MainActivity.java
        │   ├── RecordingPreferences.java
        │   └── ScreenRecordService.java
        └── res/
            ├── layout/
            │   ├── activity_main.xml
            │   ├── floating_bubble.xml
            │   └── floating_controls.xml
            └── values/
                ├── strings.xml
                └── themes.xml
```

No AndroidForge workflow, AndroidForge config, or wrapper binary has been added. The cloud build service can use its configured Gradle installation. If its build runner requires `./gradlew` specifically, it must provide or generate the Gradle wrapper scripts/JAR in its build environment; the wrapper distribution for AGP 8.2.2 should be Gradle 8.2 or newer and the JVM must still be JDK 17.

---

# 1. Application components

## `RecordingPreferences.java`

A small `SharedPreferences` facade. It persists the quality preset, FPS preset, audio mode, floating-bubble preference, current recorder state, live elapsed duration, and last completed recording URI/label/path. Settings are committed immediately so a process restart does not silently revert the selected settings. The elapsed duration is refreshed once per second by the service and is reloaded by the activity when it returns to the foreground.

Its `makeCaptureSpec()` method reads the current real display metrics and orientation at the start of a recording. The shorter physical display side maps to the requested output short side (480, 720, or 1080 pixels); the other side is scaled proportionally. Both dimensions are rounded up to even values for AVC surface encoders.

A conservative device heuristic treats low-RAM devices, devices with four or fewer available CPU cores, or devices reporting less than 3 GiB total memory as constrained. On those devices, the particularly demanding `1080p + 90 FPS` combination is reduced to `720p + 60 FPS`. The user's selected preference remains saved; only the effective session profile is reduced. The encoder bitrate is scaled from pixel count and effective FPS, then bounded to avoid unreasonably high values on small devices.

## `MainActivity.java`

The settings and consent screen. It:

- Restores saved spinner selections and the bubble switch.
- Persists each selection as soon as it changes.
- Requests `RECORD_AUDIO` before starting either audio mode. This is required for `AudioRecord` even when the selected source is internal playback capture.
- Requests `WRITE_EXTERNAL_STORAGE` only on API 24–28, where legacy public Movies storage is used.
- Requests `POST_NOTIFICATIONS` on API 33+. Denial is not treated as denial of screen-capture consent; Android still permits a foreground service to run, although its notification presentation is restricted by the OS.
- Requests a new screen-capture consent prompt for every session. The returned `Intent` is passed once to the service and is not cached for reuse.
- Checks `Settings.canDrawOverlays()` before enabling the bubble, launches the system overlay-permission screen when needed, and reconciles the switch when the activity resumes.
- Registers a non-exported state receiver with `ContextCompat.registerReceiver(..., RECEIVER_NOT_EXPORTED)`. Service broadcasts are package-scoped with `setPackage(getPackageName())`.
- Re-reads the persisted live service state and elapsed duration in `onResume()` so returning from another app does not leave the status, timer, or controls visually stale. If the process has died and there is no live service session, it clears a stale persisted `Recording`/`Paused` value.

The screen uses platform widgets and one small AndroidX Core dependency; it does not bring in AppCompat, a Material component suite, a media player, or a dependency-injection framework.

## `ScreenRecordService.java`

Owns the session lifecycle and all long-running work:

1. The activity receives screen-capture consent and starts this service.
2. The service immediately calls `startForeground()` with the media-projection service type. It adds the microphone service type only when `RECORD_AUDIO` is already granted and that type exists on the current OS version.
3. Only after foreground promotion does the setup thread call `MediaProjectionManager.getMediaProjection()`.
4. AVC is configured with `COLOR_FormatSurface`, an even-sized output, selected FPS hint, resolution/FPS-scaled bitrate, and a two-second I-frame interval.
5. Audio sources are initialized only when available. Audio failure does not stop the video pipeline.
6. The `MediaProjection.Callback` is registered before `createVirtualDisplay()`.
7. Encoder drain threads wait for output formats, add the video/audio tracks, and start the muxer only after every expected track format is ready.
8. Stop/revocation detaches and releases the `VirtualDisplay`, signals video EOS, stops audio reads and retries AAC EOS queueing, drains and joins the codec threads, releases the codecs, finalizes the muxer if it was started, unregisters the projection callback, and stops the projection when the system has not already revoked it.
9. Android 10+ muxes to an app-owned temporary MP4 first. Only after `MediaMuxer.stop()` and `release()` succeed is that completed file copied to a `MediaStore.Video` row as `IS_PENDING=1`; the row is made visible with `IS_PENDING=0` only after the complete byte copy succeeds. Android 7–9 muxes directly into `Movies/LiteScreenRecorder` and invokes `MediaScannerConnection`. Failed or zero-sample sessions are removed.

It also owns the notification and the optional floating bubble/control menu. The service can remain alive after a session when the bubble is enabled; while recording, it is a foreground media-projection service.

## Layouts and resources

- `activity_main.xml`: redesigned recorder dashboard with a prominent live status/timer card, clearly separated recording actions, grouped quality/FPS/audio settings, overlay switch, and last-file display.
- `floating_bubble.xml`: compact draggable status bubble showing `REC`/`PAUSE`/`LSR` plus the live timer.
- `floating_controls.xml`: a compact horizontal icon strip, not a large panel. It shows Start only while idle; while a session is active it shows Pause/Resume and Stop only. A new session cannot be started on top of an existing one.
- `strings.xml`: labels, user-facing warnings, and selector arrays.
- `themes.xml`: a small platform Material Light theme; no third-party UI suite.
- `AndroidManifest.xml`: permissions, launcher activity, and the non-exported media-projection/microphone foreground service.

---

# 2. Quality, FPS, and frame timing

### Quality presets

The output short edge is set to 480, 720, or 1080 pixels. The output long edge follows the device's real display aspect ratio. For example, a portrait screen produces a portrait output with the short edge as width; a landscape screen produces a landscape output with the short edge as height. Width and height are rounded to even numbers because common H.264 hardware encoders require even dimensions.

The capture dimensions are fixed when the session begins. If the phone rotates mid-recording, the encoder is **not** reconfigured. The VirtualDisplay keeps feeding the already-created fixed-size encoder surface, so the OS/device composition may scale or letterbox/crop the rotated content. The session is not forcibly orientation-locked, but the saved file dimensions do not change mid-file. For a predictable result, choose the intended orientation before starting and avoid rotating during a long recording.

### FPS presets and real display cadence

`30`, `60`, and `90` are encoder frame-rate hints (`MediaFormat.KEY_FRAME_RATE`). They are not a promise that the physical display will deliver that many unique frames:

- A 90 FPS encoder hint cannot create 90 Hz screen updates on a 60 Hz display.
- Screen capture is sourced from display composition; practical delivery is bounded by the display/compositor cadence and device performance.
- Static screens naturally produce fewer changed frames. MP4 can therefore behave like variable-frame-rate output even when the encoder was configured with a target FPS.
- Thermal throttling, low-end GPU/display pipelines, and hardware encoder limits can reduce delivered frames further.
- On constrained devices, the app guards the expensive 1080p/90 combination by using 720p/60 for that session.

The selected FPS preference remains saved even when a device-specific fallback is applied. The service logs the physical display refresh rate and warns when the selected FPS hint is above it.

### Bitrate

The AVC bitrate scales with `width × height` relative to a 854×480 baseline and scales linearly with effective FPS relative to 30 FPS. It is clamped to 1 Mbps minimum, 8 Mbps maximum on constrained devices, and 24 Mbps maximum otherwise. These are starting targets, not guarantees; some vendor encoders may ignore or adjust requested rates.

---

# 3. Audio modes and limits

## `internal_only`

On API 29+ (Android 10+), the app builds `AudioPlaybackCaptureConfiguration` from the active `MediaProjection`, matching `USAGE_MEDIA` and `USAGE_GAME`, and passes it to an `AudioRecord`. `RECORD_AUDIO` is still checked and requested before starting this mode.

Android 9/API 28 and lower do not provide `AudioPlaybackCapture`; this mode therefore records video without an audio track on those versions. The service logs that limitation rather than failing the video session.

## `internal_and_mic`

On API 29+, the service attempts to create both an internal playback `AudioRecord` and a microphone `AudioRecord`. On API 24–28 it can only initialize the microphone because internal playback capture does not exist there. Available mono PCM16 blocks are mixed at 44.1 kHz. When both sources are present, the samples are averaged to leave headroom and then saturated to the signed 16-bit range before being passed to AAC-LC.

If either source fails to initialize or read, the other source can continue. If both are unavailable, video continues without an audio track. The video recording pipeline does not crash merely because audio is silent or unsupported.

## Why internal audio may be silent

The app can request only eligible playback usages. The source app must also allow capture under its manifest and audio capture policy; apps can opt out, and DRM/protected playback can be silent. Work-profile boundaries and unsupported source apps can also restrict capture. This app does not bypass those OS or app privacy restrictions.

The microphone is subject to runtime permission, privacy toggles, hardware availability, and Android's while-in-use restrictions. The service is started from the visible activity after permission is granted, and the manifest declares the microphone foreground-service type. If the permission is revoked while recording, microphone capture can fail while video continues.

## A/V timestamps and pause/resume

Both tracks use the service's monotonic active-session clock. Audio input blocks are timestamped from that clock and the number of captured PCM samples; video output timestamps are translated from the surface timestamp by subtracting the session origin and `presentationTimeOffsetUs`. On resume, the duration of the pause is added to that offset. Each track is forced strictly monotonic before muxing. This avoids inserting the wall-clock pause duration into the MP4 timeline and reduces long-recording drift.

Pause attempts `MediaCodec.PARAMETER_KEY_SUSPEND` on the surface encoder, detaches the VirtualDisplay surface as a fallback, and pauses both AudioRecords. Resume reattaches the surface and restarts available AudioRecords. A vendor codec may ignore the suspend parameter; surface detachment is still applied.

---

# 4. Floating bubble

Enable the switch in the app. If Android has not granted overlay permission, the app opens **Display over other apps** settings and leaves the switch off until permission is actually granted. Returning to the app reconciles the switch with `Settings.canDrawOverlays()`.

On Android 8.0+ the service uses `TYPE_APPLICATION_OVERLAY`, `FLAG_NOT_FOCUSABLE`, and `PixelFormat.TRANSLUCENT`. Android 7.0–7.1 uses the legacy phone overlay type because `TYPE_APPLICATION_OVERLAY` is not available there.

The bubble continuously shows one of three states and the active recording duration: `● REC 00:24`, `Ⅱ PAUSE 00:24`, or `LSR / READY`. Tap it to open a very small horizontal icon strip:

- When idle, only **Start/New (▶)** appears. It opens the activity and requests fresh MediaProjection consent.
- While recording or paused, Start/New is hidden. Only **Pause/Resume (Ⅱ/▶)** and **Stop & Save (■)** are shown. This prevents starting a second session while one is already active.
- The menu closes after an action. The bubble remains draggable and updates its timer once per second.

Both overlay windows are created with `FLAG_SECURE` as well as `FLAG_NOT_FOCUSABLE`. The secure flag marks the bubble/menu surfaces as excluded from screen-capture paths that honor Android secure-window semantics. Verify the result on the target device/OEM; Android vendors can differ in their capture composition behavior.

A recording session is protected by its foreground service. When no recording is active, the bubble is held by a regular started service; Android or an OEM battery manager may still reclaim that idle service. Reopen the app if the idle bubble disappears. During active recording, do not force-stop the app from system settings: force-stop is an explicit user/system termination and can interrupt finalization.

---

# 5. Output location and Gallery visibility

- Android 10/API 29+: first writes the muxed MP4 to an app-owned temporary file. After the muxer has stopped and released successfully, the app inserts a `MediaStore.Video` row with `RELATIVE_PATH=Movies/LiteScreenRecorder` and `IS_PENDING=1`, copies the completed bytes, verifies the byte count, then sets `IS_PENDING=0`. This avoids making Gallery visibility depend on a pending-row size query while the muxer still owns an open file descriptor.
- Android 7–9/API 24–28: writes to the public `Movies/LiteScreenRecorder` directory. The app requests legacy write-storage permission and calls `MediaScannerConnection.scanFile()` after successful muxer finalization.
- File names use `ScreenRecord_yyyyMMdd_HHmmss.mp4`.
- A session with no encoded video samples, a failed muxer, or a zero-byte output is deleted rather than shown as a successful recording.

The muxer is started only after the expected output format(s) are available and tracks have been added. `stop()` and `release()` are executed only when `start()` succeeded. This avoids calling `MediaMuxer.stop()` on a muxer that never entered the started state.

### If Gallery publishing fails

The service preserves the completed temporary MP4 instead of deleting it when MediaStore publication fails. Check Logcat for `Completed MP4 retained for recovery at ...`; that line contains the exact file path. On a typical Android 10+ device, the file is under the app-specific Movies directory:

`/storage/emulated/0/Android/data/com.example.litescreenrecorder/files/Movies/ScreenRecord_YYYYMMDD_HHMMSS.mp4`

It can be copied to a computer with ADB (replace the filename with the path shown in Logcat):

```bash
adb pull "/sdcard/Android/data/com.example.litescreenrecorder/files/Movies/ScreenRecord_YYYYMMDD_HHMMSS.mp4" .
```

If the external app-specific directory is unavailable, the fallback path is the app cache directory; use the exact path from Logcat and `adb shell run-as com.example.litescreenrecorder` only where the device/build permits it. A retained temporary file means encoding/muxer finalization succeeded but Gallery publication did not; it is a recoverable storage-provider problem, not an assertion that Gallery saving succeeded.

---

# 6. Uploading this app ZIP to AndroidForge

These steps concern **only the app source archive**. Do not upload this archive as an AndroidForge repository patch, and do not replace or modify AndroidForge workflow/configuration files.

1. Keep the ZIP layout intact. At the top level of the ZIP, `settings.gradle`, `build.gradle`, `gradle.properties`, and `app/` must be visible. Do not nest them under an extra `LiteScreenRecorder/LiteScreenRecorder/` directory.
2. Open AndroidForge's app-source ZIP upload/import control and upload this `LiteScreenRecorder-source.zip` archive. Select the app project/root directory if the service asks for a project folder.
3. Select a **debug** build / `assembleDebug` for a sideloadable test APK. Android Gradle Plugin automatically signs debug APKs with its debug signing key.
4. The expected output is `app/build/outputs/apk/debug/app-debug.apk` (or the corresponding output artifact surfaced by AndroidForge).
5. Install the APK on a test device, grant screen-recording consent, microphone/audio permission, notification permission where applicable, and overlay permission only if the floating bubble is desired.

### Build toolchain notes

AGP 8.2.2 requires JDK 17 and a Gradle 8.2-compatible build runtime. Do not run the build using an older JDK such as JDK 11. The cloud runner must select JDK 17 before invoking Gradle. If the runner uses a Gradle Wrapper, the wrapper downloads the distribution declared in `gradle-wrapper.properties`; the wrapper itself still runs on the configured JDK. If AndroidForge invokes its preinstalled `gradle` binary, it must provide Gradle 8.2 or newer. This ZIP intentionally leaves wrapper binaries to the cloud builder rather than embedding an incomplete wrapper.

A `release` build without a configured upload keystore is unsigned and is not the right artifact for ordinary sideloading. Do not choose `release` expecting Android to install it directly. Configure a secure signing keystore in the build service only when you intentionally need a signed release build; never put private keystore passwords or key files into this source ZIP.

---

# 7. Failure prevention and troubleshooting

## Common failures

### Foreground service start failure / recording stops after leaving the app

- Start recording from the visible activity after granting the requested permissions. Android 14 requires the user consent flow before the media-projection foreground service obtains the projection.
- Keep `FOREGROUND_SERVICE` and `FOREGROUND_SERVICE_MEDIA_PROJECTION` in the manifest and the `mediaProjection` type in the service declaration.
- The app requests `RECORD_AUDIO` before recording and adds the microphone foreground type only when that permission is already granted.
- Do not force-stop the app or swipe away an OS-level “stop sharing/recording” prompt. The service is foreground while recording; aggressive OEM battery managers can still impose device-specific policies.

### MP4 is missing, zero bytes, or will not play

- Allow the app to finish its stop operation. Do not kill the process while `MediaMuxer.stop()` is finalizing the MP4 index.
- Confirm the hardware AVC encoder was created and that at least one video sample was encoded. Check `LiteScreenRecorderSvc` for `MediaCodec`, `VirtualDisplay`, and `MediaMuxer` errors.
- Test 480p/30 first. Some low-end devices cannot encode 1080p at high FPS even if the UI accepts that preference.
- A revoked projection triggers the service's `onStop()` cleanup path; if the OS terminates the process abruptly, no app can guarantee finalization after process death.

### Video does not appear in Gallery

- On Android 10+, look under `Movies/LiteScreenRecorder`. Check logs for `Temporary MP4`, `MediaStore insert`, `MediaStore copy`, and `Published MP4`. The app first finalizes an app-private temporary file, then copies it to a pending MediaStore row and publishes it only after the full copy succeeds.
- On Android 7–9, grant `WRITE_EXTERNAL_STORAGE` and verify that `Movies/LiteScreenRecorder` exists. MediaScanner runs after finalization; some Gallery apps need a refresh or a short delay.
- Check storage availability and the service log for MediaStore insert/open/update or MediaScanner failures.

### UI state is stale after returning to the app

- `onResume()` reloads the persisted state and duration, and the app listens to package-scoped service broadcasts. Confirm the service has not been force-stopped or killed by the OS.
- If the process died, the app intentionally clears a stale persisted `Recording`/`Paused` state because the encoder session is no longer alive.
- Reopen the app once after a service crash; inspect the preceding service exception before starting another session.

### Floating bubble is missing

- Check Android Settings → Apps → Special app access → Display over other apps and grant it to Lite Screen Recorder.
- Return to the app and confirm the switch is enabled. The app does not add overlay windows unless `Settings.canDrawOverlays()` is true.
- Some devices hide or reclaim idle background services. Reopen the app to restore the idle bubble. During recording, the foreground service keeps the recording session active.
- If the bubble appears but the menu does not, check for overlay permission revocation and inspect `Could not show floating control menu` in Logcat.

## Rare or hidden failures

### MediaProjection revocation, black video, or a session that stops unexpectedly

Android can revoke a projection from the system notification, Quick Settings, a screen-lock event, or other device policy. The registered `MediaProjection.Callback.onStop()` requests a normal stop/finalize path. A black recording can also occur if the display pipeline/encoder fails or the user captures a protected app. Inspect the service log for projection, VirtualDisplay, and codec exceptions; retry at 480p/30 to isolate hardware limits.

### Internal audio is silent or absent

- Android 9 and below have no `AudioPlaybackCaptureConfiguration`; internal-only mode is video-only on those OS versions.
- On Android 10+, capture is limited to allowed playback usages (this app requests MEDIA and GAME) and source apps that permit capture. Some apps opt out or use protected/DRM audio, so silence is expected and cannot be bypassed.
- In `internal_and_mic`, verify `RECORD_AUDIO` and the device microphone privacy toggle. If internal capture is blocked, microphone capture may still work.

### 1080p/90 FPS fails, overheats, or drops frames

- Test 480p/30 and increase one setting at a time.
- A 90 FPS encoder hint cannot override a 60 Hz panel/compositor. Check the service log line for physical display refresh rate.
- Use 720p/60 on constrained devices. Encoder throughput, thermal throttling, device memory, and GPU composition vary by manufacturer.
- If the file has rotated or cropped content after a mid-session orientation change, restart in the intended orientation. Encoder dimensions are fixed for the session.

### A/V sync drift or pauses that look like jumps

- The app anchors audio and video to a monotonic session clock and subtracts accumulated paused duration. OEM encoder timestamp behavior can still vary.
- Avoid changing orientation mid-session, avoid switching audio routes, and test shorter clips first. If drift persists on one device, compare a video-only recording and the same clip with audio enabled to isolate the audio route/encoder.

### Microphone or notification permission conflicts on modern Android

- `RECORD_AUDIO` is requested before both audio modes and is required to initialize AudioRecord. Android 11+ also requires the microphone foreground-service type when microphone capture continues in the foreground service; the app includes it only when permission is already granted.
- Android 13+ notification permission is requested. If denied, the service can still be started, but notification visibility is controlled by Android. Grant it for the clearest ongoing-recording indicator.
- Launch a recording from the foreground activity so Android's while-in-use microphone rules are satisfied. A start request initiated only from a background overlay may be blocked by newer Android versions; this app routes Start/New through the activity for that reason.

## Inspecting build failures in AndroidForge / GitHub Actions

1. Open the repository's **Actions** tab.
2. Select the failed run.
3. Open the workflow summary and inspect the failed job/step output. The first Gradle error is usually more useful than the final `exit code 1` line.
4. Download the **`AndroidForge-logs`** artifact from that run, if the workflow uploaded it, and inspect the included Gradle/build logs.
5. Confirm the runner uses **JDK 17**, Gradle 8.2 or newer, and that the uploaded ZIP has `settings.gradle` and `app/build.gradle` at the expected root.

This archive does not add or edit the workflow that creates the `AndroidForge-logs` artifact. If that artifact is not offered by the run, use the failed Actions step logs provided by the repository's existing workflow.

## Inspecting crashes on the device

With ADB connected and USB debugging enabled:

```bash
adb logcat -s LiteScreenRecorderSvc:V AndroidRuntime:E
```

To focus on the app process:

```bash
adb logcat --pid=$(adb shell pidof com.example.litescreenrecorder)
```

For a continuous capture, clear old messages first if useful, reproduce the issue, then save the output:

```bash
adb logcat -c
adb logcat -s LiteScreenRecorderSvc:V AndroidRuntime:E > lite-recorder-crash.txt
```

On-device log viewers can also be used. Filter for the package `com.example.litescreenrecorder`, tag `LiteScreenRecorderSvc`, and Android `AndroidRuntime` messages containing `FATAL EXCEPTION`, `SecurityException`, or `IllegalStateException`.

---

# 8. First-device test sequence

1. Install the debug APK on an Android 10+ device if internal playback capture is to be tested.
2. Open the app and choose `480p`, `30 FPS`, and `internal_only` first.
3. Tap Start, grant the Android screen-capture prompt, and record a short clip with a moving screen and media audio from a capture-eligible app.
4. Watch the timer increase, tap Pause and Resume once, then tap Stop & Save. Confirm the MP4 appears in `Movies/LiteScreenRecorder` and that the app updates the last-saved file label.
5. Repeat with `internal_and_mic`; verify both sources where allowed.
6. Enable the floating bubble, grant overlay access, return, and test Start/New, Pause/Resume, and Stop & Save.
7. Test 720p/60 and 1080p only after the baseline succeeds. Test 90 FPS only on a display/device that actually supports it.
8. Test system revocation by stopping screen sharing from Android's recording notification/Quick Settings and verify the file is finalized.

**Privacy:** screen capture and microphone input are user-consented, visible through Android's permission and foreground-service mechanisms, and subject to the source app's audio-capture policy. The recorder does not bypass protected-content restrictions.


# Official Android references

- [Media projection guide](https://developer.android.com/media/grow/media-projection) — per-session user consent, `MediaProjection` lifecycle, VirtualDisplay and callback requirements.
- [Android 14 foreground-service type requirements](https://developer.android.com/about/versions/14/changes/fgs-types-required) — media-projection and microphone type permissions and runtime prerequisites.
- [AudioPlaybackCaptureConfiguration API](https://developer.android.com/reference/android/media/AudioPlaybackCaptureConfiguration) — eligible usages and the source app's capture policy/manifest opt-out rules.
- [MediaCodec API](https://developer.android.com/reference/android/media/MediaCodec) — surface-input encoder controls, output format changes, and suspend/resume parameter.
- [Shared media storage](https://developer.android.com/training/data-storage/shared/media) — MediaStore publication and scoped storage.
