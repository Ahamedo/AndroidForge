# Lite Screen Recorder

A small Java screen recorder for Android 7.0+ (API 24+). It uses Android's built-in `MediaProjection`, `VirtualDisplay`, surface-input AVC `MediaCodec`, optional AAC `MediaCodec`, `MediaMuxer`, `MediaStore`, `AudioRecord`, `WindowManager`, and `SharedPreferences` APIs. The only external runtime dependency is AndroidX Core 1.12.0 for notification compatibility and safe receiver registration.

> **Validation status:** the source tree and CI workflow are provided, but this environment has no Android SDK / Gradle installation and cannot run an APK build or test on a physical low-end device. Treat the first GitHub Actions build and device test as the required integration-validation pass. Encoder/audio behavior is inherently device- and OEM-dependent.

## 1. Project tree

```text
LiteScreenRecorder/
├── .github/
│   └── workflows/
│       └── android.yml
├── app/
│   ├── build.gradle
│   ├── proguard-rules.pro
│   └── src/main/
│       ├── AndroidManifest.xml
│       ├── java/com/example/litescreenrecorder/
│       │   ├── MainActivity.java
│       │   ├── RecordingPreferences.java
│       │   └── ScreenRecordService.java
│       └── res/
│           ├── drawable/
│           │   ├── bubble_background.xml
│           │   └── panel_background.xml
│           ├── layout/
│           │   ├── activity_main.xml
│           │   ├── floating_bubble.xml
│           │   └── floating_controls.xml
│           └── values/
│               ├── arrays.xml
│               ├── strings.xml
│               └── themes.xml
├── build.gradle
├── gradle.properties
├── settings.gradle
├── .gitignore
└── README.md
```

## 2. Architecture

### `RecordingPreferences`

A typed facade around one private `SharedPreferences` file. It stores quality (`480p`, `720p`, `1080p`), requested FPS (`30`, `60`, `90`), audio mode (`internal_only`, `internal_and_mic`), bubble enablement, current service state and the last saved URI/name/path. Every setter uses `apply()`, updating the in-process preference state immediately and persisting it asynchronously to disk.

Its dimension helper reads the current real display size when a session begins. It scales the shorter display side to the selected preset, scales the longer dimension by the same aspect ratio, then rounds both dimensions down to even pixels. The H.264 surface encoder uses those fixed dimensions for the whole session.

Its effective-FPS helper leaves the saved preference untouched but constrains the encoder hint to the current display refresh rate, caps 1080p at 60 FPS and caps 1080p at 30 FPS on Android devices reporting themselves as low-RAM. The service also retries progressively lower encoder configurations if the requested configuration is rejected.

### `MainActivity`

Owns only user preferences, runtime-permission requests, overlay-permission navigation, the one-time-per-session screen-capture consent activity and UI display. It requests `POST_NOTIFICATIONS` on API 33+, `RECORD_AUDIO` for **both** audio modes, and `WRITE_EXTERNAL_STORAGE` on API 28 and below. The audio permission is intentionally requested for internal-only mode because `AudioPlaybackCaptureConfiguration` also requires `RECORD_AUDIO`.

It registers a package-scoped, non-exported state receiver with `ContextCompat.registerReceiver(..., RECEIVER_NOT_EXPORTED)`. `onResume()` reloads saved preferences, checks the real overlay grant, refreshes the recording status and asks the service for its live state. The state broadcast is also package-scoped with `Intent.setPackage(getPackageName())`.

### `ScreenRecordService`

Owns every long-running recording resource. It is started from the visible Activity only after the user approves screen capture. The service starts in the foreground with the media-projection service type before calling `getMediaProjection()`. It conditionally adds the microphone FGS type only when `RECORD_AUDIO` is granted and the platform exposes that type.

The service registers `MediaProjection.Callback` before creating the single `VirtualDisplay`. A surface-input AVC encoder receives the mirrored display frames. If audio can be initialized, an optional `AudioRecord` pipeline mixes selected PCM sources, saturates the sum to signed 16-bit range, and feeds an AAC encoder. A muxer gate waits until all expected output formats are available before calling `MediaMuxer.start()` exactly once.

The service also owns the overlay bubble and its three-button controls. Overlay views are created only when the saved switch is on and `Settings.canDrawOverlays()` is true.

## 3. Video behavior and performance policy

- `480p` is the default and recommended preset for low-memory / older hardware.
- `720p` is a practical balance on typical recent devices.
- `1080p` is capped at 60 FPS; devices reported as low-RAM are capped at 30 FPS at 1080p. A codec that rejects a preset causes a retry at a lower FPS and then a lower resolution.
- Bitrate is calculated from encoded pixel count and effective FPS (approximately 0.20 bits/pixel/frame), with a 1.5 Mbps minimum and 24 Mbps maximum. It is a starting target, not a quality guarantee; encoders may constrain it.
- `KEY_FRAME_RATE` is an encoder hint, not a promise of actual delivered frame rate. The capture source is the device display. A 60 Hz display cannot produce 90 unique display frames per second. The helper caps requested FPS to the display's currently reported refresh rate. A 90 Hz / 120 Hz panel may permit a 90 FPS hint, but encoder throughput and OEM scheduling still apply.
- Static display content may produce fewer changed frames than the configured hint. The MP4 can therefore behave like variable-frame-rate video. Screen animation, thermal throttling, encoder back-pressure and device refresh scheduling affect actual cadence.
- Dimensions are fixed when recording starts. Mid-recording orientation changes are **not** followed by a codec reconfiguration. The virtual display continues to target the original dimensions; Android may scale the changed display into that surface (behavior differs by Android version). For predictable output, choose the intended orientation before starting and stop/start a new session after rotating.

## 4. Audio behavior

### Internal-only mode

On API 29+, the service builds an `AudioPlaybackCaptureConfiguration` matching `USAGE_MEDIA` and `USAGE_GAME`, creates a PCM `AudioRecord`, and feeds AAC. Internal capture is subject to source-app capture policy, manifest opt-out, usage rules and DRM / protected-content restrictions. A valid recording can have a silent audio track when the source app disallows capture or produces protected output.

On API 24–28, Android does not provide `AudioPlaybackCaptureConfiguration`. Internal-only therefore produces video without an audio track. The UI still requests `RECORD_AUDIO` consistently for both modes, as required for the API 29+ internal capture path.

### Internal + microphone mode

On API 29+, playback PCM and microphone PCM are read at 44.1 kHz mono and mixed sample-by-sample. The sum is clamped to `[-32768, 32767]` to prevent signed-16-bit overflow. If internal capture is unavailable, microphone audio can continue alone. On API 24–28, only the microphone source is available.

Audio is optional. Permission denial, unsupported capture policy, protected playback, `AudioRecord` initialization problems or unavailable AAC encoding must not abort the video path. Denying `RECORD_AUDIO` skips audio capture but still permits video-only capture. In the current implementation the AAC track is added only when at least one source can initialize and start.

Audio timestamps use the same monotonic clock epoch as the screen session and subtract the accumulated paused duration. The audio input timestamps are forced to increase. The video output timestamps subtract the same pause offset. Pausing stops audio capture input, requests `MediaCodec.PARAMETER_KEY_SUSPEND` for the surface encoder where accepted, and detaches the virtual-display surface as a fallback. Resuming updates the pause offset, reattaches the surface, resumes encoder input and restarts available audio records. A/V alignment can still vary by OEM audio buffering and codec delay; test long sessions on target hardware.

## 5. Floating bubble

Enable **Floating bubble** from the main screen. When overlay access is missing, the app opens `Settings.ACTION_MANAGE_OVERLAY_PERMISSION` for this package. On return, the switch is reconciled with `Settings.canDrawOverlays()`; denial leaves it off.

Android 8+ uses `TYPE_APPLICATION_OVERLAY`; API 24–25 use the legacy phone overlay window type. Both views use `FLAG_NOT_FOCUSABLE` and `PixelFormat.TRANSLUCENT`. Drag the bubble to reposition it and tap it to open the controls:

- **بدء/جديد** opens the Activity and requests a new screen-capture consent prompt. If another recording is active, it is stopped/saved first so the new session receives a fresh one-use token.
- **إيقاف مؤقت/استئناف** pauses or resumes the existing session.
- **إيقاف وحفظ** finalizes the current MP4.

The overlay service is a normal started service while idle, not a permanent foreground service. Android/OEM process reclamation can remove the bubble while the app is idle; reopen the app to recreate it. During an actual recording, the dedicated foreground service keeps the capture pipeline alive after the Activity is left.

## 6. Storage and gallery visibility

- API 29+: `MediaStore.Video.Media` creates an item in `Movies/LiteScreenRecorder` with `IS_PENDING=1`. The muxer writes through a file descriptor. After encoder drain and muxer finalization, the service sets `IS_PENDING=0`. Failed / no-frame sessions delete the pending item.
- API 24–28: the app writes to public `Movies/LiteScreenRecorder` when `WRITE_EXTERNAL_STORAGE` is granted and invokes `MediaScannerConnection.scanFile()` after completion. If legacy storage permission is denied, the service falls back to the app's external Movies directory; that private app-specific file may not appear in every third-party Gallery.
- The MP4 output is finalized only after encoders drain and the muxer is stopped/released. `MediaMuxer.stop()` is never called unless `start()` completed. The muxer is still released if `start()` never completed, because the native resource must not leak. A session with no video samples is deleted.

## 7. Android 14 and permission ordering

The manifest declares `FOREGROUND_SERVICE`, `FOREGROUND_SERVICE_MEDIA_PROJECTION`, `FOREGROUND_SERVICE_MICROPHONE`, `RECORD_AUDIO`, `POST_NOTIFICATIONS`, `SYSTEM_ALERT_WINDOW`, and `WRITE_EXTERNAL_STORAGE` capped at API 28. The service declares `foregroundServiceType="mediaProjection|microphone"`.

The order for each new session is:

1. The visible Activity requests notifications (API 33+) and `RECORD_AUDIO`; it also requests legacy storage permission on API 28 and lower.
2. The Activity obtains a **new** `createScreenCaptureIntent()` consent result.
3. The Activity starts `ScreenRecordService` as a foreground service and passes that one-use result.
4. The Service calls `startForeground()` with media-projection type and conditionally microphone type.
5. Only then does it call `MediaProjectionManager.getMediaProjection()`.
6. The Service registers `MediaProjection.Callback`, prepares output/encoders and creates exactly one virtual display.
7. If Android or the user revokes projection, `onStop()` triggers orderly stop/save and status synchronization.

No consent token or projection instance is cached for the next session. A fresh prompt is required for every new recording. On Android 14, attempting to reuse consent data or create a second virtual display from the same `MediaProjection` session is rejected.

## 8. Cloud build without Android Studio

### GitHub Actions in this project

The included `.github/workflows/android.yml`:

1. Checks out the project.
2. Installs JDK 17.
3. Sets up Android SDK platform 34 and build-tools 34.0.0.
4. Installs Gradle 8.2.1, compatible with AGP 8.2.2.
5. Runs `gradle --no-daemon --stacktrace clean :app:assembleDebug`.
6. Uploads `LiteScreenRecorder-debug` and always uploads a diagnostic artifact named `AndroidForge-logs` containing the build log and any available Gradle reports.

Push the source to a GitHub repository (or use **Actions → Build Android APK → Run workflow**). Open the completed run and download the `LiteScreenRecorder-debug` artifact. The debug APK is signed with the standard debug key and is the correct choice for sideload testing.

### AndroidForge web uploader

The maintained AndroidForge project accepts an Android source ZIP through its web UI. Open <https://professional-x.github.io/AndroidForge/>, connect a GitHub repository with a token that has the documented repository/workflow permissions, upload the `.zip`, choose **debug** as the build variant, and start the build. Open the returned GitHub Actions run to download the APK artifact. AndroidForge detects Gradle/Java project structure, chooses a toolchain, and can use a system Gradle when a usable wrapper is absent. Its own README lists JDK 17 and SDK platform 34 in the current build environment and documents the ZIP upload and artifact flow.

**ZIP layout:** ZIP the contents of `LiteScreenRecorder/`, so `settings.gradle` and root `build.gradle` are at the ZIP root. Do not ZIP the parent directory as the only top-level entry. Exclude `.gradle/`, `build/`, `app/build/`, IDE caches, and any local keystore.

**Gradle wrapper note:** this source archive intentionally does not ship a fabricated `gradle-wrapper.jar`. The included GitHub workflow installs Gradle 8.2.1 directly. AndroidForge can fall back to its installed system Gradle if no usable wrapper exists; its current environment/toolchain selection is responsible for matching the AGP version. If you later add the official wrapper, generate it from Gradle 8.2.1 and include both `gradlew` scripts, `gradle/wrapper/gradle-wrapper.jar`, and `gradle-wrapper.properties` together.

### Debug vs release

Use `assembleDebug` for sideloading and troubleshooting. The `release` build type is configured for code/resource shrinking but has **no keystore/signingConfig** in this project, so a release APK is unsigned and is not suitable for ordinary installation until you add a private signing keystore securely in CI secrets. Never commit a production keystore or its passwords.

## 9. Common and hidden failures

| Symptom | Likely cause | Prevention / inspection |
|---|---|---|
| Foreground service start exception | `POST_NOTIFICATIONS` / audio prerequisites not handled, service started from background, missing FGS type permission, or consent not granted | Start from visible Activity after consent; grant `RECORD_AUDIO`; inspect `startForeground()` exception and manifest types. |
| Recording stops after leaving app | Service was not started foreground, OEM battery manager killed it, or process was reclaimed | Confirm persistent recording notification; exempt the app from aggressive battery optimization on devices that require it; do not keep capture in Activity. |
| MP4 is missing/corrupt | Encoder threads were stopped before EOS/drain, muxer never received all formats, muxer stop failed, or no video frames arrived | Keep the service teardown sequence; inspect `LiteScreenRecorderSvc` errors; test both video-only and audio-enabled. An empty session is intentionally deleted. |
| Video absent from Gallery | `IS_PENDING` was not cleared, legacy scanner was not called, legacy write permission denied, or file was written to app-private storage | Confirm MediaStore item has pending=0; verify `Movies/LiteScreenRecorder`; grant legacy storage permission on API 28 and below. |
| UI says recording after the session ended | Activity did not receive the broadcast while stopped, service state became stale after process death | `onResume()` queries the service and refreshes saved state; inspect `ACTION_STATE_CHANGED` and the preference `service_state`. |
| Floating bubble missing | Overlay permission denied/revoked, service process reclaimed while idle, or overlay window creation exception | Check `Settings.canDrawOverlays()`, re-enable the switch, reopen app, inspect overlay errors in Logcat. |
| Black video | Projection revoked, secure/DRM window, unsupported encoder surface, bad VD/encoder dimensions | Test a normal non-secure app, verify callback and `VirtualDisplay` creation, allow encoder fallback to 720p/480p. Secure content may intentionally be black. |
| Silent internal audio | Source app opts out, uses unsupported audio usage, protected/DRM path, or API <= 28 | Test a normal media/game app on API 29+; `USAGE_MEDIA`/`USAGE_GAME` is matched. Silence must not stop video. |
| No microphone audio | Runtime permission missing, microphone privacy toggle, another app owns mic, foreground microphone type prerequisite not met | Grant `RECORD_AUDIO`, turn off global mic privacy block, start from visible Activity, verify FGS type and `AudioRecord` state. |
| 1080p/90 FPS fails or overheats | Hardware codec size/rate limit, display refresh below 90 Hz, memory bandwidth or thermal throttling | Use 480p/720p; 1080p is capped at 60/30 low-RAM; 90 FPS is a hint bounded by display refresh and hardware. |
| A/V drift or choppy output | Codec buffering, slow AudioRecord reads, thermal pressure, device-specific timestamps | Test long recordings, compare audio/video sync near end, reduce resolution/FPS and bitrate; keep audio/video on monotonic clock and account for pauses. |
| Rotation produces letterboxing or scaling | Encoder dimensions intentionally remain fixed | Set orientation before recording; stop and start a new session after rotation. |
| Android 14 refuses projection | Consent data reused or a second VD created from one projection | Request new consent every session and call `createVirtualDisplay()` once per projection. |

## 10. Build log and device crash inspection

### GitHub Actions / AndroidForge build failures

1. Open the repository's **Actions** tab.
2. Select the failed build run.
3. Open the workflow summary and failed job/step; inspect the first Gradle error, not only the final `BUILD FAILED` line.
4. Download the `AndroidForge-logs` artifact when present. It includes `build.log` and available Gradle reports. For AndroidForge's own web upload, also open the returned run link and inspect the AndroidForge detection, toolchain setup and Gradle build steps; download the run artifacts from the summary page.
5. Common build blockers include JDK not 17, Gradle/AGP mismatch, unavailable SDK platform 34, dependency repository/network failures, malformed manifest XML, and Java compile errors.

### Runtime crashes

With ADB connected:

```bash
adb logcat -s LiteScreenRecorderSvc:V AndroidRuntime:E
```

Or filter to the package process:

```bash
adb logcat --pid=$(adb shell pidof com.example.litescreenrecorder)
```

For a crash, capture the complete `FATAL EXCEPTION` block including `Caused by` and the stack trace. Also inspect `LiteScreenRecorderSvc` messages immediately before the crash; they identify projection, codec, muxer, storage and overlay phases. An on-device log viewer can be used when ADB is unavailable; filter by package `com.example.litescreenrecorder`, tag `LiteScreenRecorderSvc`, and severity Error/Exception.

## 11. Before calling a build production-ready

Run a device matrix: API 24–28, API 29–32, API 33, and API 34; 480p/720p/1080p; 30/60/90 requests; both audio modes; permission denial/revocation; overlay grant/revocation; pause/resume; 10–30 minute sessions; rotation; low-RAM hardware; battery/thermal throttling; notification shade stop and projection revocation. Confirm every resulting MP4 plays to the end and reaches Gallery. The Android media APIs expose vendor codec differences that cannot be proven by source inspection or cloud compilation alone.
